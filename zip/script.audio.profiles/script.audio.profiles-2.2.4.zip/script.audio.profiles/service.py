
from resources.lib.audioprofiles import apMonitor

if ( __name__ == "__main__" ):
    apMonitor()
