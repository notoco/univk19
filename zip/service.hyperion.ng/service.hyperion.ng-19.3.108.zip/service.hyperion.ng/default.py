# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2018-present Team CoreELEC (https://coreelec.org)

import xbmc

monitor = xbmc.Monitor()
monitor.waitForAbort()
