"""Tiny TheMovieDB.org API wrapper."""

from datetime import datetime, date as dt_date, timedelta
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin
from enum import Enum
from typing import Optional, Union, Any, Tuple, List, Dict, Set, Sequence, Iterable, Iterator, Mapping, Callable
from typing import Generic, Generator, ClassVar, Type, TypeVar, NamedTuple
from typing_extensions import Literal, get_args as get_typing_args, TypedDict, Unpack, NotRequired, TypeAlias, cast
# from typing_extensions import Annotated
from attrs import define, frozen
import requests

from ..defs import VideoIds, MediaRef
from ..defs import RefType, MainMediaType, MainMediaTypeList, ItemList, SearchType
from ..ff.db.playback import MediaPlayInfo, MediaPlayInfoDict
from ..ff.item import FFItem
from ..ff.types import JsonData, JsonResult, KwArgs
from ..ff.calendar import utc_timestamp
from ..ff.debug import logtime
from ..ff.tricks import join_items, batched
from ..ff.log_utils import fflog
from ..ff.control import max_thread_workers
from const import const


T = TypeVar('T')

TmdbId: TypeAlias = int
MovieId: TypeAlias = TmdbId
ShowId: TypeAlias = TmdbId
SeasonId: TypeAlias = TmdbId
EpisodeId: TypeAlias = TmdbId
SeasonNumber: TypeAlias = int
EpisodeNumber: TypeAlias = int
# TmdbTvIdKey = Tuple[ShowId, Optional[SeasonId], Optional[EpisodeId]]
# TmdbTvIds = Dict[TmdbTvIdKey, TmdbId]

#: TMDB get info content type.
TmdbContentType: TypeAlias = Literal['movie', 'tv']
TmdbContentPluarType: TypeAlias = Literal['movies', 'tv']
#: TMDB get info content type.
TmdbListType: TypeAlias = Literal[
    'top_rated',    # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=vote_average.desc&without_genres=99,10755&vote_count.gte=200
    'popular',      # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc
    'now_playing',  # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}
    'upcoming',     # ?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}
]

TimeWindow: TypeAlias = Literal['week', 'day']

TmdbConfName: TypeAlias = Literal['countries', 'jobs', 'languages', 'primary_translations', 'timezones']

ExternalIdType: TypeAlias = Literal['imdb']

TmdbSearchType: TypeAlias = Literal['collection', 'company', 'keyword', 'movie', 'multi', 'person', 'tv']

PersonDataType: TypeAlias = Literal['combined_credits', 'movie_credits', 'tv_credits']

DetailsAllowed: TypeAlias = Literal['movie', 'show', 'person', 'collection']

MediaResource: TypeAlias = Literal['recommendations', 'similar']

AccountId: TypeAlias = Union[int, Literal['me']]

#: Users general list.
UserGeneralListType: TypeAlias = Literal['favorite', 'watchlist']
#: TMDB JSON item data.
TmdbItemJson: TypeAlias = Dict[str, Any]
#: Media JSON data.
TmdbMediaDataDict: TypeAlias = Dict[MediaRef, TmdbItemJson]
#: TMDB sort_by values (movie).
TmdbMovieSortBy: TypeAlias = Literal['original_title.asc', 'original_title.desc',
                                     'popularity.asc', 'popularity.desc',
                                     'revenue.asc', 'revenue.desc',
                                     'primary_release_date.asc', 'primary_release_date.desc',
                                     'title.asc', 'title.desc',
                                     'vote_average.asc', 'vote_average.desc',
                                     'vote_count.asc', 'vote_count.desc',
                                     ]
#: TMDB sort_by values (tv).
TmdbTvSortBy: TypeAlias = Literal['first_air_date.asc', 'first_air_date.desc',
                                  'name.asc', 'name.desc',
                                  'original_name.asc', 'original_name.desc',
                                  'popularity.asc', 'popularity.desc',
                                  'vote_average.asc', 'vote_average.desc',
                                  'vote_count.asc', 'vote_count.desc',
                                  ]
#: TMDB sort_by values.
TmdbSortBy: TypeAlias = Literal['original_title.asc', 'original_title.desc',              # movie only
                                'revenue.asc', 'revenue.desc',                            # movie only
                                'primary_release_date.asc', 'primary_release_date.desc',  # movie only
                                'title.asc', 'title.desc',                                # movie only
                                'first_air_date.asc', 'first_air_date.desc',              # tv-show only
                                'name.asc', 'name.desc',                                  # tv-show only
                                'original_name.asc', 'original_name.desc',                # tv-show only
                                'popularity.asc', 'popularity.desc',
                                'vote_average.asc', 'vote_average.desc',
                                'vote_count.asc', 'vote_count.desc',
                                ]


class TmdbCredentials(NamedTuple):
    """TMDB credentials."""

    #: Optional TMDB api-key for get more tv-show info.
    api_key: str
    #: User name.
    user: Optional[str] = None
    #: User password.
    password: Optional[str] = None
    #: User session.
    session_id: Optional[str] = None

    def __bool__(self) -> bool:
        """Return True if creadentials are defined (user is logged)."""
        return bool(self.session_id)


class GetImageMode(Enum):
    """Mode of image getting."""
    #: append  - use `append_to_response=images` with fixed `include_image_language`, no poster at all often
    APPEND = 'append'
    #: pull    - like `append` but gen images in next request if fails (no images)
    PULL = 'pull'
    #: full    - always make two requests, support all services (it is forced for non-tmdb services, e.g. fanart.tv)
    FULL = 'full'
    #: all     - use /images to get all images in concurrent request
    ALL = 'all'


class PersonCredits(NamedTuple):
    """Person credits result."""

    cast: Tuple[FFItem, ...] = ()
    crew: Tuple[FFItem, ...] = ()


class Condition(Generic[T]):
    """TMDB discovery conditions."""

    def __init__(self, type: Type[T], *, cond: Optional[List[Tuple[str, str]]] = None) -> None:
        self.type: Type[T] = type
        self.cond: List[Tuple[str, str]] = [] if cond is None else cond

    def range(self, min: T, max: T) -> 'Condition':
        return Condition(self.type, cond=[('gte', str(min)), ('lte', str(max))])

    def _add(self, val: T, a: int) -> T:
        if isinstance(val, dt_date):
            return val + timedelta(days=a)
        if isinstance(val, int):
            return val + a
        if isinstance(float, int):
            return val + .001 * a
        return val

    def __repr__(self) -> str:
        return f'Conditional(type={self.type}, cond={self.cond})'

    def __str__(self) -> str:
        s = ' & '.join(f'{k}={v}' for k, v in self.cond)
        return f'Conditional({s})'

    def __le__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('lte', str(other))])

    def __ge__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('gte', str(other))])

    def __lt__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('gte', str(self._add(other, -1)))])

    def __gt__(self, other: T) -> 'Condition':
        if type(other) is not self.type:
            try:
                other = self.type(other)
            except Exception:
                return Condition(self.type)
        return Condition(self.type, cond=[('gte', str(self._add(other, 1)))])

    def __and__(self, other: 'Condition[T]') -> 'Condition':
        if isinstance(other, Condition):
            return Condition(self.type, cond=[*self.cond, *other.cond])
        return NotImplemented


# RangeCondition: TypeAlias = Annotated[T, Condition]


class DiscoveryFilters(TypedDict):
    """Filter arguments for TMDB discovery."""

    air_date: NotRequired[Condition[dt_date]]
    first_air_date: NotRequired[Condition[dt_date]]
    first_air_year: NotRequired[int]
    include_null_first_air_dates: NotRequired[bool]
    screened_theatrically: NotRequired[bool]
    timezone: NotRequired[str]
    with_networks: NotRequired[int]
    with_status: NotRequired[Union[str, Literal[0, 1, 2, 3, 4, 5]]]
    with_type: NotRequired[Union[str, Literal[0, 1, 2, 3, 4, 5, 6]]]

    certification: NotRequired[Union[str, Condition[str]]]
    certification_country: NotRequired[str]
    include_adult: NotRequired[bool]
    include_video: NotRequired[bool]
    language: NotRequired[str]
    primary_release_year: NotRequired[int]
    primary_release_date: NotRequired[Condition[dt_date]]
    region: NotRequired[str]
    release_date: NotRequired[Condition[dt_date]]
    sort_by: NotRequired[TmdbSortBy]
    vote_average: NotRequired[Condition[float]]
    vote_count: NotRequired[Condition[int]]
    watch_region: NotRequired[str]
    with_cast: NotRequired[str]
    with_companies: NotRequired[str]
    with_crew: NotRequired[str]
    with_genres: NotRequired[str]
    with_keywords: NotRequired[str]
    with_origin_country: NotRequired[str]
    with_original_language: NotRequired[str]
    with_people: NotRequired[str]
    with_release_type: NotRequired[Union[str, Literal[1, 2, 3, 4, 5, 6]]]
    with_runtime: NotRequired[Condition[int]]
    with_watch_monetization_types: NotRequired[Union[str, Literal['flatrate', 'free', 'ads', 'rent', 'buy']]]
    with_watch_providers: NotRequired[str]
    without_companies: NotRequired[str]
    without_genres: NotRequired[str]
    without_keywords: NotRequired[str]
    without_watch_providers: NotRequired[str]
    year: NotRequired[int]


class SearchFilters(TypedDict):
    """Filter arguments for TMDB search."""

    include_adult: NotRequired[bool]
    primary_release_year: NotRequired[int]
    year: NotRequired[int]
    first_air_date_year: NotRequired[int]
    region: NotRequired[str]


class TmdbRequestKwargs(TypedDict):
    credentials: NotRequired[Optional[TmdbCredentials]]
    api_version: NotRequired[int]
    params: NotRequired[Optional[KwArgs]]
    append_to_response: NotRequired[Tuple[str, ...]]
    lang: NotRequired[Optional[str]]


@define
class TmdbApiStats:
    request_count: int = 0
    extra_seasons_count: int = 0
    multi_seasons_count: int = 0


class TmdbApi:
    """Base TBDB API."""

    # 2015:
    #   Movies - alternative_titles, changes, credits, images, keywords, lists, releases, reviews, similar, translations, videos
    #   TV - alternative_titles, changes, content_ratings, credits, external_ids, images, keywords, similar, translations, videos
    #   People - changes, combined_credits, external_ids, images, movie_credits, tagged_images, tv_credits
    # + (2015):
    #   genre_ids, original_language and overview

    DISCOVER_FILTERS = {
        'air_date.gte': dt_date,
        'air_date.lte': dt_date,
        'first_air_year': int,
        'first_air_date.gte': dt_date,
        'first_air_date.lte': dt_date,
        'include_null_first_air_dates': bool,
        'screened_theatrically': bool,
        'timezone': str,
        'with_networks': int,
        'with_status': Union[str, Literal[0, 1, 2, 3, 4, 5]],  # can be a comma (AND) or pipe (OR) separated query, can be used in conjunction with region
        'with_type': Union[str, Literal[0, 1, 2, 3, 4, 5, 6]],  # can be a comma (AND) or pipe (OR) separated query, can be used in conjunction with region

        'certification': str,
        'certification.gte': str,
        'certification.lte': str,
        'certification_country': str,
        'include_adult': bool,
        'include_video': bool,
        'language': str,
        'primary_release_year': int,
        'primary_release_date.gte': dt_date,
        'primary_release_date.lte': dt_date,
        'region': str,
        'release_date.gte': dt_date,
        'release_date.lte': dt_date,
        'sort_by': TmdbSortBy,
        'vote_average.gte': float,
        'vote_average.lte': float,
        'vote_count.gte': float,
        'vote_count.lte': float,
        'watch_region': str,
        'with_cast': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_companies': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_crew': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_genres': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_keywords': str,   # can be a comma (AND) or pipe (OR) separated query
        'with_origin_country': str,
        'with_original_language': str,
        'with_people': str,  # can be a comma (AND) or pipe (OR) separated query
        'with_release_type': Union[str, Literal[1, 2, 3, 4, 5, 6]],  # can be a comma (AND) or pipe (OR) separated query, can be used in conjunction with region
        'with_runtime.gte': int,
        'with_runtime.lte': int,
        'with_watch_monetization_types': Union[str, Literal['flatrate', 'free', 'ads', 'rent', 'buy']],  # use in conjunction with watch_region, can be a comma (AND) or pipe (OR) separated query
        'with_watch_providers': str,  # use in conjunction with watch_region, can be a comma (AND) or pipe (OR) separated query
        'without_companies': str,
        'without_genres': str,
        'without_keywords': str,
        'without_watch_providers': str,
        'year': int,
        # --- conditional keywords ---
        'air_date': dt_date,
        'first_air_date': dt_date,
        'primary_release_date': Condition[str],
        'release_date': Condition[dt_date],
        'vote_average': Condition[float],
        'vote_count': Condition[float],
        'with_runtime': Condition[int],
    }

    # --- some dicovery conditions ---
    Date = Condition(dt_date)
    Int = Condition(int)
    Float = Condition(float)
    VoteCount = Int
    VoteAverage = Float
    Vote = VoteAverage
    Int = Condition(int)
    Today = dt_date.today()
    Now = Today
    WeekAgo = Today - timedelta(days=7)

    _main2tmdb_type: Dict[MainMediaType, TmdbContentType] = {
        'movie': 'movie',
        'show': 'tv',
    }

    _main2tmdb_type2: Dict[MainMediaType, TmdbContentPluarType] = {
        'movie': 'movies',
        'show': 'tv',
    }

    _ext_id_results: Dict[RefType, str] = {
        'movie': 'movie_results',
        'show': 'tv_results',
        'season': 'tv_season_results',
        'episode': 'tv_episode_results',
        'person': 'person_results',
    }

    _search2tmdb: Dict[SearchType, Optional[TmdbSearchType]] = {
        'all': 'multi',
        'multi': 'multi',
        'movie': 'movie',
        'show': 'tv',
        'person': 'person',
        'collection': 'collection',
        'company': 'company',
        'keyword': 'keyword',
    }

    _person2ref: Dict[PersonDataType, RefType] = {
        'combined_credits': '',
        'movie_credits': 'movie',
        'tv_credits': 'show',
    }

    # NOT USED yet, got from https://developer.themoviedb.org/reference/movie-now-playing-list
    predef_lists = {
        'now_playing': 'include_adult=false&include_video=false&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}',
        'popular': 'include_adult=false&include_video=false&sort_by=popularity.desc',
        'top_rated': 'include_adult=false&include_video=false&sort_by=vote_average.desc&without_genres=99,10755&vote_count.gte=200',
        'upcoming': 'include_adult=false&include_video=false&sort_by=popularity.desc&with_release_type=2|3&release_date.gte={min_date}&release_date.lte={max_date}',
    }

    _DEBUG_STATS: ClassVar[TmdbApiStats] = TmdbApiStats()

    def __init__(self, api_key: Optional[str] = None, lang: Optional[str] = None) -> None:
        #: TMDB base URL.
        self.base: str = 'https://api.themoviedb.org/'
        #: Base API version.
        self.api_version: int = 3
        #: TMDB base URL for v3.
        self.base3: str = f'{self.base}{self.api_version}'
        #: URL to person profile image.
        self.art_image_url: str = 'https://image.tmdb.org/t/p/w780'
        #: URL to art image with formating.
        self.art_image_url_fmt: str = 'https://image.tmdb.org/t/p/{width}'
        #: URL to person profile image.
        self.person_image_url: str = 'https://image.tmdb.org/t/p/w300_and_h450_bestv2'
        #: TMDB API key for direct use. If None, credentials() must be overloaded.
        self.api_key: Optional[str] = api_key
        #: TMDB response language.
        self.lang: Optional[str] = lang  # or 'pl-PL'
        #: Connection timeout.
        self.timeout = 15

    def _update_lang(self, lang: Optional[str] = None) -> str:
        """Update language (from settings)."""
        if lang is None:
            if self.lang is None:
                from ..ff.control import apiLanguage
                self.lang = apiLanguage().get('tmdb', 'pl-PL')
            lang = self.lang
        return lang

    # @logtime
    def request(self,
                method: str,
                url: str,
                *,
                credentials: Optional[TmdbCredentials] = None,
                api_version: int = 3,
                data: Optional[JsonData] = None,
                params: Optional[KwArgs] = None,
                append_to_response: Tuple[str, ...] = (),
                lang: Optional[str] = None,
                ) -> Optional[requests.Response]:
        """Request to API."""

        def cond_params(params: KwArgs) -> Generator[Tuple[str, Any], None, None]:
            for k, v in params.items():
                if isinstance(v, Condition):
                    for cmp, val in v.cond:
                        # if val is True:
                        #     val = 'true'
                        # elif val is False:
                        #     val = 'false'
                        yield f'{k}.{cmp}', val
                else:
                    # if v is True:
                    #     v = 'true'
                    # elif v is False:
                    #     v = 'false'
                    yield k, v

        url = urljoin(f'{self.base}/{api_version}/', url)
        if credentials is None:
            credentials = self.credentials()
        # append_to_response = ['external_ids', 'release_dates', 'translations']  # 'images', 'original_language'
        params = dict(cond_params(params or {}))
        params.setdefault('api_key', credentials.api_key)
        if credentials:
            params.setdefault('session_id', credentials.session_id)
        if append_to_response:
            params.setdefault('append_to_response', ','.join(append_to_response))
        lang = self._update_lang(lang)
        if lang:
            params['language'] = self.lang
        headers = {
            'Accept': 'application/json',
        }
        fflog(f'[FF][TMDB] {url=}, {params=}')
        self._DEBUG_STATS.request_count += 1
        resp = requests.request(method, url, json=data, params=params, headers=headers, timeout=self.timeout)
        if resp.status_code >= 400:
            fflog(f'[TMDB] ERROR {resp.status_code} for {url}')
        return resp

    def get(self, url: str, **kwargs: Unpack[TmdbRequestKwargs]) -> Optional[JsonResult]:
        """Send GET request to tbdb.org and return JSON."""
        resp: Optional[requests.Response] = self.request('GET', url, data=None, **kwargs)
        if resp is None:
            return None
        return resp.json()

    def post(self, url: str, data: JsonData, **kwargs: Unpack[TmdbRequestKwargs]) -> Optional[JsonData]:
        """Send POST request to tbdb.org and return JSON."""
        resp: Optional[requests.Response] = self.request('POST', url, data=data, **kwargs)
        if resp is None:
            return None
        return resp.json()

    def delete(self, url: str, data: JsonData, **kwargs: Unpack[TmdbRequestKwargs]) -> Optional[JsonData]:
        """Send POST request to tbdb.org and return JSON."""
        resp: Optional[requests.Response] = self.request('DELETE', url, data=data, **kwargs)
        if resp is None:
            return None
        return resp.json()

    def auth(self, *, credentials: Optional[TmdbCredentials] = None, force: bool = False) -> bool:
        """Authorize user and create new session."""
        if credentials is None:
            credentials = self.credentials()
        if not force and credentials:
            return True  # already authorized
        credentials = credentials._replace(session_id=None)
        if not credentials.user or not credentials.password:
            return False
        data = self.get('authentication/token/new', credentials=credentials)
        if not isinstance(data, Mapping):
            return False
        token = data.get('request_token')
        if not token:
            return False
        data = self.post('authentication/token/validate_with_login', credentials=credentials, data={
            'username': credentials.user,
            'password': credentials.password,
            'request_token': token,
        })
        if not data:
            return False
        data = self.post('authentication/session/new', credentials=credentials, data={'request_token': token})
        if not isinstance(data, Mapping) or not data.get('success'):
            return False
        self.set_session_id(data['session_id'])
        return True

    def revoke_session(self, *, credentials: Optional[TmdbCredentials] = None) -> bool:
        """Revoke the session (logout user)."""
        if credentials is None:
            credentials = self.credentials()
        if not credentials:
            return True  # no session, already done
        data = self.delete('authentication/session', credentials=credentials,
                           data={'session_id': credentials.session_id})
        if not isinstance(data, Mapping) or not data.get('success'):
            return False
        self.set_session_id(None)  # forgot session id
        return True

    unauth = revoke_session

    def _parse_art(self, *, item: JsonData, translate_order: Sequence[str], skip_fanart: bool) -> Dict[str, str]:
        """Pre-parse art images. Much simpler verison of Art.parse_art()."""
        from ..ff.art import TmbdArtService
        images = item.get('images') or {}
        art_langs = (*dict.fromkeys(loc.partition('-')[0] for loc in translate_order), *(None,))
        no_langs = ('00', 'xx', None)
        art: Dict[str, str] = {}
        # breakpoint()
        for aname, artdef in TmbdArtService.art_names.items():
            for src in artdef.sources:
                ilist = images.get(src.key)
                if ilist:
                    for lng in artdef.langs(yes=art_langs, no=no_langs, skip_fanart=skip_fanart):
                        for ielem in ilist:
                            if ielem.get('iso_639_1') == lng and (path := ielem['file_path']):
                                art[aname] = f'{self.art_image_url}{path}'
                                break
                        else:
                            continue
                        break
                    else:
                        continue
                    break
        return art

    def get_media_by_ref(self, ref: MediaRef, *, tv_episodes: bool = False,
                         seasons: Optional[Iterable[int]] = None,
                         credentials: Optional[TmdbCredentials] = None) -> TmdbItemJson:
        """Get single media by reference."""
        def get(path: str, par: Optional[Dict[str, Any]] = None):
            if par is None:
                par = params
            fflog(f'[FF][TMDB] {path=}, params={par!r}')
            self._DEBUG_STATS.request_count += 1
            resp = requests.get(f'{self.base3}/{path}', params=par)
            if resp.status_code >= 400:
                fflog(f'[FF][TMDB] ERROR {resp.status_code} for {path}')
            return resp.json()

        tv_seasons = tuple(seasons or ())
        rtype = ref.real_type
        if credentials is None:
            credentials = self.credentials()
        imode = GetImageMode(const.tmdb.get_image_mode)
        respapp = ['external_ids', 'release_dates', 'translations']
        if imode in (GetImageMode.APPEND, GetImageMode.PULL):
            respapp.append('images')
        if ref.real_type in ('show', 'season'):
            respapp.append('aggregate_credits')
        elif ref.real_type in ('movie', 'episode'):
            respapp.append('credits')
        # append a few seasons with episodes to single request (sic!)
        scount: int = 0
        if tv_episodes and rtype == 'show':  # append a few existing seasons with episodes to single request (sic!)
            # see: https://www.themoviedb.org/talk/63ee22b4699fb7009e3e5102
            respapp.extend(f'season/{i+1}' for i in range(const.tmdb.append_seasons_count))
        if tv_seasons and rtype == 'show':  # append a few requestet seasons to single request (sic!)
            scount = const.tmdb.append_seasons_count
            respapp.extend(f'season/{i}' for i in tv_seasons[:scount])
            tv_seasons = tv_seasons[scount:]
        params = {
            'api_key': credentials.api_key,
            'append_to_response': ','.join(respapp)
        }
        lang = self._update_lang()
        if self.lang:
            params['language'] = self.lang
        if 'images' in respapp:
            lang = self.lang.partition('-')[0] if self.lang else 'en'
            params['include_image_language'] = ','.join(dict.fromkeys((lang, 'en', 'xx', 'null')))
        if ref.type == 'movie':
            path = f'movie/{ref.tmdb_id}'
        elif ref.type == 'show':
            path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], ref.tmdb_tv_tuple))
        elif ref.type in ('person', 'collection'):
            path = f'{ref.type}/{ref.tmdb_id}'
        else:
            # non DetailsAllowed type
            raise ValueError(f'Unsupported TMDB media type {ref.type}, can NOT use season or episode ID or else')

        # receive tmdb data with images
        if imode is GetImageMode.ALL:
            with ThreadPoolExecutor(max_thread_workers()) as ex:
                obj = ex.submit(get, path)
                img = ex.submit(get, f'{path}/images', {'api_key': credentials.api_key})
            data = obj.result()
            data['images'] = img.result()

        else:
            data: JsonData = get(path)
            if imode is GetImageMode.PULL:
                orig_lang: str = data.get('original_language', 'en')
                trans_order = tuple(dict.fromkeys((self._update_lang(), lang, 'en-US', 'en-GB', 'en',
                                                   *(f'{orig_lang}-{c}' for c in data.get('origin_country', ())), orig_lang)))
                art = self._parse_art(item=data, translate_order=trans_order, skip_fanart=ref.is_episode)
                if not all(art.get(a) for a in ('fanart', 'landscape', 'poster', 'clearlogo')):
                    data['images'] = get(f'{path}/images', {'api_key': credentials.api_key})

        # fix up extra seasons and theirs episodes
        if (tv_episodes or tv_seasons) and rtype == 'show':
            # get missing seasons (if more then const.tmdb.append_seasons_count)
            if tv_episodes:
                seasons_need = {sz['season_number'] for sz in data.get('seasons', ())}
            else:
                seasons_need = set(tv_seasons)
            seasons_got = {int(sznum) for asz in data if asz.startswith('season/') if (sznum := asz.partition('/')[2]).isdigit()}
            missing_seasons = seasons_need - seasons_got
            if missing_seasons:
                data2: JsonData
                self._DEBUG_STATS.extra_seasons_count += 1
                scount = const.tmdb.append_seasons_max_count
                if len(missing_seasons) > scount:
                    def get_seasons(nums):
                        sz_params = {**params, 'append_to_response': ','.join(f'season/{sz}' for sz in nums)}
                        return get(path, sz_params)

                    self._DEBUG_STATS.multi_seasons_count += 1
                    with ThreadPoolExecutor(max_thread_workers()) as ex:
                        for data2 in ex.map(get_seasons, batched(missing_seasons, scount)):
                            if isinstance(data2, Mapping) and data2.get('success', True):
                                data.update(data2)
                else:
                    # get extra info about missing show seasons
                    params['append_to_response'] = ','.join(f'season/{sz}' for sz in missing_seasons)
                    data2 = get(path)
                    if isinstance(data2, Mapping) and data2.get('success', True):
                        data.update(data2)

        # udpate main season list
        if rtype == 'show':
            for sz in data.get('seasons') or ():
                num: int = sz['season_number']
                sz['_ref'] = ref.with_season(num)
                sz['_type'] = 'season'
                if ex := data.get(f'season/{num}'):
                    sz.update(ex)

        data['_ref'] = ref
        data['_type'] = rtype
        if rtype == 'episode':
            if tv_vid := VideoIds.from_dbid(ref.dbid):
                data.setdefault('show_id', tv_vid.tmdb)
        return data

    # @logtime
    def get_media_list_by_ref(self, refs: Sequence[MediaRef], *, tv_episodes: bool = False,
                              credentials: Optional[TmdbCredentials] = None) -> List[TmdbItemJson]:
        """Get list of media by theris references."""
        def get(ref):
            return self.get_media_by_ref(ref, tv_episodes=tv_episodes, credentials=credentials)

        if credentials is None:
            credentials = self.credentials()
        with ThreadPoolExecutor(max_thread_workers()) as ex:
            jobs = ex.map(get, refs)
        return list(jobs)

    # @logtime
    def get_media_dict_by_ref(self, refs: Sequence[MediaRef], *, tv_episodes: bool = False, optimize: bool = False,
                              credentials: Optional[TmdbCredentials] = None) -> Dict[MediaRef, TmdbItemJson]:
        """Get dict of media by theris references."""
        def get(ref):
            if optimize and ref.is_show:
                seasons = show_seasons.get(ref)
            else:
                seasons = None
            return self.get_media_by_ref(ref, tv_episodes=tv_episodes, credentials=credentials, seasons=seasons)

        # optimize requests, to get seasons inside shows
        if optimize:
            show_seasons: Dict[MediaRef, Set[int]] = {ref: set() for ref in refs if ref.is_show}
            for ref in refs:
                if ref.is_season and (show_ref := ref.show_ref) and (nums := show_seasons.get(show_ref)) is not None:
                    assert ref.season is not None
                    nums.add(ref.season)
            refs = [ref for ref in refs if not ref.is_season or ref.show_ref not in show_seasons]
        # get items
        if credentials is None:
            credentials = self.credentials()
        if len(refs) == 1:
            jobs = [get(refs[0])]
        else:
            with ThreadPoolExecutor(max_thread_workers()) as ex:
                jobs = ex.map(get, refs)
        if optimize:
            def scan_items(item: JsonData) -> Iterator[JsonData]:
                yield item
                for sz in item.get('seasons', ()):
                    num = sz['season_number']
                    if item.get(f'season/{num}'):
                        yield sz
            return {it['_ref']: it for item in jobs for it in scan_items(item)}
        else:
            return {it['_ref']: it for it in jobs}

    def list_refs(self, type: RefType, items: Sequence[Union[JsonData, FFItem]]) -> List[MediaRef]:
        """Get refs from media item list."""
        if items:
            elem = items[0]
            if isinstance(elem, (FFItem, MediaRef)):
                return [it.ref for it in cast(Sequence[FFItem], items)]
            if isinstance(elem, Mapping):
                return [MediaRef.from_tmdb(type, it.get('id', 0), season=None, episode=None) for it in items]
        return []

    def get_skel_en_media(self, refs: Sequence[MediaRef], *,
                          credentials: Optional[TmdbCredentials] = None) -> Dict[MediaRef, TmdbItemJson]:
        """Load sekelton media info."""
        def get(ref: MediaRef, par: Optional[Dict[str, Any]] = None) -> TmdbItemJson:
            if par is None:
                par = params
            rtype = ref.real_type
            if ref.type == 'movie':
                path = f'movie/{ref.tmdb_id}'
            elif ref.type == 'show':
                path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], ref.tmdb_tv_tuple))
            elif ref.type in ('person', 'collection'):
                path = f'{ref.type}/{ref.tmdb_id}'
            else:
                # non DetailsAllowed type
                raise ValueError(f'Unsupported TMDB media type {ref.type}, can NOT use season or episode ID or else')
            fflog(f'[FF][TMDB] {path=}, params={par!r}')
            self._DEBUG_STATS.request_count += 1
            resp = requests.get(f'{self.base3}/{path}', params=par)
            if resp.status_code >= 400:
                fflog(f'[FF][TMDB] ERROR {resp.status_code} for {path}')
            data = resp.json()
            data['_ref'] = ref
            data['_type'] = rtype
            if rtype == 'episode':
                if tv_vid := VideoIds.from_dbid(ref.dbid):
                    data.setdefault('show_id', tv_vid.tmdb)
            return data

        if credentials is None:
            credentials = self.credentials()
        params = {
            'api_key': credentials.api_key,
            'append_to_response': 'external_ids',
            # 'language': 'en-US',
        }
        # for ref in refs:
        #     if ref.type not in {'movie', 'show', 'person', 'collection'}:
        #         # non DetailsAllowed type
        #         raise ValueError(f'Unsupported TMDB media type {ref.type}, can NOT use season or episode ID or else')

        if not refs:
            return {}
        if len(refs) == 1:
            ref = refs[0]
            return {ref: get(ref)}
        with ThreadPoolExecutor(max_thread_workers()) as ex:
            jobs = ex.map(get, refs)
        return {ref: item for ref, item in zip(refs, jobs)}

    def _item_list(self, type: Union[RefType, SearchType], data: Optional[JsonResult], *,
                   key: str = 'results', out_type: Optional[RefType] = None) -> ItemList[FFItem]:
        """Return item list with pagination."""

        def parse(it: JsonData) -> FFItem:
            def set_if(setter: Callable, key: str) -> None:
                val = it.get(key)
                if val is not None:
                    setter(val)

            mtype: RefType = it.get('media_type', out_type)
            if mtype == 'tv':
                mtype = 'show'
            if out_type == 'movie' and 'media_type' not in it and 'genre_ids' not in it and 'popularity' not in it:
                mtype = 'collection'  # hack, searching movies returns collections
            ref = MediaRef.from_tmdb(mtype, it.get('id') or 0)
            it['_ref'] = ref
            ff = FFItem(ref)
            ff.source_data = it
            vtag = ff.vtag
            ff.label = ff.title = it.get('title', it.get('name')) or ''
            set_if(vtag.setOriginalTitle, 'original_name')
            set_if(vtag.setPlot, 'description')
            set_if(vtag.setPlot, 'overview')
            set_if(vtag.setPremiered, 'release_date')
            if (date := vtag.getPremieredAsW3C()) and date not in ('1970-01-01', '1601-01-01'):
                vtag.setYear(int(date[:4]))
            # set_if(vtag.set..., 'popularity')
            vtag.setRatings({'tmdb': (it.get('vote_average', 0.0), it.get('vote_count', 0))}, 'tmdb')
            ff.role = it.get('character', it.get('job', ''))
            poster = it.get('poster_path', it.get('logo_path'))
            if poster:
                poster = f'{self.person_image_url}/{poster}'
                ff.setArt({'thumb': poster, 'poster': poster})
            return ff

        if out_type is None:
            out_type = type

        if isinstance(data, Mapping):
            return ItemList([parse(it) for it in data.get(key, ())], page=data.get('page', 0),
                            total_pages=data.get('total_pages', 0), total_results=data.get('total_results', 0))

        if isinstance(data, Sequence) and not isinstance(data, str):
            return ItemList([parse(it) for it in data], page=1, total_pages=1, total_results=len(data))

        return ItemList.empty()

    # --- General API ---

    def discover(self,
                 type: MainMediaType,
                 *,
                 page: int = 1,
                 # all filter paramaters from https://developer.themoviedb.org/reference/discover-movie
                 **kwargs: Unpack[DiscoveryFilters],
                 ) -> ItemList:
        """Discover media."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.discover() got incorrect type {type!r}')
        try:
            ctype = self._main2tmdb_type[type]
        except KeyError:
            return ItemList.empty()

        allowed = set(self.DISCOVER_FILTERS)
        if kwargs.keys() - allowed:
            wrong = ', '.join(kwargs.keys() - allowed)
            raise TypeError(f'TmdbApi.discover() unknown filter params: {wrong}')

        params = {}
        for k, v in kwargs.items():
            if v is not None:
                params[k] = v
        params['page'] = page
        # data: Optional[JsonData] = cast(Optional[JsonData], self.get(type, params=params))
        return self._item_list(type, self.get(f'discover/{ctype}', params=params))

    def discover_list(self,
                      type: MainMediaType,
                      list: TmdbListType,
                      *,
                      page: int = 1,
                      region: Optional[str] = None,
                      ) -> ItemList:
        """Discover media list (tweaked discover)."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.discover() got incorrect type {type!r}')
        if list not in get_typing_args(TmdbListType):
            raise ValueError(f'TmdbApi.discover() got incorrect list {list!r}')
        try:
            ctype = self._main2tmdb_type[type]
        except KeyError:
            return ItemList.empty()

        params: Dict[str, Any] = {'page': page}
        if region:
            params['region'] = region
        return self._item_list(type, self.get(f'{ctype}/{list}', params=params))

    def trending(self,
                 type: MainMediaType,
                 time: TimeWindow = 'week',
                 *,
                 page: int = 1,
                 ) -> ItemList:
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.trending() got incorrect type {type!r}')
        if time not in get_typing_args(TimeWindow):
            raise ValueError(f'TmdbApi.trending() got incorrect time window {time!r}')
        ctype = self._main2tmdb_type[type]

        params: Dict[str, Any] = {'page': page}
        return self._item_list(type, self.get(f'trending/{ctype}/{time}', params=params))
        # Daily Trending
        # https://api.themoviedb.org/3/trending/movie/day?api_key=###
        # https://api.themoviedb.org/3/trending/tv/day?api_key=###
        # https://api.themoviedb.org/3/trending/person/day?api_key=###
        # https://api.themoviedb.org/3/trending/all/day?api_key=###
        # Weekly Trending
        # https://api.themoviedb.org/3/trending/movie/week?api_key=###
        # https://api.themoviedb.org/3/trending/tv/week?api_key=###
        # https://api.themoviedb.org/3/trending/person/week?api_key=###
        # https://api.themoviedb.org/3/trending/all/weekly?api_key=###

    def configuration(self, name: TmdbConfName) -> List[JsonData]:
        """Get configuration lists like countries, languages etc."""
        data = self.get(f'configuration/{name}')
        if isinstance(data, Sequence):
            return data
        return []

    def genres(self, type: MainMediaType) -> List[JsonData]:
        """Get genres lists."""
        if type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.genres() got incorrect type {type!r}')
        ctype = self._main2tmdb_type[type]

        data = self.get(f'genre/{ctype}/list')
        if isinstance(data, Mapping):
            return data['genres']
        return []

    def find_id(self, source: ExternalIdType, id: Union[int, str]) -> Optional[MediaRef]:
        """Find external id."""
        data = self.get(f'find/{id}', params={'external_source': f'{source}_id'})
        if not isinstance(data, Mapping):
            return None
        for mtype, key in self._ext_id_results.items():
            if data.get(key):
                data = data[key][0]
                return MediaRef.from_tmdb(mtype, data['id'], data.get('season_number'), data.get('episode_number'))

    def find_ids(self, source: ExternalIdType, ids: Iterable[Union[int, str]]) -> Sequence[Optional[MediaRef]]:
        """Find list of external id."""
        def get(id: Union[int, str]) -> Optional[MediaRef]:
            return self.find_id(source, id)

        with ThreadPoolExecutor(max_thread_workers()) as ex:
            jobs = ex.map(get, ids)
        return list(jobs)

    def find_mixed_ids(self, ids: Iterable[Tuple[ExternalIdType, Union[int, str]]]) -> Sequence[Optional[MediaRef]]:
        """Find list of external id as list of (source, id)."""
        def get(args: Tuple[ExternalIdType, Union[int, str]]) -> Optional[MediaRef]:
            src, id = args
            return self.find_id(src, id)

        with ThreadPoolExecutor(max_thread_workers()) as ex:
            jobs = ex.map(get, ids)
        return list(jobs)

    def search(self,
               type: SearchType,
               query: str,
               *,
               page: int = 1,
               **kwargs: Unpack[SearchFilters],
               ) -> ItemList[FFItem]:
        """Search items."""
        stype = self._search2tmdb.get(type)
        if not stype:
            return ItemList.empty()
        params = {'page': page, 'query': query, **kwargs}
        return self._item_list(type, self.get(f'search/{stype}', params=params))

    def person_credits(self, person_id: int, type: PersonDataType) -> PersonCredits:
        """Get person credits."""
        mtype = self._person2ref[type]
        if person_id in VideoIds.TMDB:
            person_id = VideoIds.TMDB.index(person_id)
        data = self.get(f'person/{person_id}/{type}')
        if isinstance(data, Mapping):
            return PersonCredits(cast=tuple(self._item_list(mtype, data.get('cast', ()))),
                                 crew=tuple(self._item_list(mtype, data.get('crew', ()))))
        return PersonCredits()

    def collection_items(self, collection_id: int) -> Sequence[FFItem]:
        """Get collection's items."""

        def parse(it: JsonData) -> FFItem:
            mtype = it.get('media_type', 'movie')
            if mtype == 'tv':
                mtype = 'show'
            ref = MediaRef.from_tmdb(mtype, it['id'])
            ff = FFItem(ref)
            ff.title = it.get('title') or ''
            ff.vtag.setOriginalTitle(it.get('original_title') or '')
            poster = it.get('poster_path')
            if poster:
                ff.setArt({'poster': f'{self.art_image_url}{poster}'})
            return ff

        if collection_id in VideoIds.TMDB:
            collection_id = VideoIds.TMDB.index(collection_id)
        data = self.get(f'collection/{collection_id}')
        if isinstance(data, Mapping):
            return [parse(it) for it in data.get('parts', ())]
        return []

    def media_resource(self, ref: MediaRef, resource: MediaResource, *, page: int = 1) -> List[FFItem]:
        """Get media (movie, show) resource."""
        if ref.type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.media_resource() got incorrect type {ref.type!r}')
        if resource not in get_typing_args(MediaResource):
            raise ValueError(f'TmdbApi.media_resource() got incorrect resource {resource!r}')
        try:
            mtype = cast(MainMediaType, ref.type)
            ctype = self._main2tmdb_type[mtype]
        except KeyError:
            return ItemList.empty()

        params = {'page': page}
        return self._item_list(mtype, self.get(f'{ctype}/{ref.tmdb_id}/{resource}', params=params))

    def media_keywords(self, ref: MediaRef) -> List[FFItem]:
        """Get media (movie, show) resource."""
        if ref.type not in get_typing_args(MainMediaType):
            raise ValueError(f'TmdbApi.media_resource() got incorrect type {ref.type!r}')
        try:
            mtype = cast(MainMediaType, ref.type)
            ctype = self._main2tmdb_type[mtype]
        except KeyError:
            return ItemList.empty()

        return self._item_list(mtype, self.get(f'{ctype}/{ref.tmdb_id}/keywords'), key='keywords', out_type='keyword')

    def user_lists(self, account_id: AccountId = 'me', *, page: int = 1) -> List[FFItem]:
        """Get user lists."""
        if isinstance(account_id, int) and account_id in VideoIds.TMDB:
            account_id = VideoIds.TMDB.index(account_id)
        data = self.get(f'account/{account_id}/lists', params={'page': page})
        return self._item_list('list', data)

    def user_list_items(self, list_id: int, *, page: int = 1) -> ItemList[FFItem]:
        """Get user lists."""
        if isinstance(list_id, int) and list_id in VideoIds.TMDB:
            list_id = VideoIds.TMDB.index(list_id)
        data = self.get(f'list/{list_id}', params={'page': page})
        return self._item_list('', data, key='items')

    def user_general_lists(self,
                           list_type: UserGeneralListType,
                           type: Union[MainMediaType, MainMediaTypeList],
                           account_id: AccountId = 'me',
                           *,
                           page: int = 1,
                           chunk: int = 0,
                           ) -> ItemList[FFItem]:
        """Get user lists."""
        def get(mtype: MainMediaType) -> ItemList[FFItem]:
            if mtype not in get_typing_args(MainMediaType):
                raise ValueError(f'TmdbApi got incorrect type {mtype!r}')
            ctype = self._main2tmdb_type2[mtype]
            data = self.get(f'account/{account_id}/{list_type}/{ctype}', params={'page': page})
            return self._item_list(mtype, data)

        if isinstance(type, str):
            type = type.split(',')
        if not type:
            return ItemList.empty()
        if len(type) == 1:
            return get(type[0])
        with ThreadPoolExecutor(max_thread_workers()) as pool:
            datas: Iterable[ItemList[FFItem]] = pool.map(get, type)
        return ItemList(join_items(*datas, zip_chunk=chunk), page=page, total_pages=max(d.total_pages for d in datas))

    def web_url(self, ref: MediaRef) -> str:
        """Return link to media for humans."""
        if not ref.tmdb_id:
            return ''
        if ref.type == 'show':
            path = '/'.join(f'{k}{v}' for k, v in zip(['tv/', 'season/', 'episode/'], ref.tmdb_tv_tuple))
        elif ref.type in ('movie', 'person', 'collection'):
            path = f'{ref.type}/{ref.tmdb_id}'
        else:
            return ''  # unspurted media type
        return f'https://www.themoviedb.org/{path}'

    # --- Following methods MUST be overrided ---

    def credentials(self) -> TmdbCredentials:
        """Return current credentials."""
        if self.api_key is not None:
            return TmdbCredentials(api_key=self.api_key)
        raise NotImplementedError('api.tmdb.TmdbApi.credentials() is not implemented')

    def set_session_id(self, session_id: Optional[str]) -> None:
        """Set session ID. Override this method and remember session ID or remove if None."""
        print(session_id)


# --- DEBUG & TESTS ---

if __name__ == '__main__':
    import json
    # from pprint import pprint
    from ..ff.cmdline import DebugArgumentParser
    from ..ff import apis
    # from ..ff.settings import settings

    def jprint(data: JsonData) -> None:
        print(json.dumps(data, indent=2))

    def mprint(info: MediaPlayInfoDict) -> None:
        print('{')
        for k, v in info.items():
            # x = str(v).replace(', item_count', ',\n                  item_count')
            x = str(v).replace(', duration', ',\n                  duration')
            print(f'  {k}:\n    {x},')
        print('}')

    def parse_ref(v: str) -> MediaRef:
        if v[:1] in 'Mm':
            return MediaRef('movie', int(v[1:]))
        if v[:1] in 'Ttse':
            return MediaRef('show', *map(int, v[1:].split('/')))
        if v[:1] in 'S':
            return MediaRef('season', int(v[1:]))
        if v[:1] in 'E':
            return MediaRef('episode', int(v[1:]))
        raise ValueError(f'Incorrect media ref {v!r}')

    p = DebugArgumentParser(dest='cmd')
    p.add_argument('--tmdb-api-key', help='TMDB API key, for get extra info')
    with p.with_subparser('movie') as p_mv:
        p_mv.add_argument('id', type=int, help='tmdb movie id')
    with p.with_subparser('tv') as p_tv:
        p_tv.add_argument('id', type=int, help='tmdb tv-show id')
        p_tv.add_argument('season', type=int, nargs='?', help='optional season number')
        p_tv.add_argument('episode', type=int, nargs='?', help='optional episode number')
        p_tv.add_argument('-e', '--tv-episodes', action='store_true', help='episodes data for tv-show (gets seasons)')
    with p.with_subparser('info') as p_in:
        p_in.add_argument('ids', type=parse_ref, nargs='+', help='tmdb refs (m123, s123, s123/4, s123/4/5)')
        p_in.add_argument('-e', '--tv-episodes', action='store_true', help='episodes data for tv-show (gets seasons)')
    args = p.parse_args()
    # print(args); exit()  # DEBUG

    tmdb = TmdbApi(api_key=apis.tmdb_API)

    if args.cmd == 'movie':
        jprint(tmdb.get_media_by_ref(MediaRef('movie', args.id)))
    elif args.cmd == 'tv':
        jprint(tmdb.get_media_by_ref(MediaRef('show', args.id, args.season, args.episode),
                                     tv_episodes=args.tv_episodes))
    elif args.cmd == 'info':
        # pprint(list(tmdb.x_media_play_dict(args.ids, tv_episodes=args.tv_episodes).keys()))
        mprint(tmdb.x_media_play_dict(args.ids, tv_episodes=args.tv_episodes))
