"""
Simple HTTP Proxy for FanFilm Kodi addon
This module starts a simple HTTP proxy server that listens for incoming
HTTP requests and forwards them to an external server, modifying the headers as necessary.
"""

from typing import Optional, Union, Any, Tuple, List, Dict, Set, Iterable, Mapping
from typing import ClassVar, Type, Callable, TYPE_CHECKING
from typing_extensions import TypeAlias, ParamSpec
import sys
import re
from enum import Enum
# from contextlib import closing
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from http import HTTPStatus
from urllib.parse import parse_qsl
import json
from traceback import format_exc
from attrs import define, frozen
if sys.version_info >= (3, 9):
    from random import randbytes
else:
    from random import randint
    def randbytes(n: int) -> bytes:
        return b''.join(bytes((randint(0, 255),)) for _ in range(n))
if TYPE_CHECKING:
    from .trakt import TraktSync
    from .misc import VolatileDbid
    from .main import Works

import requests
import xbmcaddon

from .http_request import RequestHandler, Route, request
from .http_request import HTTPBadRequest, HTTPNotFound, HTTPUnprocessableContent, ExpectedJsonObjectError
from ..ff.control import plugin_id, busy_dialog
from ..ff.settings import settings
from ..ff.log_utils import fflog, fflog_exc
from ..ff.routing import URL  # , Router
from ..ff.threads import Thread, Event, Lock
from ..ff.tricks import MISSING
from ..ff.types import JsonData, JsonResult
from ..ff.db.db import Db, DbManager, DbMode, SqlConnection, SqlCursor
from ..ff.db import state
from ..defs import MediaRef
from const import const

PS = ParamSpec('PS')
RouteResultValue: TypeAlias = Union[JsonResult, str]
RouteResult: TypeAlias = Union[Tuple[int, RouteResultValue], RouteResultValue]

# Initialize addon
addon = xbmcaddon.Addon(id=plugin_id)

Host: TypeAlias = str
Port: TypeAlias = int
Address: TypeAlias = Tuple[Host, Port]
DbClientId: TypeAlias = str


# DEBUG (command line tests)
if __name__ == '__main__':
    from ..ff.cmdline import DebugArgumentParser
    p = DebugArgumentParser()
    p.add_argument('-p', '--port', type=int, default=8123, help='server port')
    p.add_argument('-t', '--threading', action='store_true', help='multithreading / concurent requests')
    args = p.parse_args()


DUMMY_M3U = b'#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:0.500,\n\n#EXT-X-ENDLIST\n'


class SqlMethod(Enum):
    EXECUTE = 'execute'
    EXECUTE_MANY = 'executemany'
    EXECUTE_SCRIPT = 'executescript'
    COMMIT = 'commit'
    ROLLBACK = 'rollback'


@define
class DbClient:
    """Represents single client connection."""
    id: DbClientId
    db: Db
    cursor: SqlCursor


if TYPE_CHECKING:
    class ServerBase(ThreadingHTTPServer):
        pass
elif __name__ == '__main__' and not args.threading:  # DEBUG only !!!
    class ServerBase(HTTPServer):
        pass
else:
    class ServerBase(ThreadingHTTPServer):
        pass


class Server(ServerBase):
    """FanFilm HTTP Server."""

    def __init__(self,
                 server_address: Address,
                 RequestHandlerClass: Type[BaseHTTPRequestHandler],
                 *,
                 works: Optional['Works'] = None,
                 ) -> None:
        super().__init__(server_address, RequestHandlerClass)
        host, port = self.server_address
        self.url = URL(f'http://{host}:{port}/')
        self.db_lock = Lock()
        self.db_conns: Dict[DbClientId, Db] = {}
        self.db_clients: Dict[DbClientId, DbClient] = {}
        self.works: Optional['Works'] = works
        self.events: Dict[str, Event] = {} if works is None else works.events  # no copy - shared events
        self.trakt_sync: Optional['TraktSync'] = works and works.trakt_sync
        self.volatile_dbid: Optional['VolatileDbid'] = works and works.volatile_dbid
        if self.trakt_sync:
            self.events.setdefault('trakt', self.trakt_sync.synced)

    def _get_db_under_lock(self, name: str):
        """Get DB connection. MUST be uner self.lock."""
        try:
            return self.db_conns[name]
        except KeyError:
            pass
        # DB manager is used only for create connection. Do NOT use manage methods here.
        manager = DbManager()
        path = manager._path_for_name(name)
        db = manager._create_connection(name, path, mode=DbMode.SEPARATED)
        self.db_conns[name] = db
        return db

    def _get_db(self, name: str):
        with self.db_lock:
            return self._get_db_under_lock(name)

    def _get_client(self, cid: Optional[DbClientId], name: str) -> DbClient:
        with self.db_lock:
            if cid:
                try:
                    return self.db_clients[cid]
                except KeyError:
                    pass
            while True:
                cid = randbytes(8).hex()
                if cid not in self.db_clients:
                    break
            db = self._get_db_under_lock(name)
            self.db_clients[cid] = client = DbClient(cid, db, db._conn.cursor())
            return client

    @Route.post(r'/db/(?P<name>\w+)/?')
    def db_query(self, name: str) -> JsonResult:
        """Handle SQL query POST."""
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        try:
            cid = data.get('cursor')
            method = SqlMethod(data.get('method', 'execute'))
            if method in (SqlMethod.COMMIT, ):
                query = ''
                params = ()
            else:
                query = data['query']
                if method == SqlMethod.EXECUTE_MANY:
                    params = data['params']
                else:
                    params = data.get('params', ())
        except (KeyError, ValueError):
            raise HTTPUnprocessableContent(message='innorect request')
        client = self._get_client(cid, name)
        with self.db_lock:
            if method is SqlMethod.EXECUTE:
                client.cursor.execute(query, params)
            elif method is SqlMethod.EXECUTE_MANY:
                client.cursor.executemany(query, params)
            elif method is SqlMethod.EXECUTE_SCRIPT:
                client.cursor.executescript(query)
            elif method is SqlMethod.COMMIT:
                client.cursor.connection.commit()
            elif method is SqlMethod.ROLLBACK:
                client.cursor.connection.rollback()
            return {
                'status': 'ok',
                'items': client.cursor.fetchall(),
                'lastrowid': client.cursor.lastrowid,
                'rowcount': client.cursor.rowcount,
            }

    @Route.post(r'/event/(?P<name>[a-zA-Z]\w*)(?:/(?P<action>\w+))?/?')
    def event_request(self, name: str, action: Optional[str] = None) -> JsonResult:
        """Remote service events support."""
        event = self.events.get(name)
        if event is None:
            raise HTTPNotFound(message=f'Event {name!s} not found')
        if not action:
            action = 'get'
        data = {'status': 'ok', 'event': name, 'action': action}
        if action == 'get':
            return data
        elif action == 'wait':
            result = event.wait()
            return {**data, 'state': result}
        elif action == 'set':
            event.set()
            return {**data, 'state': event.is_set()}
        elif action == 'clear':
            event.clear()
            return {**data, 'state': event.is_set()}
        else:
            raise HTTPUnprocessableContent(message=f'Unspotted event action {action!r}')

    @Route.post(r'/trakt/(?P<action>\w+)/?')
    def trakt(self, action: Optional[str] = None) -> JsonResult:
        """Remote service events support."""
        if self.trakt_sync is None:
            raise HTTPUnprocessableContent(message='Trakt not initialized')
        event = self.events.get('trakt')
        if event is None:
            raise HTTPNotFound(message='Event trakt not found')
        if not action:
            action = 'get'
        timeout = request.json.get('timeout') if isinstance(request.json, Mapping) else None
        data = {'status': 'ok', 'action': action}
        if action == 'get':
            return data
        elif action == 'sync':
            status = self.trakt_sync.sync(timeout=timeout)
            return {**data, 'timestamp': status and status.timestamp, 'changed': bool(status and status.changed)}
        elif action == 'wait':
            status = self.trakt_sync.wait_for_sync(timeout=timeout)
            return {**data, 'timestamp': status and status.timestamp, 'changed': bool(status and status.changed)}
        else:
            raise HTTPUnprocessableContent(message=f'Unspotted trakt action {action!r}')

    @Route.get(r'/plugin/request/info/?')
    @Route.get(r'/folder/info/?')
    def get_plugin_request_info(self) -> JsonResult:
        """Get folder info."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        return {
            'status': 'ok',
            'plugin_request': self.works.folder.__to_json__(),
        }

    @Route.post(r'/plugin/request/enter/?')
    @Route.post(r'/folder/enter/?')
    def plugin_request_enter(self) -> JsonResult:
        """Enter into new plugin folder."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if not isinstance(request.json, Mapping):
            raise HTTPUnprocessableContent(message='innorect request, object requested')
        if not (url := request.json.get('url')):
            raise HTTPUnprocessableContent(message='"url" missing')
        self.works.folder.enter(url)
        if const.tune.service.group_update_busy_dialog and self.works.folder.scan_started:
            busy_dialog(True)
        return {
            'status': 'ok',
            'plugin_request': self.works.folder.__to_json__(),
        }

    @Route.post(r'/plugin/request/exit/?')
    @Route.post(r'/folder/exit/?')
    def plugin_request_exit(self) -> JsonResult:
        """Enter into new plugin folder."""
        if not self.works:
            raise HTTPUnprocessableContent(message='Works are not initialized')
        if const.tune.service.group_update_busy_dialog and self.works.folder.scan_finished:
            busy_dialog(False)
        if not isinstance(request.json, Mapping):
            raise HTTPUnprocessableContent(message='innorect request, object requested')
        if (folder := request.json.get('folder', MISSING)) is MISSING:
            raise HTTPUnprocessableContent(message='"folder" missing')
        self.works.folder.exit(folder=folder)
        return {
            'status': 'ok',
            'plugin_request': self.works.folder.__to_json__(),
        }

    # DEBUG only (!!!)
    @Route.post(r'/plugin/request/ready/force/?')
    @Route.post(r'/folder/ready/force/?')
    def folder_force_ready(self, action: str = 'ready') -> JsonResult:
        """Handle folder ready event - force ready only."""
        event = self.events.get('folder')
        if event is None:
            raise HTTPNotFound(message='Event folder not found')
        state = True
        if isinstance(request.json, Mapping):
            state = bool(request.json.get('set', True))
        if state:
            event.set()
        else:
            event.clear()
        # done = event.clear()
        return {
            'status': 'ok',
            'ready': event.is_set(),
        }

    @Route.route(('POST', 'GET'), r'/(?:plugin/request|folder)/(?P<action>ready)/?')
    def folder_ready(self, action: str = 'ready') -> JsonResult:
        """Handle folder ready event."""
        event = self.events.get('folder')
        if event is None:
            raise HTTPNotFound(message='Event folder not found')
        timeout = request.json.get('timeout') if isinstance(request.json, Mapping) else None
        verbose = not event.is_set()
        if verbose:
            fflog('[FOLDER] wait')
        done = event.wait(timeout=timeout)
        if verbose:
            fflog(f'[FOLDER] {done = }')
        return {
            'status': 'ok',
            'ready': done,
        }

    @Route.get(r'/dbid/?')
    def list_dbid(self) -> JsonResult:
        """list all refs (filter by volatile dbid)."""
        if self.volatile_dbid is None:
            raise HTTPBadRequest(message='Volatile DBID is not supported')
        if 'dbid' in request.params:
            dbids = request.params.get('dbid', '')
            filters = {'dbid': dbids}
            refs = [{'dbid': dbid, 'ref': self.volatile_dbid.get(dbid)}
                    for dbid in map(int, dbids.split(','))]
        else:
            filters = {}
            refs = [{'dbid': dbid, 'ref': ref} for dbid, ref in self.volatile_dbid._refs.items()]
        return {
            'status': 'ok',
            'filters': filters,
            'refs': refs,
            }

    @Route.get(r'/dbid/(?P<dbid>\d+)/?')
    def get_dbid(self, dbid: int) -> JsonResult:
        """Get ref by volatile dbid."""
        if self.volatile_dbid is None:
            raise HTTPBadRequest(message='Volatile DBID is not supported')
        if ref := self.volatile_dbid.get(dbid):
            return {
                'status': 'ok',
                'dbid': dbid,
                'ref': ref.as_dict(),
            }
        raise HTTPNotFound(message=f'DBID {dbid} not found')

    @Route.post(r'/dbid/?')
    def create_dbid(self) -> JsonResult:
        """Create new volatile dbid for given ref."""
        if self.volatile_dbid is None:
            raise HTTPBadRequest(message='Volatile DBID is not supported')
        data = request.json
        if not isinstance(data, Mapping):
            raise ExpectedJsonObjectError()
        if refs := data.get('refs'):
            try:
                return {
                    'status': 'ok',
                    'refs': [{'dbid': self.volatile_dbid.register(ref), 'ref': ref.as_dict()}
                             for ref_json in refs if (ref := MediaRef(**ref_json))],
                }
            except TypeError as exc:
                raise HTTPUnprocessableContent(message=f'incorrect `refs` format: {exc}`') from None
        raise HTTPUnprocessableContent(message='`refs` missing')

    # ----- Original old methods (m3u, drm), must be at the end  ----

    @Route.get(r'/stop.m3u8?')
    def stop_m3u(self) -> bytes:
        """Fake player (empty m38u playlist) to avoid error on sources window cancel."""
        return DUMMY_M3U

    @Route.post(r'.*drmcda=(?P<url>.*)')
    def drm(self, url: str) -> bytes:
        """DRM woraround."""
        # def parse_url(self, path, separator):
        #     """
        #     Parse the URL to extract headers and the actual URL to be requested.
        #     """
        #     url = path.split(separator)[-1]
        #     headers = {}
        #     if "@" in url:
        #         url, header_str = url.split('@')
        #         headers = dict(parse_qsl(header_str))
        #     return url, headers
        #  parsed_url, _ = self.parse_url(self.path, 'drmcda=')

        headers = {k: v for k, v in request.headers.items() if k not in ('Host', 'Content-Type')}
        length = int(request.headers.get('Content-Length', 0))
        post_data = request.handler.rfile.read(length)
        print(f'HTTP POST Data {repr(post_data)}')

        headers = dict(request.headers)
        resp = requests.post(url=url, headers=headers, data=post_data, verify=False)
        return resp.content


class Proxy:
    """
    The main function that starts the HTTP Proxy server.
    """

    def __init__(self,
                 *,
                 works: Optional['Works'],
                 ) -> None:
        self._running: bool = False
        self._server: Optional[HTTPServer] = None
        self._httpd_thread: Optional[Thread] = None
        self.works: Optional['Works'] = works

    @property
    def running(self) -> bool:
        return self._running

    def start(self) -> None:
        """Start proxy server (in new therad)."""
        if self._running:
            return

        address = '127.0.0.1'  # Localhost
        try:
            # create HTTP server and start serve in new therad
            self._server = Server((address, RequestHandler.DEFAULT_PORT), RequestHandler, works=self.works)
            self._server.allow_reuse_address = True
            self._httpd_thread = Thread(target=self._server.serve_forever)
            self._httpd_thread.start()
            self._running = True

            # get port number and set server URL in the settings
            # GET.url = POST.url = self._server.url
            state.set('url', str(self._server.url), module='service')
            settings.setString('_proxy_path', str(self._server.url))
            fflog(f'=== Proxy Started: {self._server.url} ===')

        except Exception:
            # creating HTTP server failed, clear URL in the settings
            state.set('url', None, module='service')
            try:
                settings.setString('_proxy_path', '')
            except Exception:
                pass  # skip any exception, spesially RuntimError in FF update/exit
            self._running = False
            fflog_exc()
            raise

    def stop(self):
        """Stop proxy server."""
        if not self._running:
            return

        # shutdown and close the server
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server.socket.close()
            self._server = None
        if self._httpd_thread is not None:
            self._httpd_thread.join()
            self._httpd_thread = None
        self._running = False

        # clear URL in the settings
        state.set('url', None, module='service')
        try:
            settings.setString('_proxy_path', '')
        except Exception:
            pass  # skip any exception, spesially RuntimError in FF update
        fflog('=== Proxy Stopped ===')


if __name__ == '__main__':
    from .misc import VolatileDbid
    from .main import Works
    address = '127.0.0.1'
    works = Works(
        events={
            'folder': Event(),
        },
        volatile_dbid=VolatileDbid()
    )
    works.events['folder'].set()
    server = Server((address, args.port), RequestHandler, works=works)
    server.allow_reuse_address = True
    server.serve_forever()
