
from typing import Optional, Union, List, Dict, Iterator, TYPE_CHECKING
import re
from attrs import define, field, Factory, asdict
from ..defs import MediaRef, VideoIds
from ..ff.calendar import utc_timestamp
from ..ff.url import URL

if TYPE_CHECKING:
    from ..ff.types import JsonData


def _parse_url(value) -> URL:
    if isinstance(value, str):
        return URL(value)
    return value


def _serialize(inst, field, value):
    # if isinstance(value, datetime.datetime):
    #     return value.isoformat()
    if isinstance(value, URL):
        return str(value)
    return value


@define
class VolatileDbid:
    """Volatile DBID, defined for single kodi session only."""

    _refs: Dict[int, MediaRef] = Factory(dict)
    _ids: Dict[MediaRef, int] = Factory(dict)
    _generator: Iterator[int] = field(init=False, factory=VideoIds.VOLATILE.__iter__)

    def next_dbid(self) -> int:
        """Get next volatile dbid."""
        try:
            return next(self._generator)
        except StopIteration:
            self._generator = iter(VideoIds.VOLATILE)
        return next(self._generator)

    def register(self, ref: MediaRef) -> int:
        """Register new value."""
        if dbid := self._ids.get(ref):
            return dbid
        dbid = self.next_dbid()
        self._ids[ref] = dbid
        self._refs[dbid] = ref
        return dbid

    def get(self, dbid: int) -> Optional[MediaRef]:
        """Return ref by `dbid` or None if not exists."""
        return self._refs.get(dbid)


@define
class FolderHistoryItem:
    """One item if the folder history."""

    #: Folder URL.
    url: URL = field(converter=_parse_url)
    #: Folder enter UTC timestamp.
    enter_timestamp: float = 0
    #: Folder exit UTC timestamp.
    exit_timestamp: float = 0

    def __to_json__(self) -> 'JsonData':
        """Serialize object to JSON."""
        return asdict(self, value_serializer=_serialize)

    @classmethod
    def __from_json__(cls, data: 'JsonData') -> 'FolderHistoryItem':
        """Create object from JSON."""
        return FolderHistoryItem(**data)


@define
class PluginRequestInfo:
    """FF plugin URL enter info (folder, videos, scripts etc.)."""
    #: Folder history.
    history: List[FolderHistoryItem] = Factory(list)
    #: True, if refresh is detected.
    refresh: bool = False
    #: True, if kodi folder is scaned (tree scan is detected).
    scan: bool = False
    #: True, if kodi folder tree scan is just detected.
    scan_started: bool = False
    #: True, if kodi folder tree scan is just stoped (enter to `scan_url`, folder before scan started)
    scan_finished: bool = False
    #: Keep URL, when scanning is detected (folder before scan started).
    scan_url: URL = field(default=URL(''), converter=_parse_url)
    #: Main media URL (e.g. tvshow).
    media_url: URL = field(default=URL(''), converter=_parse_url)
    #: Last folder info (not video or else).
    folder_url: URL = field(default=URL(''), converter=_parse_url)

    @property
    def url(self) -> URL:
        """Current folder URL (first item from the history)."""
        if not self.history:
            return URL('')
        return self.history[0].url

    def __to_json__(self) -> 'JsonData':
        """Serialize object to JSON."""
        return asdict(self, recurse=True, value_serializer=_serialize)

    @classmethod
    def __from_json__(cls, data: 'JsonData') -> 'PluginRequestInfo':
        """Create object from JSON."""
        data = dict(data)
        data['history'] = [FolderHistoryItem.__from_json__(it) for it in data['history']]
        return PluginRequestInfo(**data)

    def enter(self, url: Union[URL, str]) -> None:
        """Enter into folder, add new URL."""
        if isinstance(url, str):
            url = URL(url)
        if self.history and not self.history[0].exit_timestamp:
            self.history[0].exit_timestamp = utc_timestamp()
        self.history.insert(0, FolderHistoryItem(url, enter_timestamp=utc_timestamp()))
        if len(self.history) > 10:
            self.history = self.history[:10]
        # simple refresh
        if len(self.history) >= 2:
            self.refresh = self.history[0].url in (self.history[1].url, self.scan_url, self.folder_url)
        # interval between folder exit and enter into next onw
        interval = 2.0
        # scanning by kodi, detected when history is (from newwst):
        #   - [0] SHOW/2
        #   - [1] SHOW/1
        #   - [2] SHOW
        #   - [3] some list of shows
        if len(self.history) >= 4:
            hist = self.history
            path0 = self.history[0].url.path
            path1 = self.history[1].url.path
            path2 = self.history[2].url.path
            path3 = self.history[3].url.path
            if (not re.fullmatch(r'/tvshow/\d+/?.*', path3)                               # shows (no show / season view)
                    and '/tvshow' in path2 and path2.rpartition('/')[2].isdigit()         # show view
                    and path1 == f'{path2}/1'                                             # first season
                    and path0 == f'{path2}/2'                                             # second season
                    and hist[2].exit_timestamp - hist[1].enter_timestamp <= interval      # fast enter into first season
                    and hist[1].exit_timestamp - hist[0].enter_timestamp <= interval      # fast enter into second season
               ):
                self.scan_started = True
                self.scan = True
                self.scan_url = self.history[3].url  # folder before scan started
                self.media_url = self.history[2].url  # scanned folder
        # scan is stopped / aborted if more time to enter into current folder
        if self.scan and self.history[1].exit_timestamp - self.history[0].enter_timestamp > interval:
            self.scan = False
        if self.scan and self.refresh:
            self.scan = False
            self.scan_finished = True

    def exit(self, *, folder: bool = True) -> None:
        """Exit from folder."""
        if self.history:
            self.history[0].exit_timestamp = utc_timestamp()
            if folder:
                self.folder_url = self.history[0].url
        self.scan_started = False
        self.scan_finished = False
