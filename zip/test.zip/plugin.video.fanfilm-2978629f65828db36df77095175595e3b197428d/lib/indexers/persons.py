
from typing import Optional, List

from .core import Indexer, Job
from .search import Search
from ..ff.info import ffinfo
from ..ff.routing import route, subobject, RouteObject, url_for, PathArg
from ..ff.menu import KodiDirectory, directory, ContextMenuItem
from ..ff.item import FFItem
from ..ff.tmdb import tmdb
from ..defs import MediaRef
from ..kolang import L


class Persons(RouteObject, Indexer):
    """Persons navigation (a little bit degraded)."""

    MODULE = 'persons'
    TYPE = 'person'
    VIEW = 'actors'

    @subobject
    def search(self) -> 'Search':
        """Search submodule."""
        return Search(indexer=self, type='person')

    def do_show_item(self, kdir: KodiDirectory, it: FFItem, *, alone: bool, link: bool, menu: List[ContextMenuItem]) -> None:
        """Process discover item. Called from discover()."""
        it.label = f'{it.title}'
        it.mode = it.Mode.Folder
        it.url = str(url_for(self.person, person_id=it.dbid))
        kdir.add(it, menu=menu)

    @route('/')
    def person(self, person_id: PathArg[int]) -> None:
        """Show person."""
        ref = MediaRef.person(person_id)
        it = ffinfo.get_item(ref)
        if it is None:
            return self.no_content()
        it.mode = it.Mode.Separator
        it.label = f'[B]{it.title}[/B]'
        with directory(view='artists') as kdir:
            kdir.add(it, url=kdir.no_op)
            kdir.folder(L(32001, 'Movies'), url_for(self.movie, person_id=person_id),
                        thumb='movies.png', icon='DefaultMovies.png')
            kdir.folder(L(32002, 'TV Shows'), url_for(self.tvshow, person_id=person_id),
                        thumb='tvshows.png', icon='DefaultTVShows.png')
            kdir.folder(L(30178, 'Director'), url_for(self.crew, person_id=person_id, job='director'))
            kdir.folder(L(30179, 'Producer'), url_for(self.crew, person_id=person_id, job='producer'))

    @route('/{person_id}/movie')
    def movie(self, person_id: int, page: PathArg[int] = 1) -> None:
        from .navigator import nav
        credits = tmdb.person_credits(person_id, 'movie_credits')
        return nav.show_items(credits.cast)

    @route('/{person_id}/tvshow')
    def tvshow(self, person_id: int, page: PathArg[int] = 1) -> None:
        from .navigator import nav
        credits = tmdb.person_credits(person_id, 'tv_credits')
        return nav.show_items(credits.cast)

    @route('/{person_id}/crew')
    def crew(self, person_id: int, job: Optional[PathArg[Job]] = None) -> None:
        from .navigator import nav
        credits = tmdb.person_credits(person_id, 'combined_credits')
        jobs = self._jobs.get(job, set())
        if jobs:
            crew = [c for c in credits.crew if c.role in jobs]
        else:
            crew = [c for c in credits.crew if c.role != 'Thanks']
        return nav.show_items(crew)
