# -*- coding: utf-8 -*-

"""
    Fanfilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

raise AssertionError(f'Do NOT use this module {__name__}')

from lib.ff import bookmarks, control, trakt
from lib.ff.log_utils import fflog


def getMovieIndicators(refresh=False, timeout=None):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()
        if timeout and not refresh:
            pass
        elif not refresh:
            timeout = 720
        else:
            timeout = 0
        indicators = trakt.syncMovies()
        return indicators
    except Exception:
        pass


def getTVShowIndicators(refresh=False, timeout=None):
    assert False
    #   try:
    #         if trakt.trakt_credentials_manager.indicators_info == True: raise Exception()
    #         indicators_ = bookmarks._indicators()
    #         return indicators_
    #   except:
    #         pass
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()
        if timeout and not refresh:
            pass
        elif not refresh:
            timeout = 720
        #        elif trakt.getWatchedActivity() < trakt.timeoutsyncTVShows():
        #            timeout = 720
        else:
            timeout = 0
        indicators = trakt.syncTVShows()
        return indicators
    except:
        pass


def getSeasonIndicators(imdb):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()
        indicators = trakt.syncSeason(imdb)
        return indicators
    except:
        pass


def getEpisodeIndicators(imdb):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()
        indicators = trakt.syncEpisode(imdb)
        return indicators
    except:
        pass


def getMovieOverlay(indicators, imdb=None, tmdb=None):
    assert False
    try:
        if trakt.trakt_credentials_manager.indicators_info:
            is_fully_watched = any(i == imdb for i in indicators)
            return "7" if is_fully_watched else "6"
        else:
            return str(bookmarks._get_watched("movie", imdb))
    except Exception:
        return "6"


def getTVShowOverlay(indicators, imdb=None, tmdb=None):
    assert False
    try:
        if trakt.trakt_credentials_manager.indicators_info:
            is_fully_watched = any(
                i[0] == tmdb and len(i[2]) >= int(i[1]) for i in indicators
            )
            return "7" if is_fully_watched else "6"
        else:
            return str(bookmarks._get_watched("tvshow", imdb))
    except Exception:
        return "6"


def getSeasonOverlay(indicators, season, imdb=None, tmdb=None):
    assert False
    try:
        if trakt.trakt_credentials_manager.indicators_info:
            is_fully_watched = any(int(season) == int(i) for i in indicators)
            return "7" if is_fully_watched else "6"
        else:
            return str(bookmarks._get_watched("season", imdb, season, ""))
    except Exception:
        return "6"


def getEpisodeOverlay(indicators, season, episode, imdb=None, tmdb=None):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            # fflog(f"Local overlay {imdb}")
            return str(bookmarks._get_watched("episode", imdb, season, episode))
        else:
            # fflog(f"Trakt overlay {imdb}")
            # Sprawdzanie, czy istnieje krotka (season, episode) w liście wskaźników
            is_tuple_watched = (int(season), int(episode)) in indicators
            # Sprawdzanie, czy istnieje lista [season, episode] w liście wskaźników
            is_list_watched = [int(season), int(episode)] in indicators

            return "7" if (is_tuple_watched or is_list_watched) else "6"
    except Exception:
        return "6"


def markMovieDuringPlayback(imdb, watched):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()

        if int(watched) == 7:
            trakt.markMovieAsWatched(imdb)
        else:
            trakt.markMovieAsNotWatched(imdb)
        trakt.syncMovies(refreshCache=True)

        if trakt.getTraktAddonMovieInfo():
            trakt.markMovieAsNotWatched(imdb)
    except:
        pass


def markEpisodeDuringPlayback(imdb, tmdb, season, episode, watched):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()

        if int(watched) == 7:
            trakt.markEpisodeAsWatched(imdb, season, episode)
        else:
            trakt.markEpisodeAsNotWatched(imdb, season, episode)
        trakt.syncTVShows(refreshCache=True)

        if trakt.getTraktAddonEpisodeInfo():
            trakt.markEpisodeAsNotWatched(imdb, season, episode)
    except:
        pass


def movies(imdb=None, watched=None, tmdb=None, refresh=False, current_time=1, total_time=1):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()
        if int(watched) == 7:
            fflog(
                f"Próba oznaczenia filmu {imdb or tmdb} jako obejrzanego w trakt"
            )
            trakt.markMovieAsWatched(imdb, tmdb=tmdb)
        else:
            fflog(
                f"Próba oznaczenia filmu {imdb or tmdb} jako nieobejrzanego w trakt",
            )
            trakt.markMovieAsNotWatched(imdb, tmdb=tmdb)
        trakt.syncMovies(refreshCache=True)
    except:
        pass

    try:
        if int(watched) == 7 and imdb:
            fflog(
                f"Próba oznaczenia filmu o imdb {imdb} jako obejrzanego w fanfilm",

            )
            # Reset the bookmark for the movie
            bookmarks.reset(current_time, total_time, "movie", imdb)
        else:
            fflog(
                f"Próba oznaczenia filmu o imdb {imdb} jako nieobejrzanego w fanfilm",
            )
            bookmarks._delete_record("movie", imdb)
    except:
        pass

    if refresh:
        control.refresh()


def episodes(
    imdb=None, tmdb=None, season=None, episode=None, watched=None, refresh=False, current_time=1, total_time=1
):
    assert False
    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()
        if int(watched) == 7:
            fflog(
                f"Próba oznaczenia odcinka {episode} sezonu {season} dla {imdb or tmdb} jako obejrzanego w trakt"
            )
            trakt.markEpisodeAsWatched(imdb, season, episode, tmdb=tmdb)
        else:
            fflog(
                f"Próba oznaczenia odcinka {episode} sezonu {season} dla {imdb or tmdb} jako nieobejrzanego w trakt"
            )
            trakt.markEpisodeAsNotWatched(imdb, season, episode, tmdb=tmdb)
        trakt.syncTVShows(refreshCache=True)
    except:
        pass

    try:
        if int(watched) == 7 and imdb:
            fflog(
                f"Próba oznaczenia odcinka {episode} sezonu {season} dla imdb {imdb} jako obejrzanego w fanfilm"
            )
            # Reset the bookmark for the movie
            bookmarks.reset(current_time, total_time, "episode", imdb, season, episode)
        else:
            fflog(
                f"Próba oznaczenia odcinka {episode} sezonu {season} dla imdb {imdb} jako nieobejrzanego w fanfilm"
            )
            bookmarks._delete_record("episode", imdb, season, episode)
    except:
        pass

    if refresh:
        control.refresh()


def tvshows(tvshowtitle, imdb, tmdb, season, watched):
    assert False
    #
    try:
        import sys

        if trakt.trakt_credentials_manager.indicators_info is not False:
            raise Exception()

        from lib.indexers import episodes

        name = control.addonInfo("name")

        dialog = control.progressDialogBG()
        dialog.create(str(name), str(tvshowtitle))
        dialog.update(0, str(name), str(tvshowtitle))

        # fflog('playcount_season: ' + str(season))
        items = []
        if season:
            items = episodes.episodes().get(imdb, tmdb, season=season, idx=False)
            items = [
                i
                for i in items
                if int("%01d" % int(season)) == int("%01d" % int(i["season"]))
            ]
            items = [
                {
                    "label": "%s S%02dE%02d"
                    % (tvshowtitle, int(i["season"]), int(i["episode"])),
                    "season": int("%01d" % int(i["season"])),
                    "episode": int("%01d" % int(i["episode"])),
                    "unaired": i["unaired"],
                }
                for i in items
            ]

            for i in range(len(items)):
                if control.monitor().abortRequested():
                    return sys.exit()

                dialog.update(
                    int((100 / float(len(items))) * i),
                    str(name),
                    str(items[i]["label"]),
                )

                _season, _episode, unaired = (
                    items[i]["season"],
                    items[i]["episode"],
                    items[i]["unaired"],
                )
                if int(watched) == 7:
                    if not unaired == "true":
                        fflog(
                            f"Próba oznaczenia odcinka "
                            f"{_episode} sezonu {_season} dla imdb {imdb} jako obejrzanego "
                            f"w fanfilm"
                        )
                        bookmarks.reset(1, 1, "episode", imdb, _season, _episode)
                    else:
                        pass
                else:
                    fflog(
                        f"Próba oznaczenia odcinka "
                        f"{_episode} sezonu {_season} dla imdb {imdb} jako nieobejrzanego "
                        f"w fanfilm"
                    )
                    bookmarks._delete_record("episode", imdb, _season, _episode)
                    bookmarks._delete_record("season", imdb, _season, _episode)

        else:
            seasons = episodes.seasons().get(imdb, tmdb, idx=False)
            seasons = [i["season"] for i in seasons]
            # fflog('playcount_seasons: ' + str(seasons))
            for s in seasons:
                items = episodes.episodes().get(imdb, tmdb, season=s, idx=False)
                items = [
                    {
                        "label": "%s S%02dE%02d"
                        % (tvshowtitle, int(i["season"]), int(i["episode"])),
                        "season": int("%01d" % int(i["season"])),
                        "episode": int("%01d" % int(i["episode"])),
                        "unaired": i["unaired"],
                    }
                    for i in items
                ]
                # fflog('playcount_items2: ' + str(items))

                for i in range(len(items)):
                    if control.monitor().abortRequested():
                        return sys.exit()

                    dialog.update(
                        int((100 / float(len(items))) * i),
                        str(name),
                        str(items[i]["label"]),
                    )

                    _season, _episode, unaired = (
                        items[i]["season"],
                        items[i]["episode"],
                        items[i]["unaired"],
                    )
                    if int(watched) == 7:
                        if not unaired == "true":
                            fflog(
                                f"Próba oznaczenia odcinka "
                                f"{_episode} sezonu {_season} dla imdb {imdb} jako obejrzanego "
                                f"w fanfilm"
                            )
                            bookmarks.reset(1, 1, "episode", imdb, _season, _episode)
                        else:
                            pass
                    else:
                        fflog(
                            f"Próba oznaczenia odcinka "
                            f"{_episode} sezonu {_season} dla imdb {imdb} jako nieobejrzanego "
                            f"w fanfilm"
                        )
                        bookmarks._delete_record("episode", imdb, _season, _episode)
        if not season:
            if int(watched) == 7:
                fflog(
                    f"Próba oznaczenia serialu "
                    f"dla imdb {imdb} jako obejrzanego "
                    f"w fanfilm"
                )
                bookmarks.reset(1, 1, "tvshow", imdb)
            else:
                fflog(
                    f"Próba oznaczenia serialu "
                    f"dla imdb {imdb} jako nieobejrzanego "
                    f"w fanfilm"
                )
                bookmarks._delete_record("tvshow", imdb)

        try:
            dialog.close()
        except:
            pass
    except:
        fflog("playcount_local_shows")
        try:
            dialog.close()
        except:
            pass

    try:
        if not trakt.trakt_credentials_manager.indicators_info:
            raise Exception()

        # fflog('playcount_season: ' + str(season))
        if season:
            if int(watched) == 7:
                trakt.markSeasonAsWatched(imdb, season)
            else:
                trakt.markSeasonAsNotWatched(imdb, season)
        else:
            if int(watched) == 7:
                trakt.markTVShowAsWatched(imdb)
            else:
                trakt.markTVShowAsNotWatched(imdb)
        trakt.syncTVShows(refreshCache=True)
    except:
        fflog("playcount_trakt_shows")
        pass

    control.refresh()
