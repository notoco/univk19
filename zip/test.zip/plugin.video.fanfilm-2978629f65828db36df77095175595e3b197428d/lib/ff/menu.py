"""Menu and Kodi list directory support."""

from typing import Optional, Any, Union, Tuple, List, Dict, Set, Sequence, Iterable, Iterator, Callable, ClassVar
from typing_extensions import Literal, TypedDict, Unpack, NotRequired, TypeAlias
from contextlib import contextmanager
from pathlib import Path
import re
from attrs import define

from xbmcplugin import addDirectoryItems, endOfDirectory
from xbmcplugin import setContent as setContentView

from .log_utils import fflog_exc
from .routing import URL, url_for, url_proxy, subobject, route, RouteObject, find_dispatched_call
from .item import FFItem, FMode, SortPosition
from .kotools import xsleep
from .db.state import save_directory
from . import control
from .types import PagedItemList
from ..service.client import service_client
from ..service.misc import PluginRequestInfo
from ..kolang import L
from .control import addonFanart, update as folder_update
from const import const


Target: TypeAlias = Union[None, str, URL, Callable[..., None], RouteObject]
ContextMenuItem: TypeAlias = Tuple[str, Target]
ContextMenu: TypeAlias = Iterable[ContextMenuItem]

#: Folder content view type.
ContentView: TypeAlias = Literal[
    # - from xbmcplugin.setContent()
    #   albums, artists, episodes, files, games, images, movies, musicvideos, songs, tvshows, videos,
    'albums', 'artists', 'episodes', 'files', 'games', 'images', 'movies', 'musicvideos', 'songs', 'tvshows', 'videos',
    # - from Container.Content()
    #   actors, albums, artists, directors, episodes, files, genres, movies, musicvideos, playlists, plugins,
    #   seasons, sets, songs, studios, tags, tvshows, years,
    'actors', 'directors', 'genres', 'playlists', 'plugins', 'seasons', 'sets', 'studios', 'tags', 'years',
    # - extra well known types
    'addons',
]

art_path: Path = Path(control.art_path)


@route
def _no_operation() -> None:
    """No operation (separator)."""


class CMenu(ContextMenuItem):
    """Single context-menu item with some extra stuff."""

    visible: bool

    def __new__(cls, label: str, target: Target, *, visible: bool = True) -> 'CMenu':
        obj = super().__new__(cls, (label, target))
        obj.visible = visible
        return obj


class KodiDirectoryKwArgs(TypedDict):
    """Arguments for KodiDirectory() for better typing."""
    view: NotRequired[ContentView]
    prefix: NotRequired[str]
    update: NotRequired[bool]
    thumb: NotRequired[Optional[str]]
    icon: NotRequired[Optional[str]]
    poster: NotRequired[Optional[str]]
    landscape: NotRequired[Optional[str]]
    banner: NotRequired[Optional[str]]
    fanart: NotRequired[Optional[str]]
    autoformat: NotRequired[bool]
    style: NotRequired[Optional[str]]


class KodiDirectoryAddArgs(TypedDict):
    """Arguments for KodiDirectory() create items functions."""
    thumb: NotRequired[Optional[str]]
    icon: NotRequired[Optional[str]]
    poster: NotRequired[Optional[str]]
    landscape: NotRequired[Optional[str]]
    banner: NotRequired[Optional[str]]
    fanart: NotRequired[Optional[str]]
    style: NotRequired[Optional[str]]
    descr: NotRequired[str]
    position: NotRequired[SortPosition]
    menu: NotRequired[Optional[Iterable[Tuple[str, Target]]]]
    role: NotRequired[Optional[str]]


class KodiDirectory:
    """Kodi list directory used in with statement."""

    #: Current folder info (url, refreshing, history...).
    INFO: ClassVar[PluginRequestInfo] = PluginRequestInfo()
    #: Current folder URL.
    REFRESH_DONE: ClassVar[bool] = False
    #: True if folder is created (KodiDirectory is used).
    CREATED: ClassVar[bool] = False

    #: Format for future item (unaired, non-premiered).
    FUTURE_FORMAT: ClassVar[Optional[str]] = const.folder.style.future
    #: Format for item with role.
    ROLE_FORMAT: ClassVar[Optional[str]] = const.folder.style.role
    #: Format for broken items (eg. not found in TMDB). Eg. '{} [COLOR red]![/COLOR]'
    BROKEN_FORMAT: ClassVar[Optional[str]] = const.folder.style.broken

    _DEBUG_PRINT_LIST: ClassVar[bool] = False

    _rx_menu_target = re.compile(r'[^(]*://')

    def __init__(self,
                 *,
                 view: ContentView = 'addons',
                 prefix: str = '',
                 update: bool = False,
                 thumb: Optional[str] = None,
                 icon: Optional[str] = None,
                 poster: Optional[str] = None,
                 landscape: Optional[str] = None,
                 banner: Optional[str] = None,
                 fanart: Optional[str] = None,
                 autoformat: bool = True,
                 style: Optional[str] = None,
                 menu_top: Optional[Iterable[Tuple[str, Target]]] = None,
                 menu_bottom: Optional[Iterable[Tuple[str, Target]]] = None,
                 ) -> None:
        import sys  # XXX 
        #: Directory view type.
        self.view: str = view
        #: URL prefix for all added actions.
        self.prefix: str = prefix
        #: Update the listing (updateListing=True).
        self.update: bool = update
        #: Plugin handle.
        self.handle: int = int(sys.argv[1])  # 0  XXX
        #: Added items.
        self.items: List[FFItem] = []
        #: Auto-format (ex. unaired).
        self.autoformat = bool(autoformat)
        #: Style format.
        self.style: Optional[str] = style
        #: Context menu (append on top).
        self.menu_top: List[Tuple[str, Target]] = list(menu_top or ())
        #: Context menu (append on botom).
        self.menu_bottom: List[Tuple[str, Target]] = list(menu_bottom or ())
        #: Menu of last item.
        self._last_item_menu: Optional[ContextMenu] = None
        #: Set of handled items to avoid format dubplications, key: id(FFItem).
        self._handled_items: Set[int] = set()
        # --- default settings ---
        if fanart is None:
            fanart = addonFanart()
        #: Art images.
        self.images: Dict[str, Optional[str]] = {
            'thumb': thumb,
            'icon': icon,
            'poster': poster,
            'landscape': landscape,
            'banner': banner,
            'fanart': fanart,
        }

    @classmethod
    def ready_for_data(cls) -> bool:
        """
        Checks service if everyfing is ready.

        Only trakt sync on refreshing is supported now.
        """
        from .log_utils import fflog  # XXX
        if cls.INFO.refresh and const.folder.refresh_delay:
            fflog('sleep before refresh')
            xsleep(const.folder.refresh_delay)
        if cls.INFO.refresh and not cls.REFRESH_DONE:
            fflog('wait for refresh')
            ok = service_client.foler_ready()
            fflog(f'folder ready: {ok=}')
            cls.REFRESH_DONE = True
        return True

    @classmethod
    def set_current_info(cls, info: 'PluginRequestInfo') -> None:
        cls.INFO = info
        cls.REFRESH_DONE = False
        cls.CREATED = False

    def close(self) -> None:
        """Close the directory (endDirectory)."""
        if self.view:
            setContentView(self.handle, self.view)
        if self.items:
            if self._DEBUG_PRINT_LIST:
                print('\n'.join(f'  {it.url:50s} {it}' for it in self.items))
            items = [(item.url or '', item, item.isFolder()) for item in self.items]
            addDirectoryItems(self.handle, items, len(self.items))
        endOfDirectory(self.handle, updateListing=self.update, cacheToDisc=const.folder.cache_to_disc)
        self.__class__.CREATED = True
        # save folder to DB
        if const.folder.db_save:
            save_directory(str(self.INFO.url), self.items)

    def _make_url(self, target: Target) -> str:
        """Make URL string from URL or target method."""
        url: Optional[str]
        if target is None:
            return self.no_op_url
        if isinstance(target, URL):
            target = str(target)
        if isinstance(target, str):
            url = target
        elif isinstance(target, subobject) and self.prefix:
            url = str(url_for(self.prefix, target))
        else:
            url = str(url_for(target))
        return url

    def _menu_target(self, target: Target) -> str:
        url = self._make_url(target)
        if self._rx_menu_target.match(url):
            url = f'RunPlugin({url})'
        return url

    def add(self, item: FFItem, *, url: Optional[Target] = None, **kwargs: Unpack[KodiDirectoryAddArgs]) -> None:
        """Add new item (folder / action)."""
        if url is not None:
            item.url = self._make_url(url)
        self._set_item(item, **kwargs)
        self.items.append(item)

    def _set_item(self, ffitem: FFItem, enable_art: bool = True, enable_format: bool = True,
                  **kwargs: Unpack[KodiDirectoryAddArgs]) -> None:
        """Fill item with extra arguments."""
        if enable_art:
            mn_art, it_art = {}, ffitem.getArt()
            if fallback := const.folder.fanart_fallback:
                if ffitem.ref.type == 'show' and 'tvshow.fanart' not in it_art:
                    for key in (f'tvshow.{fallback}', fallback):
                        if img := it_art.get(key):
                            it_art.setdefault('tvshow.fanart', img)
                            break
                if 'fanart' not in it_art:
                    for key in ('tvshow.fanart', f'tvshow.{fallback}', 'tvshow.landscape', fallback):
                        if img := it_art.get(key):
                            it_art.setdefault('fanart', img)
                            break
            for nm, img in self.images.items():
                if img := kwargs.get(nm, it_art.get(nm) or img):
                    if '://' not in img:
                        path = art_path / img
                        if path.exists():
                            img = str(path)
                    mn_art[nm] = img
            ffitem.setArt({**mn_art, **it_art})
        if role := kwargs.get('role'):
            ffitem.role = role
        if id(ffitem) not in self._handled_items:  # only first time
            if enable_format and self.autoformat:
                if ffitem.unaired and self.FUTURE_FORMAT:
                    ffitem.label = self.FUTURE_FORMAT.format(ffitem.label, item=ffitem)
                if ffitem.role and self.ROLE_FORMAT:
                    ffitem.label = self.ROLE_FORMAT.format(ffitem.label, item=ffitem)
                if ffitem.broken and self.BROKEN_FORMAT:
                    ffitem.label = self.BROKEN_FORMAT.format(ffitem.label, item=ffitem)
            if style := kwargs.get('style', self.style):
                ffitem.label = style.format(ffitem.label, item=ffitem)
            if descr := kwargs.get('descr'):
                ffitem.vtag.setPlot(descr)
            if ffitem.descr_style:
                ffitem.vtag.setPlot(ffitem.descr_style.format(ffitem.vtag.getPlot(), item=ffitem))
        menu: Optional[ContextMenu] = kwargs.get('menu')
        menu = (*self.menu_top, *(menu or ()), *self.menu_bottom)
        if const.debug.crash_menu:
            from ..main import crash
            menu = (('CRASH', url_for(crash)), *(menu or ()))
        if menu:
            # filter out context-menu items with visible == False
            menu = tuple(m for m in menu if getattr(m, 'visible', True))
        if menu:
            self._last_item_menu = tuple(menu)
            ffitem.addContextMenuItems([(label, self._menu_target(target)) for label, target in menu])
        self._handled_items.add(id(ffitem))

    def folder(self, label: str, target: Optional[Target], **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new folder menu."""
        item = FFItem(label, mode=FMode.Folder, url=self._make_url(target))
        self.add(item, **kwargs)
        return item

    def action(self, label: str, action: Union[str, Target], **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new folder menu."""
        if isinstance(action, str):
            url = self.no_op_url
        else:
            url = self._make_url(action)
        item = FFItem(label, mode=FMode.Command, url=url)
        self.add(item, **kwargs)
        return item

    def play(self, label: str, target: Optional[Target], **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new folder menu."""
        item = FFItem(label, mode=FMode.Playable, url=self._make_url(target))
        self.add(item, **kwargs)
        return item

    def separator(self, label: str = '———————', **kwargs: Unpack[KodiDirectoryAddArgs]) -> FFItem:
        """Add new seaparator / label menu. No any operation."""
        item = FFItem(label, mode=FMode.Separator, url=str(url_for(_no_operation)))
        self.add(item, **kwargs)
        return item

    @contextmanager
    def item_mutate(self) -> Iterator['KodiDirectoryMutate']:
        """With context for mustate (modify) added items."""
        yield KodiDirectoryMutate(self, len(self.items))

    no_op = staticmethod(_no_operation)

    no_op_url = str(url_for(_no_operation))


@define
class KodiDirectoryMutate:
    """With context for mutate (modify) added items."""
    kdir: KodiDirectory
    index: int = 0

    @property
    def items(self) -> Sequence[FFItem]:
        """Return new added items."""
        return self.kdir.items[self.index:]

    @property
    def item(self) -> Optional[FFItem]:
        """Return last new added item."""
        assert self.index >= 0
        if len(self.kdir.items) > self.index:
            return self.kdir.items[-1]
        return None

    @property
    def menu(self) -> Optional[List[ContextMenuItem]]:
        """Menu of last new added item."""
        assert self.index >= 0
        if len(self.kdir.items) > self.index:
            return list(self.kdir._last_item_menu or ())
        return None

    @menu.setter
    def menu(self, menu: ContextMenu) -> None:
        if not (item := self.item):
            raise IndexError('No item to mutate')
        self.kdir._set_item(item, enable_art=False, enable_format=False, menu=menu)


@contextmanager
def directory(items: Optional[PagedItemList] = None,  # optional items get pagination
              *,
              # Extra arguments for "next page" routing, next page url_for().
              route_args: Optional[Dict[str, Any]] = None,
              # All KodiDirectoryKwArgs arguments.
              **kwargs: Unpack[KodiDirectoryKwArgs]) -> Iterator[KodiDirectory]:
    kdir = KodiDirectory(**kwargs)
    if kdir.handle == -1 and const.folder.script_autorefresh:  # called as script
        import sys
        folder_update(str(url_for()))
        sys.exit()
    kdir.ready_for_data()
    if route_args is None:
        route_args = {}
    try:
        def show_page_item(*, go_next: bool) -> None:
            if not items or not hasattr(items, 'page') or not (page := items.page):
                return  # no page api
            if go_next:
                next_page = items.next_page() if hasattr(items, 'next_page') else page + 1
                icon = 'poster_next.jpg'
                landscape = 'landscape.jpg'
                label = L(32053, '[I]Next page[/I]')
            else:
                if const.folder.previous_page == 'never':
                    return
                next_page = page - 1
                icon = 'poster_prev.jpg'
                landscape = 'landscape_prev.jpg'
                label = L(30239, '[I]Previous page[/I]')
            if not next_page:  # out of range
                return
            if hasattr(items, 'total_pages'):
                total_pages = min(items.total_pages, const.folder.max_page_jump or 10*9)
                descr = L(30125, 'Go to page {page} / {total_pages}').format(page=next_page, total_pages=total_pages)
                if go_next is False and const.folder.previous_page == 'on_last_page' and page + 1 < total_pages:
                    return
            else:
                total_pages = 0
                descr = L(30240, 'Go to page {page}').format(page=next_page)
            kdir.folder(label, url_for(page=next_page, **route_args), icon=icon,
                        thumb=icon, banner=icon, poster=icon, landscape=landscape, descr=descr, menu=[
                            CMenu(L(30241, 'First page'), url_for(page=1, **route_args), visible=page > 1),
                            CMenu(L(30242, 'Jump to page...'), url_proxy(jump_to_page, page=page, total_pages=total_pages), visible=total_pages > 3),
                            CMenu(L(30243, 'Last page'), url_for(page=total_pages, **route_args), visible=page + 1 < total_pages),
                        ])

        show_page_item(go_next=False)
        yield kdir
        show_page_item(go_next=True)
    except Exception:
        fflog_exc()
    finally:
        kdir.close()


@route('/jumping_to_page/{page}/{total_pages}/{url}')
def jump_to_page(url: URL, page: int, total_pages: int, **kwargs) -> None:
    """Proxy to jump to page with page number dialog."""

    from xbmcgui import Dialog
    ShowAndGetNumber = 0

    if call := find_dispatched_call(url.with_query(kwargs)):
        total_pages = min(total_pages, const.folder.max_page_jump or 10*9)
        heading = L(30244, 'Enter page number (1..{total_pages})').format(page=page, total_pages=total_pages)
        if snum := Dialog().numeric(ShowAndGetNumber, heading):
            if snum.isdigit():
                page = int(snum)
                if page < 1:
                    page = 1
                elif total_pages and page > total_pages:
                    page = total_pages
                meth = call.bind()
                target = url_for(meth, page=page, **kwargs)
                if target:
                    folder_update(str(target))


if __name__ == '__main__':
    from ..defs import ItemList

    with directory(view='addons') as kdir:
        kdir.folder('ala ma kaca', '/')
        kdir.folder(12345, '/')  # test nieporawnego argumentu

    items = ItemList(page=1, total_pages=5, total_results=10)
    with directory(items, view='addons') as kdir:
        kdir.folder('ala ma kaca', '/')
        kdir.folder(12345, '/')  # test nieporawnego argumentu
