import re
from datetime import datetime, timedelta
from html import unescape
from threading import Thread
from urllib.parse import unquote
from typing import Optional, Union, List, TYPE_CHECKING

from xbmcgui import ListItem, Window

from ..ff.control import addonPath, run_plugin, settings, busy_dialog, close_busy_dialog
from ..ff.log_utils import fflog, fflog_exc
from ..ff import control
if TYPE_CHECKING:
    from ..ff.sources import sources as Sources, Item
    SourceItem = Item
    Meta = Item

from .base_window import BaseDialog
from .context import ContextMenu
from const import const


def endtime(minutes: Union[int, str]) -> str:
    if not minutes:
        return '–'
    end = datetime.now() + timedelta(minutes=int(minutes))
    return end.strftime("%H:%M")


def clear_source(source):
    return source.rsplit(".", 1)[0]


def format_info(label):
    try:
        return re.sub(r"(\d+(?:[.,]\d+)?\s*[GMK]B)", r"[COLOR ffffffff]\1[/COLOR]", label)
    except Exception:
        return label


class Dialog(BaseDialog):

    XML = "SourcesDialog.xml"

    def __init__(self, xmlFilename: Optional[str] = None, scriptPath: str = control.addonPath, *args,
                 sources: 'Sources', item: 'FFItem', items: List['SourceItem'], **kwargs):
        if xmlFilename is None:
            xmlFilename = self.XML
        fflog(f'WIN  {xmlFilename=}, {scriptPath=}, {args=}')
        super().__init__(xmlFilename, scriptPath, *args)
        self.sources: 'Sources' = sources
        self.item: 'FFItem' = item
        self.items: List['SourceItem'] = items
        self.lists = self.list_items(self.items)
        self.resolved = ""

    def doModal(self):
        super().doModal()
        if self.resolved:
            return self.resolved
        else:
            return "empty"

    def onInit(self):

        default_color = settings.getString("default.color.identify2")
        duration_in_mins = int(self.item.vtag.getDuration() / 60)

        self.setProperty('item.title', str(self.item.title))
        self.setProperty('item.tvshowtitle', self.item.vtag.getTvShowTitle())
        self.setProperty('item.year', str(self.item.year))
        self.setProperty('item.season', str(self.item.season))
        self.setProperty('item.episode', str(self.item.episode))
        self.setProperty('item.duration', str(duration_in_mins) if duration_in_mins else '–')
        self.setProperty('item.art.poster', self.item.getArt('poster'))
        self.setProperty('item.art.fanart', self.item.getArt('fanart'))
        self.setProperty('item.endtime', endtime(duration_in_mins))
        self.setProperty('item.colored.default', default_color)
        # colors MUST be set in known window, HOME is very know :-D
        home = Window(10000)
        home.setProperty('fanfilm.sources_dialog.info.index.color', const.sources_dialog.index_color)
        # items
        self.add_items(5000, self.lists)
        self.setFocus(self.getControl(5000))

    def handle_source(self):
        try:
            busy_dialog()

            position = self.getControl(5000).getSelectedPosition()
            auto_select = settings.getBool("auto.select.next.item.to.play")

            if auto_select:
                for i in range(position, len(self.items)):
                    if resolved := self.sources.sourcesResolve(self.items[i]):
                        self.resolved = resolved
                        self.close()
                        break
            else:
                resolved = self.sources.sourcesResolve(self.items[position])

                if resolved:
                    self.resolved = resolved
                    self.close()
                else:
                    close_busy_dialog()
        except Exception:
            fflog_exc()

    def handle_rescan(self):
        self.close()
        url = f"{control.plugin_url}rescan/{self.item.dbid}"
        run_plugin(url)

    def handle_download(self):
        position = self.getControl(5000).getSelectedPosition()
        resolved = self.sources.sourcesResolve(self.items[position])
        if resolved:
            from lib.ff.downloader import download
            thread = Thread(target=download, args=(self.item.title, self.getProperty("item.art.poster"), resolved))
            thread.start()

    def handle_rebuy(self):
        position = self.getControl(5000).getSelectedPosition()
        resolved = self.sources.sourcesResolve(self.items[position], for_resolve={"buy_anyway": True})
        if resolved:
            self.resolved = resolved
            self.close()

    def onClick(self, control):
        if control == 5000:
            self.handle_source()
        if control == 5005:
            self.handle_rescan()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in {9, 10, 13, 92}:
            self.close()
        elif action_id in {101, 108, 117}:
            context_menu_items = []
            if settings.getBool("downloads"):
                context_menu_items.append((control.lang(30115), self.handle_download))
            item_no = self.getControl(5000).getSelectedPosition()
            provider = self.lists[item_no].getProperty("item.provider")
            if provider == "tb7" or provider == "xt7":
                context_menu_items.append((control.lang(30116), self.handle_rebuy))
            if len(context_menu_items) >= 1:
                ContextMenu("ContextMenu.xml", addonPath).open(context_menu_items)

    def list_items(self, items):
        return [self.create_list_item(item) for item in items]

    def create_list_item(self, item):
        source = clear_source(item['source'])

        fflog(f'[WINDOWS]:  {item=}')
        li = ListItem(label=item['label'])
        li.setProperty('item.info', format_info((item.get('info') or '–––').strip()))
        li.setProperty('item.source', source)
        li.setProperty('item.colored', item.get('color_identify'))
        li.setProperty('item.colored.default', settings.getString("default.color.identify2"))

        if item.get('on_account'):
            li.setProperty('item.on_account_expires', item.get('on_account_expires') if item.get('on_account_expires') else 'konto')

        for key in ["provider", "url", "info2", "language", "quality"]:
            if item.get(key) is None:
                fflog(f'[WINDOWS]: ERORR: No key {key!r} in item {item!r} !!!')
            li.setProperty(f"item.{key}", (item.get(key) or '').strip())

        if not li.getProperty('item.info2'):
            li.setProperty('item.info', li.getProperty('item.info').lstrip('| '))

        if settings.getBool("sources.filename_in_2nd_line"):
            filename = item.get("filename")
            if filename:
                filename = unescape(unquote(filename))
            li.setProperty('item.id', filename)

        if settings.getBool('icon.external') and (icon := item.get('icon')):
            li.setProperty('item.icon', icon)
        return li
