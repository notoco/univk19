
from unittest import TestCase
from unittest.mock import MagicMock

from lib import defs


A = MagicMock()
B = MagicMock()
C = MagicMock()
D = MagicMock()


class TestExceptions(TestCase):

    def test_DeprecatedError(self):
        self.assertIsInstance(defs.DeprecatedError(), BaseException)


class TestVideoIds(TestCase):

    def test_init(self):
        with self.subTest('tuple'):
            self.assertTupleEqual(defs.VideoIds(), (None, None, None, None))
            self.assertTupleEqual(defs.VideoIds(A), (A, None, None, None))
            self.assertTupleEqual(defs.VideoIds(A, B), (A, B, None, None))
            self.assertTupleEqual(defs.VideoIds(A, B, C), (A, B, C, None))
            self.assertTupleEqual(defs.VideoIds(A, B, C, D), (A, B, C, D))
        with self.subTest('named tuple'):
            self.assertTupleEqual(defs.VideoIds(tmdb=A), (A, None, None, None))
            self.assertTupleEqual(defs.VideoIds(imdb=A), (None, A, None, None))
            self.assertTupleEqual(defs.VideoIds(trakt=A), (None, None, A, None))
            self.assertTupleEqual(defs.VideoIds(tvdb=A), (None, None, None, A))
        with self.subTest('names'):
            self.assertIs(defs.VideoIds(tmdb=A).tmdb, A)
            self.assertIs(defs.VideoIds(imdb=A).imdb, A)
            self.assertIs(defs.VideoIds(trakt=A).trakt, A)
            self.assertIs(defs.VideoIds(tvdb=A).tvdb, A)

    def test_is_xxx(self):
        with self.subTest('true'):
            self.assertTrue(defs.VideoIds(tmdb=A).is_tmdb())
            self.assertTrue(defs.VideoIds(imdb=A).is_imdb())
            self.assertTrue(defs.VideoIds(trakt=A).is_trakt())
            self.assertTrue(defs.VideoIds(tvdb=A).is_tvdb())
        with self.subTest('false tmdb'):
            self.assertFalse(defs.VideoIds(imdb=A).is_tmdb())
            self.assertFalse(defs.VideoIds(trakt=A).is_tmdb())
            self.assertFalse(defs.VideoIds(tvdb=A).is_tmdb())
        with self.subTest('false imdb'):
            self.assertFalse(defs.VideoIds(tmdb=A).is_imdb())
            self.assertFalse(defs.VideoIds(trakt=A).is_imdb())
            self.assertFalse(defs.VideoIds(tvdb=A).is_imdb())
        with self.subTest('false trakt'):
            self.assertFalse(defs.VideoIds(tmdb=A).is_trakt())
            self.assertFalse(defs.VideoIds(imdb=A).is_trakt())
            self.assertFalse(defs.VideoIds(tvdb=A).is_trakt())


class TestPagina(TestCase):

    lst = tuple(f'item_{i:02d}' for i in range(35))

    def test_init(self):
        with self.subTest('sequence'):
            self.assertTupleEqual(defs.Pagina(()).items, ())
            self.assertTupleEqual(defs.Pagina((A, B)).items, (A, B))
            self.assertListEqual(defs.Pagina([A, B]).items, [A, B])
        with self.subTest('args'):
            self.assertEqual(defs.Pagina(()).page, 1)
            self.assertIs(defs.Pagina((), page=A).page, A)
            self.assertIs(defs.Pagina((), limit=A).limit, A)
            self.assertIs(defs.Pagina((), page=A, limit=B).page, A)
            self.assertIs(defs.Pagina((), page=A, limit=B).limit, B)

    def test_len(self):
        self.assertEqual(len(defs.Pagina(self.lst, page=2, limit=10)), 10)
        self.assertEqual(len(defs.Pagina(self.lst, page=4, limit=10)), 5)
        self.assertEqual(len(defs.Pagina(self.lst, page=5, limit=10)), 0)
        self.assertEqual(len(defs.Pagina(self.lst, page=0, limit=10)), 0)

    def test_bool(self):
        self.assertTrue(bool(defs.Pagina(self.lst, page=2, limit=10)))
        self.assertFalse(bool(defs.Pagina(self.lst, page=0, limit=10)))
        self.assertFalse(bool(defs.Pagina(self.lst, page=5, limit=10)))
        self.assertFalse(bool(defs.Pagina.empty()))

    def test_item(self):
        p = defs.Pagina(self.lst, page=2, limit=10)
        with self.subTest('index'):
            self.assertEqual(p[0], 'item_10')
            self.assertEqual(p[9], 'item_19')
            self.assertEqual(p[-1], 'item_19')
            self.assertEqual(p[-10], 'item_10')
        with self.subTest('wrong index'):
            with self.assertRaises(IndexError):
                p[10]
            with self.assertRaises(IndexError):
                p[-11]
        with self.subTest('slice'):
            self.assertTupleEqual(p[2:4], ('item_12', 'item_13'))
            self.assertTupleEqual(p[1:5:2], ('item_11', 'item_13'))

    # def test_index(self):

    def test_contains(self):
        p = defs.Pagina(self.lst, page=2, limit=10)
        self.assertTrue('item_12' in p)
        self.assertFalse('item_22' in p)

    def test_iter(self):
        p = defs.Pagina(self.lst, page=2, limit=10)
        self.assertTupleEqual(tuple(iter(p)), self.lst[10:20])
        self.assertTupleEqual(tuple(reversed(p)), self.lst[19:9:-1])

    def test_rest(self):
        p = defs.Pagina(self.lst, page=2, limit=10)
        self.assertEqual(p.index('item_12'), 2)
        self.assertEqual(p.count('item_12'), 1)

    def test_range(self):
        self.assertEqual(defs.Pagina(self.lst, page=2, limit=10).start(), 10)
        self.assertEqual(defs.Pagina(self.lst, page=2, limit=10).end(), 20)
        self.assertEqual(defs.Pagina(self.lst, page=4, limit=10).start(), 30)
        self.assertEqual(defs.Pagina(self.lst, page=4, limit=10).end(), 35)

    def test_next(self):
        self.assertEqual(defs.Pagina(self.lst, page=2, limit=10).next().page, 3)

    def test_next_page(self):
        self.assertEqual(defs.Pagina(self.lst, page=2, limit=10).next_page(), 3)
        self.assertIsNone(defs.Pagina(self.lst, page=4, limit=10).next_page())
