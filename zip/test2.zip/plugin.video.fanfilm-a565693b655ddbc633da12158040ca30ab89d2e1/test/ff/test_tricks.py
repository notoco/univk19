
import typing
from unittest import TestCase
from unittest.mock import MagicMock

from lib.ff import tricks


# A = MagicMock()


class TestMissing(TestCase):

    def test_class(self):
        self.assertIs(tricks.MISSING, type(tricks.MISSING)())


class TestJoinItems(TestCase):

    def test_type(self):
        self.assertIsInstance(tricks.join_items(), typing.Generator)

    def test_single(self):
        self.assertListEqual(list(tricks.join_items('abc', zip_chunk=0)), list('abc'))
        self.assertListEqual(list(tricks.join_items('abc', zip_chunk=1)), list('abc'))
        self.assertListEqual(list(tricks.join_items('abc', zip_chunk=2)), list('abc'))

    def test_chain(self):
        self.assertListEqual(list(tricks.join_items('abc', 'xyz', '123', zip_chunk=0)), list('abcxyz123'))
        self.assertListEqual(list(tricks.join_items('abc', '12345', zip_chunk=0)), list('abc12345'))
        self.assertListEqual(list(tricks.join_items('abcde', '123', zip_chunk=0)), list('abcde123'))

    def test_zip(self):
        self.assertListEqual(list(tricks.join_items('abc', 'xyz', '123', zip_chunk=1)), list('ax1by2cz3'))
        self.assertListEqual(list(tricks.join_items('abc', '12345', zip_chunk=1)), list('a1b2c345'))
        self.assertListEqual(list(tricks.join_items('abcde', '123', zip_chunk=1)), list('a1b2c3de'))

    def test_chunk(self):
        self.assertListEqual(list(tricks.join_items('abc', 'xyz', '123', zip_chunk=2)), list('abxy12cz3'))
        self.assertListEqual(list(tricks.join_items('abcde', '123', zip_chunk=2)), list('ab12cd3e'))
        self.assertListEqual(list(tricks.join_items('abc', '12345', zip_chunk=2)), list('ab12c345'))
