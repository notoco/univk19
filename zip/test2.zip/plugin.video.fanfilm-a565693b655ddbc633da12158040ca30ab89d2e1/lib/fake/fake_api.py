
from typing import Optional, Callable, List
import xbmc
import xbmcplugin
from xbmcplugin import _Item as Item, _directory


def auto() -> None:
    """Auto configuration."""
    from lib.fake.fake_term import print_item_list, print_log
    set_print_list_callback(print_item_list)
    set_print_log_callback(print_log)


def set_print_list_callback(cb: Optional[Callable[[List[Item]], None]]) -> None:
    """Print ListItem folder callback."""
    xbmcplugin._print_item_list_cb = cb


def get_directory() -> List[xbmcplugin._Item]:
    """Reset all fake xmbc structures."""
    return xbmcplugin._directory or []


def reset() -> None:
    """Reset all fake xmbc structures."""
    xbmcplugin._directory.clear()


def url_at_index(index: int) -> str:
    """Return URL for direcotry index."""
    return str(xbmcplugin._directory[index].url or '')


def set_print_log_callback(cb: Optional[Callable[[str, int], None]]) -> None:
    """Reset all fake xmbc structures."""
    xbmc._print_log_cb = cb


def print_last_directory() -> None:
    """(Re)print last directory."""
    if xbmcplugin._print_item_list_cb:
        xbmcplugin._print_item_list_cb(_directory)
