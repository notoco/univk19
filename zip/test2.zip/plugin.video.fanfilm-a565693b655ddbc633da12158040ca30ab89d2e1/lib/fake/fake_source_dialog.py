
from typing import Optional, Sequence, TYPE_CHECKING
from typing_extensions import TypedDict
from lib.ff.item import FFItem
from lib.fake.fake_term import fg, bg, ef, rs, formatting, get_color, print_table
# from lib.ff.types import JsonData

if TYPE_CHECKING:
    from lib.ff.sources import sources as SourcesClass


class SourceDescr(TypedDict):
    color_identify: str
    debrid: str
    debridonly: bool
    direct: bool
    info: str
    info2: str
    label: str
    language: str
    provider: str
    quality: str
    source: str
    url: str


def fake_source_list_dialog(*, item: FFItem, items: Sequence[SourceDescr], sources=Optional['SourcesClass']) -> str:
    """Print sources in terminal and let user make a choice."""
    def fmt_provider(txt, *args, i, **kwargs) -> str:
        color = get_color(items[i].get('color_identify', ''))
        return f'{fg.white}{bg(*color)}{txt}{rs.all}'

    cformats = ['', fmt_provider, '', '', '']
    table = [[f'{i}.', it.get('provider', ''), it.get('quality', ''),
              formatting(it.get('info', '')), it.get('url', '')]
             for i, it in enumerate(items, 1)]
    print_table(table, cformats=cformats)

    cmd = input('Enter list number: ')
    if cmd and cmd.isdigit():
        idx = int(cmd)
        if 0 <= idx < len(items):
            return items[idx].get('url', '')
    return ''
