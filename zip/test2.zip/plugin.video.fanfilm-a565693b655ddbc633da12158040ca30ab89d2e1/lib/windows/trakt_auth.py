
from typing import Optional, Union
from pathlib import Path

# from xbmcvfs import translatePath

from .base_window import BaseDialog
from ..kolang import L
from ..ff.log_utils import fflog
from const import const


class TraktAuthWindow(BaseDialog):

    XML = 'TraktAuth.xml'

    def __init__(self, *args,
                 code: str,
                 url: str = '',
                 progress: Union[int, bool] = 0,
                 icon: Optional[Union[Path, str]] = None,
                 **kwargs) -> None:
        super().__init__(self, *args, **kwargs)
        self.progress_enabled: bool = progress is not False
        self.progress: int = progress or 0
        self.icon: str = icon
        self.code: str = code
        self.url: str = url or ''
        self._is_canceled: bool = False

        if not code:
            code = '???'
        if const.trakt.auth.code.color:
            code = f'[COLOR {const.trakt.auth.code.color}]{code}[/COLOR]'
        self.setProperty('code', str(code))
        self.setProperty('link', L(30118, 'Open: [COLOR FFA30707]{url}[/COLOR]').format(url=self.url))
        self.setProperty('icon.path', str(self.icon or ''))
        self.setProperty('progress.enabled', 'enabled' if self.progress_enabled else '')

    def onInit(self) -> None:
        fflog('TraktAuthWindow.onInit()')
        self.setFocusId(31)

    def onAction(self, action) -> None:
        fflog(f'TraktAuthWindow.onAction({action!r})')

    def onClick(self, control: int) -> None:
        fflog(f'TraktAuthWindow.onClick({control!r})')
        if control == 31:
            self._is_canceled = True
            self.close()

    def update(self, value: int) -> None:
        """Upate progress in percent (0..100)."""
        if not value or value < 0:
            value = 0
        elif value is True or value > 100:
            value = 100
        bg = self.getControl(21)
        fg = self.getControl(22)
        fg.setWidth(int(value * bg.getWidth() / 100))

    def dialog_is_canceled(self) -> bool:
        return self._is_canceled
