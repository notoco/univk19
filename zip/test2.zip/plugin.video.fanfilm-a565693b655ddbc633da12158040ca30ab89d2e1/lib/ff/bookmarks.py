# -*- coding: utf-8 -*-

"""
    FanFilm Add-on
    Copyright (C) 2015 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from lib.ff import control, trakt
from lib.ff.db_connection_manager import connection_manager
from lib.ff.log_utils import LOGDEBUG, LOGERROR, LOGINFO, LOGWARNING, fflog


def initialize_bookmarks_db():
    control.make_dir(control.dataPath)
    dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
    dbcur = dbcon.cursor()

    dbcur.execute(
        "CREATE TABLE IF NOT EXISTS bookmarks ("
        "timeInSeconds TEXT, "
        "type TEXT, "
        "imdb TEXT, "
        "season TEXT, "
        "episode TEXT, "
        "playcount INTEGER, "
        "overlay INTEGER, "
        "UNIQUE(imdb, season, episode)"
        ");"
    )
    dbcon.commit()

def get(media_type, imdb, season, episode, local=False):
    assert False
    try:
        sql_select = "SELECT * FROM bookmarks WHERE imdb = '%s'" % imdb
        if media_type == "episode":
            sql_select += " AND season = '%s' AND episode = '%s'" % (season, episode)

        control.make_dir(control.dataPath)
        dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
        dbcur = dbcon.cursor()
        dbcur.execute(sql_select)
        match = dbcur.fetchone()
        if match:
            offset = match[0]
            return float(offset)
        else:
            return 0
    except Exception as e:
        fflog("bookmarks_get %s" % e)
        return 0


def reset(
    current_time,
    total_time,
    media_type,
    imdb,
    season="",
    episode="",
    init=False,
    dbcon=None,
):
    assert False
    try:
        timeInSeconds = str(current_time)
        _playcount = 0
        overlay = 6
        ok = int(current_time) > 120 and (current_time / total_time) < 0.85
        watched = (current_time / total_time) >= 0.85

        queries = {
            "movie": {
                "select": "SELECT * FROM bookmarks WHERE imdb = ?",
                "update_watched": "UPDATE bookmarks SET timeInSeconds = ?, playcount = ?, overlay = ? WHERE imdb = ?",
                "insert": "INSERT INTO bookmarks (timeInSeconds, type, imdb, season, episode, playcount, overlay) Values (?, ?, ?, NULL, NULL, ?, ?)",
            },
            "episode": {
                "select": "SELECT * FROM bookmarks WHERE imdb = ? AND season = ? AND episode = ?",
                "update_watched": "UPDATE bookmarks SET timeInSeconds = ?, playcount = ?, overlay = ? WHERE imdb = ? AND season = ? AND episode = ?",
                "insert": "INSERT INTO bookmarks Values (?, ?, ?, ?, ?, ?, ?)",
            },
            "tvshow": {
                "select": "SELECT * FROM bookmarks WHERE imdb = ? AND season IS NULL AND episode IS NULL",
                "update_watched": "UPDATE bookmarks SET timeInSeconds = '0', playcount = ?, overlay = ? WHERE imdb = ?",
                "insert": "INSERT INTO bookmarks (timeInSeconds, type, imdb, season, episode, playcount, overlay) Values ('0', ?, ?, NULL, NULL, ?, ?)",
            },
        }

        dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
        dbcur = dbcon.cursor()

        dbcur.execute(
            "CREATE TABLE IF NOT EXISTS bookmarks ("
            "timeInSeconds TEXT, "
            "type TEXT, "
            "imdb TEXT, "
            "season TEXT, "
            "episode TEXT, "
            "playcount INTEGER, "
            "overlay INTEGER, "
            "UNIQUE(imdb, season, episode)"
            ");"
        )

        parameters = [imdb]
        if media_type == "episode":
            parameters.extend([season, episode])

        dbcur.execute(queries[media_type]["select"], parameters)
        match = dbcur.fetchone()

        if match:
            if init:
                _playcount = match[5]
                overlay = 6
                dbcur.execute(
                    queries[media_type]["update_watched"],
                    [timeInSeconds, _playcount, overlay] + parameters,
                )
            elif ok:
                if media_type == "episode":
                    dbcur.execute(
                        queries[media_type]["insert"],
                        [
                            timeInSeconds,
                            media_type,
                            imdb,
                            season,
                            episode,
                            _playcount,
                            overlay,
                        ],
                    )
                else:
                    dbcur.execute(
                        queries[media_type]["insert"],
                        [timeInSeconds, media_type, imdb, _playcount, overlay],
                    )
            elif watched:
                _playcount = match[5] + 1
                overlay = 7
                dbcur.execute(
                    queries[media_type]["update_watched"],
                    [timeInSeconds, _playcount, overlay] + parameters,
                )
            else:
                _playcount = match[5]
                overlay = 6
                dbcur.execute(
                    queries[media_type]["update_watched"],
                    [timeInSeconds, _playcount, overlay] + parameters,
                )
        else:
            if media_type == "episode":
                if watched:
                    _playcount = 1
                    overlay = 7
                    dbcur.execute(
                        queries[media_type]["insert"],
                        [
                            timeInSeconds,
                            media_type,
                            imdb,
                            season,
                            episode,
                            _playcount,
                            overlay,
                        ],
                    )
                else:
                    _playcount = 0
                    overlay = 6
                    dbcur.execute(
                        queries[media_type]["insert"],
                        [
                            timeInSeconds,
                            media_type,
                            imdb,
                            season,
                            episode,
                            _playcount,
                            overlay,
                        ],
                    )
            else:
                if watched:
                    _playcount = 1
                    overlay = 7
                    dbcur.execute(
                        queries[media_type]["insert"],
                        [timeInSeconds, media_type, imdb, _playcount, overlay],
                    )
                else:
                    _playcount = 0
                    overlay = 6
                    dbcur.execute(
                        queries[media_type]["insert"],
                        [timeInSeconds, media_type, imdb, _playcount, overlay],
                    )

        dbcon.commit()

    except Exception:
        fflog("bookmarks_reset")
        pass


def set_scrobble(
    current_time, total_time, _content, _imdb="", _tmdb="", _season="", _episode=""
):
    assert False
    try:
        if not (current_time == 0 or total_time == 0):
            percent = float((current_time / total_time)) * 100
        else:
            percent = 0
        if int(current_time) > 120 and 2 < percent < 85:
            trakt.scrobbleMovie(
                _imdb, percent, action="pause"
            ) if _content == "movie" else trakt.scrobbleEpisode(
                _imdb, _season, _episode, percent, action="pause"
            )
        elif percent >= 85:
            trakt.scrobbleMovie(
                _imdb, percent, action="stop"
            ) if _content == "movie" else trakt.scrobbleEpisode(
                _imdb, _season, _episode, percent, action="stop"
            )
    except:
        fflog("Scrobble - Exception")
        control.infoDialog("Scrobble Failed")


def _indicators():
    control.make_dir(control.dataPath)
    dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM bookmarks WHERE overlay = 7")
    match = dbcur.fetchall()
    if match:
        return [i[2] for i in match]
    dbcon.commit()


def _get_watched(media_type, imdb, season=None, episode=None):
    if media_type not in ["episode", "movie", "season", "tvshow"]:
        raise ValueError(
            "Invalid media_type. Must be either 'episode', 'season', or 'movie'."
        )

    control.make_dir(control.dataPath)
    dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
    dbcur = dbcon.cursor()

    # Connect to meta database to get episodes count
    dbcon_meta = connection_manager.get_connection("metacache", control.metacacheFile)
    dbcur_meta = dbcon_meta.cursor()

    if media_type == "episode":
        if not season or not episode:
            raise ValueError(
                "For 'episode' media_type, 'season' and 'episode' must be provided."
            )

        sql_select = "SELECT * FROM bookmarks WHERE imdb = ? AND overlay = 7 AND type = 'episode' AND season = ? AND episode = ?"
        dbcur.execute(sql_select, (imdb, season, episode))
        match = dbcur.fetchone()

        return 7 if match else 6

    elif media_type == "season":
        if not season:
            raise ValueError("For 'season' media_type, 'season' must be provided.")

        # Connect to bookmarks database to check season status

        # 1. Check if a season entry already exists in bookmarks and is marked as watched
        sql_check_season = "SELECT * FROM bookmarks WHERE imdb = ? AND season = ? AND type = 'season' AND overlay = 7"
        dbcon.execute(sql_check_season, (imdb, season))
        exists = dbcur.fetchone()

        # 2. Count episodes for the season
        sql_count_episodes = "SELECT COUNT(*) FROM meta WHERE imdb = ? AND season = ? AND (episode IS NOT NULL OR episode != '')"
        dbcur_meta.execute(sql_count_episodes, (imdb, season))
        total_episodes = dbcur_meta.fetchone()[0]

        if (
            total_episodes == 0
        ):  # If total episodes for the season is 0, return 6 (not watched)
            return 6

        # 3. Check how many episodes are watched
        sql_count_watched = "SELECT COUNT(*) FROM bookmarks WHERE imdb = ? AND season = ? AND type = 'episode' AND overlay = 7"
        dbcur.execute(sql_count_watched, (imdb, season))
        watched_episodes = dbcur.fetchone()[0]

        if total_episodes == watched_episodes:
            if not exists:
                # Add a new entry if it does not exist
                sql_insert_season = "INSERT INTO bookmarks (imdb, type, season, overlay, playcount) VALUES (?, 'season', ?, 7, 1)"
                dbcur.execute(sql_insert_season, (imdb, season))

            dbcon.commit()
            return 7
        else:
            return 6

    elif media_type == "tvshow":
        # 1. Get unique seasons for the tvshow
        sql_get_seasons = (
            "SELECT DISTINCT season FROM meta WHERE imdb = ? AND season IS NOT NULL"
        )
        dbcur_meta.execute(sql_get_seasons, (imdb,))
        all_seasons = [row[0] for row in dbcur_meta.fetchall()]

        # 2. Check if a tvshow entry already exists in bookmarks and is marked as watched
        sql_check_tvshow = (
            "SELECT * FROM bookmarks WHERE imdb = ? AND type = 'tvshow' AND overlay = 7"
        )
        dbcur.execute(sql_check_tvshow, (imdb,))
        exists = dbcur.fetchone()

        # 3. Check status for each season
        watched_seasons_count = 0
        for s in all_seasons:
            sql_check_season = "SELECT * FROM bookmarks WHERE imdb = ? AND season = ? AND type = 'episode' AND overlay = 7"
            dbcur.execute(sql_check_season, (imdb, s))
            if dbcur.fetchall():
                # 2. Count episodes for the season
                sql_count_episodes = "SELECT COUNT(*) FROM meta WHERE imdb = ? AND season = ? AND (episode IS NOT NULL OR episode != '')"
                dbcur_meta.execute(sql_count_episodes, (imdb, str(s)))
                total_episodes = dbcur_meta.fetchone()[0]

                if (
                    total_episodes == 0
                ):  # If total episodes for the season is 0, return 6 (not watched)
                    return 6

                # 3. Check how many episodes are watched
                sql_count_watched = "SELECT COUNT(*) FROM bookmarks WHERE imdb = ? AND season = ? AND type = 'episode' AND overlay = 7"
                dbcur.execute(sql_count_watched, (imdb, s))
                watched_episodes = dbcur.fetchone()[0]

                if total_episodes == watched_episodes:
                    watched_seasons_count += 1

        if (
            watched_seasons_count == len(all_seasons)
            and len(all_seasons) > 0
            and watched_seasons_count > 0
        ):
            if not exists:
                # Add a new entry for the tvshow if it does not exist
                sql_insert_tvshow = "INSERT INTO bookmarks (imdb, type, overlay, playcount) VALUES (?, 'tvshow', 7, 1)"
                dbcur.execute(sql_insert_tvshow, (imdb,))

            dbcon.commit()
            return 7
        else:
            return 6

    else:  # for movies
        sql_select = (
            "SELECT * FROM bookmarks WHERE imdb = ? AND overlay = 7 AND type = 'movie'"
        )
        dbcur.execute(sql_select, (imdb,))
        match = dbcur.fetchone()

        return 7 if match else 6


def _update_watched(media_type, new_value, imdb, season="", episode=""):
    sql_update = "UPDATE bookmarks SET overlay = %s WHERE imdb = '%s'" % (
        new_value,
        imdb,
    )

    if media_type == "episode":
        sql_update += " AND season = '%s' AND episode = '%s'" % (season, episode)
    elif media_type == "tvshow":
        pass  # For tvshow, we don't need to add any additional conditions.
    elif media_type == "season":
        sql_update += " AND season = '%s'" % season

    dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(sql_update)
    dbcon.commit()


def _delete_record(media_type, imdb, season=None, episode=None):
    sql_delete = "DELETE FROM bookmarks WHERE imdb = '%s'" % imdb

    if media_type == "episode":
        sql_delete += " AND season = '%s' AND episode = '%s'" % (season, episode)
    elif media_type == "season":
        sql_delete += " AND season = '%s'" % season
    elif media_type == "tvshow":
        pass  # For tvshow, we just need to delete based on the IMDb ID.

    dbcon = connection_manager.get_connection("bookmarks", control.bookmarksFile)
    dbcur = dbcon.cursor()
    dbcur.execute(sql_delete)
    dbcon.commit()
