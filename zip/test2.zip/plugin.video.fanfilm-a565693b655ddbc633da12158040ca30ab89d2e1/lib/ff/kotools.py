"""Simple Kodi tools."""

from time import monotonic
from threading import Event, Thread
from types import TracebackType
from typing import Optional, Union, List, Dict, Type, TypeVar, Callable, ClassVar, Generic
from typing_extensions import TypedDict, Unpack, NotRequired, Self
from attrs import define, field, Attribute
from .tricks import MISSING, MissingType
from .log_utils import fflog  # XXX DEBUG


try:
    from xbmc import Monitor
except ModuleNotFoundError:
    # DEBUG & TESTS  (run w/o Kodi)
    from time import sleep
    class Monitor:                  # noqa: E301, D101
        def abortRequested(self):   # noqa: D102
            return False
        def waitForAbort(self, t):  # noqa: E301, D102
            sleep(t)
import xbmcaddon
import xbmcgui

from const import const
from ..service.exc import KodiExit, ReloadExit, ExitBaseExcepion


T = TypeVar('T')


def xsleep(interval: float, *, cancel_event: Optional[Event] = None, monitor: Optional[Monitor] = None) -> None:
    """Sleep in safe mode. Exit on Kodi exit or module reload."""
    end = monotonic() + interval
    if monitor is None:
        monitor = Monitor()
    while True:
        now = monotonic()
        if end <= now:
            return
        if cancel_event is not None and cancel_event.is_set():
            return
        dt = min(const.tune.sleep_step, end - now)
        if monitor.abortRequested() or (dt >= 0.01 and monitor.waitForAbort(dt)):
            raise KodiExit()
        if const.debug.autoreload:
            from ..service.reload import ReloadMonitor
            if ReloadMonitor.reloading:
                raise ReloadExit()


def xsleep_until_exit(interval: float) -> Optional[Type[ExitBaseExcepion]]:
    try:
        xsleep(interval)
    except ExitBaseExcepion as exc:
        return type(exc)
    return None


class Timer(Thread, Generic[T]):
    """
    Call a function after a specified number of seconds:

        t = Timer(30.0, f, args=None, kwargs=None)
        t.start()
        t.cancel()     # stop the timer's action if it's still waiting

    Modified Python's version. Keep function result.
    """

    def __init__(self, interval: float, function: Callable[..., T], args=None, kwargs=None) -> None:
        super().__init__()
        self.interval = interval
        self.function = function
        self.args = args if args is not None else []
        self.kwargs = kwargs if kwargs is not None else {}
        self.finished = Event()
        self.result: Optional[T] = None

    def cancel(self) -> None:
        """Stop the timer if it hasn't finished yet."""
        self.finished.set()

    def run(self) -> None:
        xsleep(self.interval, cancel_event=self.finished)
        if not self.finished.is_set():
            self.result = self.function(*self.args, **self.kwargs)
        self.finished.set()


FF_ICON: str = xbmcaddon.Addon().getAddonInfo('icon')

ICONS: Dict[Optional[str], str] = {
    None: FF_ICON,
    '': FF_ICON,
    'INFO': xbmcgui.NOTIFICATION_INFO,
    'WARNING': xbmcgui.NOTIFICATION_WARNING,
    'ERROR': xbmcgui.NOTIFICATION_ERROR,
}


class NotificationOpenArgs(TypedDict):
    interval: NotRequired[Optional[float]]
    delay: NotRequired[Optional[float]]


@define
class Notification:
    """
    Forced GUI notifications.

    Like xbmcgui.Dialog().notification() but keeps visible event another notification occur.
    Differences:
    - `interval` in SECONDS (not milliseconds)
    - it starts hidden, must be opened or shown, you can use `with` statement
    - `heading`, `message` and `icon` could be changed in any time
    - you could add startup `delay`

    `open()` and `show()` are very similar and don't differ on first usage at all.
    Opening rests all settings and shows, then delay works again.

    When `with` statement is used `interval` interval means visible time AFTER statement exit.

    >>> Notification('Header', 'My text').show()
    >>>
    >>> with Notification('Header', 'Progress: 0%', delay=1) as notif:
    >>>    for i, job in enumerate(jobs):
    >>>        notif.message = f'Progress: {100 * i / len(jobs)}%'
    """

    # Dialog heading (title).
    heading: str
    # heading: str = field()
    # Dialog message.
    message: str
    # message: str = field()
    # Icon to use. Default is FanFilm icon.
    icon: Optional[str] = None
    # Time in SECONDS (sic!). Default 5, None or -1 means forever.
    interval: Optional[float] = 5
    # Play notification sound, default True.
    sound: bool = True
    # True if the notification is visible, if not, you must use show().
    visible: bool = False
    # Startup show delay in seconds.
    delay: float = -1  # -1 means auto (zero or almost zero)

    # -- private attributes --
    _visible: bool = field(default=False, init=False, repr=False)
    _sound: bool = field(default=False, init=False, repr=False)
    _delay: float = field(default=0, init=False, repr=False)
    _thread: Optional[Thread] = field(default=None, init=False, repr=False)
    # _changed: Event = field(factory=Event, init=False, repr=False)
    _exit: Event = field(factory=Event, init=False, repr=False)
    _finished: Event = field(factory=Event, init=False, repr=False)
    _stack: ClassVar[List['Notification']] = []

    def __attrs_post_init__(self):
        self.icon = ICONS.get(self.icon, FF_ICON)
        self._delay = self.delay
        # self._changed.clear()
        if self.visible:
            if self.delay < 0:
                self.delay = 0.01
            self.show()
        elif self.delay < 0:
            self.delay = 0

    # @heading.validator
    # def _change_heading(self, attr: Attribute, value: str) -> None:
    #     self._changed.set()

    # @message.validator
    # def _change_message(self, attr: Attribute, value: str) -> None:
    #     self._changed.set()

    def _show_loop(self, **kwargs: Unpack[NotificationOpenArgs]) -> None:
        assert self.icon is not None
        self._finished.clear()
        interval = kwargs.get('interval', self.interval)
        delay = kwargs.get('delay', self._delay)
        if delay and delay > 0:
            xsleep(delay, cancel_event=self._exit)
            # self._changed.clear()
            self._delay = 0
        if interval is None or interval < 0:
            end = 2**63  # a lot of interval
        else:
            end = monotonic() + (interval or 5)
        try:
            self._stack.append(self)
            fflog(f'Start {self.heading=}, {interval=}, {delay=}, {self._visible=}')
            while self._visible and (now := monotonic()) < end:
                if self._stack and self._stack[-1] is self:
                    sleep_interval = min(1, end - now)
                    sound, self._sound = self._sound, False
                    # self._changed.clear()
                    fflog(f'notif {self.heading=}, {interval=}, {delay=}, {sleep_interval=}')
                    xbmcgui.Dialog().notification(self.heading, self.message, self.icon, int(1000 * sleep_interval + 10), sound)
                    self._sound = False
                    xsleep(sleep_interval, cancel_event=self._exit)
                    # xsleep(sleep_interval, cancel_event=self._changed)
                else:  # not on top
                    fflog(f'hidden {self.heading=}, {interval=}, {delay=}')
                    xsleep(min(.2, end - now))
        finally:
            fflog(f'finish {self.heading=}, {interval=}, {delay=}')
            self.visible = False
            self._thread = None
            self._stack.remove(self)
            self._finished.set()

    def show(self, **kwargs: Unpack[NotificationOpenArgs]) -> Self:
        """Shows notification. No delay again."""
        if not self._visible:
            self._exit.clear()
            self._visible = True
            self._sound = self.sound
            self._thread = Thread(target=self._show_loop, kwargs=kwargs)
            self._thread.start()
        return self

    def hide(self) -> Self:
        """Hide notification."""
        if self._visible:
            self._visible = False
            self._exit.set()
            # self._changed.set()
        return self

    def open(self, **kwargs: Unpack[NotificationOpenArgs]) -> Self:
        """Opens notification again: resets settings and shows."""
        if not self.visible:
            self._sound = self.sound
            self._delay = self.delay
            self.show(**kwargs)
        return self

    def close(self) -> Self:
        """Closes notification."""
        self.hide()
        return self

    # def __del__(self) -> None:
    #     self.hide()

    def __enter__(self) -> 'Notification':
        if self._visible:
            self.hide()
            xsleep(1.1, cancel_event=self._finished)
        self.open(interval=None)
        return self

    def __exit__(self, exc_type: Type[BaseException], exc_inst: Optional[BaseException], exc_tb: Optional[TracebackType]) -> None:
        self.close()
