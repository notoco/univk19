"""Just Kodi settings, separated from control."""

from pathlib import Path
from threading import Lock
from typing import Optional, Union, Any, Callable, overload
from typing_extensions import Literal

try:
    from xbmcaddon import Addon, Settings
    import xbmcvfs
except ModuleNotFoundError:
    # DEBUG & TESTS
    from lxml import etree
    from lxml.etree import _ElementTree as ElementTree, _Element as Element

    class xbmcvfs:

        @staticmethod
        def translatePath(path):
            return path

    class Settings:

        def __init__(self, path: Optional[Path] = None) -> None:
            self.tree: ElementTree = etree.parse(str(path))
            self.root: Element = self.tree.getroot()

        def getString(self, id: str) -> str:
            try:
                return self.root.xpath(f'./setting[@id="{id}"]')[0].text
            except IndexError:
                return ''

        def getBool(self, id: str) -> bool:
            return bool(self.getString(id))

        def getInt(self, id: str) -> int:
            return int(self.getString(id))

        def getNumber(self, id: str) -> float:
            return float(self.getString(id))

    class Addon:

        def __init__(self, id: str = None):
            self.id: str = id or 'plugin.video.fanfilm'  # DEBUG (termial)
            self._settings = None

        def getAddonInfo(self, name: str) -> str:
            if name == 'profile':
                return str(Path('~/.kodi/userdata/addon_data/plugin.video.fanfilm/').expanduser())  # DEBUG (termial)
            return None

        def getSettings(self) -> Settings:
            if self._settings is None:
                self._settings = Settings(Path(self.getAddonInfo('profile')) / 'settings.xml')
            return self._settings

        def getSetting(self, id: str) -> str:
            return self.getSetting().getString(id)


from .log_utils import fflog

GetCallable = Callable[[str], Any]
SetCallable = Callable[[str, Any], None]

MethodGetName = Literal['getBool', 'getInt', 'getNumber', 'getString', 'getBoolList', 'getIntList', 'getNumberList', 'getStringList']
MethodSetName = Literal['setBool', 'setInt', 'setNumber', 'setString', 'setBoolList', 'setIntList', 'setNumberList', 'setStringList']


class SettingsManager:
    """K20+ settings proxy."""

    def __init__(self, *, k19log: bool = True, safe: bool = False) -> None:
        #: Access lock
        self.lock = Lock()
        #: The addon.
        self._addon: Optional[Addon] = None
        #: K20+ settings object.
        self._settings: Optional[Settings] = None
        #: Log every outdated K19 get/set.
        self.k19log: bool = bool(k19log)
        #: Force use safe getter.
        self.safe: bool = bool(safe)
        # Create addon and settings.
        self.reset()
        #: Path to settings file.
        self.path = Path(xbmcvfs.translatePath(self._addon.getAddonInfo('profile'))) / 'settings.xml'

    def _reset(self) -> None:
        """Reset setting access. Remove addon and recreate it again."""
        self._addon = Addon()
        self._settings = self._addon.getSettings()
        self._propagate_settings()

    def reset(self) -> None:
        """Reset setting access. Remove addon and recreate it again."""
        with self.lock:
            self._reset()

    def delete(self) -> None:
        with self.lock:
            self._addion = None
            self._settings = None

    @property
    def addon(self) -> Addon:
        with self.lock:
            if self._addion is None:
                self._reset()
            return self._addion

    @addon.deleter
    def addon(self) -> None:
        with self.lock:
            self._addion = None
            self._settings = None

    @property
    def settings(self) -> Settings:
        with self.lock:
            if self._settings is None:
                self._reset()
            return self._settings

    @settings.deleter
    def setting(self) -> None:
        with self.lock:
            self._settings = None

    def _propagate_settings(self) -> None:
        """Propagate changes to other modules."""
        from .log_utils import options  # import is here to avoid recurrence
        del options.show_fflog          # force refresh log setting

    def get(self, id: str, *, stack_depth: int = 1, k19log: Optional[bool] = None) -> str:
        """Get K19 setting (everything is string)."""
        if k19log is None:
            k19log = self.k19log
        if k19log:
            fflog(f'K19 outdated get setting {id!r}', stack_depth=stack_depth+1)
        return self.addon.getSetting(id)

    def set(self, id: str, value: str, *, stack_depth: int = 1) -> None:
        """Set K19 setting (everything is string)."""
        if self.k19log:
            fflog(f'K19 outdated set setting {id!r}', stack_depth=stack_depth+1)
        self.addon.setSetting(id, value)

    @overload
    def __getattr__(self, key: Literal['getBool']) -> Callable[[str], bool]: ...

    @overload
    def __getattr__(self, key: Literal['getInt']) -> Callable[[str], int]: ...

    @overload
    def __getattr__(self, key: Literal['getNumber']) -> Callable[[str], float]: ...

    @overload
    def __getattr__(self, key: Literal['getString']) -> Callable[[str], str]: ...

    @overload
    def __getattr__(self, key: MethodGetName) -> GetCallable: ...

    @overload
    def __getattr__(self, key: MethodSetName) -> SetCallable: ...

    # @overload
    # def __getattr__(self, key: str) -> Callable[..., Any]: ...

    def __getattr__(self, key: str) -> Union[GetCallable, SetCallable, Callable]:
        """Get settigns from kodi addon settings."""
        def safe_getter(*args, **kwargs):
            from .log_utils import log, LOGWARNING  # force logging, do NOT use fflog to avoid recurrence
            try:
                val = func(*args, **kwargs)
            except TypeError:
                pass  # pass to reset
            else:
                return val
            log(f'[SETTINGS] force RESET for {key}(*{args}, **{kwargs})', LOGWARNING)  # do NOT use fflog() here
            # settings are corrupted
            self.reset()
            # retry to get settings
            return func(*args, **kwargs)

        with self.lock:
            if self._settings is None:
                self._reset()
            # if self._addon is None:
            #     self._addon = Addon()
            # if self._settings is None:
            #     self._settings = self._addon.getSettings()
            if key.startswith('set'):
                # Addon().getSettings.setString(name, val) not works! Use old method.
                return getattr(self._addon, f'setSetting{key[3:]}')
            # special case, if kodi recall the plugin settings are corrupted, need to be reset
            if self.safe:
                # proxy to allow settings reset on corruption
                func = getattr(self._settings, key)
                return safe_getter
            # default getter
            return getattr(self._settings, key)


settings = SettingsManager(k19log=True)


def __getattr__(key: str) -> Union[GetCallable, SetCallable]:
    """Return settings function on module level."""
    if key.startswith('get') or key.startswith('set'):
        return getattr(settings, key)
    raise AttributeError(f'Module settings has no attribute {key!r}')
