"""
    FanFilm Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import sty  # XXX XXX XXX

from pathlib import Path
import re
import json
from enum import Enum
from time import monotonic
from weakref import WeakSet
from pprint import pformat  # DEV LOGS
from typing import Optional, Union, Any, Tuple, List, Dict, Set, Callable, Sequence, TYPE_CHECKING
from typing_extensions import cast
from attrs import define, Factory, field

import xbmc

# Some consts.
from const import const
from ..indexers.core import Indexer
from ..main import reset

# MUST be before any kodi or FF import
# from ..kover import autoinstall  # noqa: F401, pylint: disable=W0611  # noqa: F401
from ..defs import MediaRef, RefType, MediaType
from ..ff import cache, control, metacache
from ..ff.threads import Thread, Event
from ..ff.trakt2 import trakt, ScrobbleAction
from ..ff.settings import settings
from ..ff.db import state
from ..ff.db.playback import MediaPlayInfo, get_playback_item, update_track_watched_item
from ..ff.item import FFItem, FFItemDict
from ..ff.info import ffinfo
from ..ff.calendar import utc_timestamp
from ..ff.tricks import suppress
from ..ff.kotools import xsleep
from ..ff.log_utils import fflog, fflog_exc
from ..ff.types import Params
from ..api.trakt import PlayContentType, HistoryContentType, Ids as TraktIds
from ..indexers.defs import VideoIds
from .exc import ExitBaseExcepion, KodiExit
from .misc import VolatileDbid, PluginRequestInfo
from ..ff.debug.timing import logtime  # XXX DEBUG
from .http_server import Proxy
from .trakt import TraktSync
from .kodidb import KodiVideoDB, KodiVideoInfo, video_db
from ..kolang import L
if TYPE_CHECKING:
    from .reload import ReloadMonitor

# reset some stuff on script relaod
reset()


# FF plugin path
plugin: str = control.plugin_id
plugin_url: str = control.plugin_url


@define
class Video:
    #: Real media type (movie or episode).
    type: RefType
    #: Video DBID.
    dbid: int
    #: Movie or episode IDs for query old FF links in kodi db.
    item: FFItem
    #: Movie or episode Kodi DB video info.
    kodi_info: KodiVideoInfo
    #: Trakt playback (event if not trakt credentials, will be ignored in this case)
    playback: MediaPlayInfo

    @property
    def ref(self) -> MediaRef:
        """Movie or episode ref (normalized)."""
        return self.item.ref

    @property
    def denormalized_ref(self) -> MediaRef:
        """Movie or episode ref (denormalized)."""
        return MediaRef(self.type, self.dbid)

    @property
    def history_type(self) -> HistoryContentType:
        """Movie or episode ref (normalized)."""
        # hack: movie -> movies, episode -> episodes
        return cast(HistoryContentType, f'{self.type}s')

    @property
    def ids(self) -> TraktIds:
        """Returns item ids. Convert type only, data already are OK."""
        return cast(TraktIds, self.item.ids)


@define
class Work:
    name: str
    func: Callable[..., None]
    interval: int = 0
    thread: Optional[Thread] = None
    break_event: Event = Factory(Event)

    def force_call(self):
        """Force re-call cyclic function now."""
        self.break_event.set()


@define
class Works:
    #: Jobs (DB requests).
    jobs: Optional[Work] = None
    #: Trakt sync thrad object.
    trakt_sync: Optional[TraktSync] = None
    #: All events (shared with HTTP server).
    events: Dict[str, Event] = Factory(dict)
    #: Volatile DBID.
    volatile_dbid: VolatileDbid = Factory(VolatileDbid)
    #: Folder info and history.
    folder: PluginRequestInfo = Factory(PluginRequestInfo)
    #: Folder info and history.
    http: Optional[Proxy] = None


# All cyclic workers.
works = Works()


def hash_bar(text: Optional[str] = None, *, stack_depth: int = 1) -> None:
    """Log ##### bar with text in the center."""
    width = 63
    if text is None:
        fflog("#" * width, stack_depth=stack_depth+1)
    else:
        text = f" {text} "
        fflog(f"{text:#^{width}}", stack_depth=stack_depth+1)


def hash_box(lines: List[str], *, ff: bool = False, stack_depth: int = 1) -> None:
    """Log text in ##### box. If `ff` is True, log "FANFILM" in header. """
    hash_bar("FANFILM" if ff else None, stack_depth=stack_depth+1)
    for line in lines:
        hash_bar(line, stack_depth=stack_depth+1)
    hash_bar(None, stack_depth=stack_depth+1)


def hash_bar_next(settting_name: str, title: str = '', stack_depth: int = 1) -> None:
    """Log update info, plus next in H hours."""
    hours = settings.getInt(settting_name)
    hash_bar(f"{title or settting_name} UPDATE - NEXT ON {hours} HOURS", stack_depth=stack_depth+1)


def cyclic_call(interval: Union[int, Tuple[int, int]], func: Callable[..., None], *args: Any, **kwargs) -> Optional[Work]:
    def calling():
        interval = frist_interval
        try:
            while not monitor.abortRequested():
                if const.debug.autoreload:
                    from .reload import ReloadMonitor
                    if ReloadMonitor.reloading:
                        break
                xsleep(interval, cancel_event=work.break_event)
                settings.delete()
                func(*args, **kwargs)
                interval = next_interval
        except ExitBaseExcepion:
            return
        except Exception:
            fflog_exc()
            raise

    if not interval:
        fflog.error(f'missing interval, skip {func}')
        return None
    if isinstance(interval, Sequence):
        frist_interval, next_interval = interval
    else:
        frist_interval = next_interval = interval
    thread = Thread(target=calling)
    thread.name = f'{thread.name}: {func.__qualname__}'
    work = Work(thread=thread, func=func, name=func.__qualname__, interval=next_interval)
    thread.start()
    threads.add(thread)
    return work


@define
class SkipUpdate:
    """Info what to skip."""
    #: skip is valid until `timestamp'
    timestamp: float = 0
    #: Parent ref of skipped media.
    parent: Optional[MediaRef] = None
    #: Parent ref of skipped media.
    refs: Set[MediaRef] = Factory(set)
    #: Is playcount incremented?
    playcount: bool = False

    def __bool__(self) -> bool:
        return bool(self.refs)


class FFMonitor(xbmc.Monitor):
    """FF monitor."""

    VTYPES: Dict[str, RefType] = {
        'tvshow': 'show',
    }

    def __init__(self, *, selfcheck: bool = True):
        xbmc.Monitor.__init__(self)
        self.selfcheck: bool = bool(selfcheck)
        self._indexer: Optional[Indexer] = None
        self.reload_monitor: Optional['ReloadMonitor'] = None
        self.kodidb: KodiVideoDB = video_db
        #: Plugin needs refresh (run update)
        self.need_refresh: bool = False
        #: Plugin needs refresh (run update) - for sure.
        self.force_refresh: bool = False
        #: True if working, else exit from monitor loop.
        self.working: bool = True
        #: Playerstate dict.
        self.player: Dict[str, Any] = {}
        #: Playing now media denormalized reference (DBID).
        self.playing_media_ref: Optional[MediaRef] = None
        #: Full ff-item of playing media
        self.playing_ffitem: Optional[FFItem] = None
        #: All  itms needed to support playing media progress.
        self.playing_items: Optional[FFItemDict] = None
        #: What to skip and when.
        self.skip_updates: SkipUpdate = SkipUpdate()

    def run(self) -> None:
        while self.working and not self.abortRequested():
            # fflog(f'FFMonitor.run... ans={service.ans}')
            # state.add_job('plugin', 'dupa', ('blada', 'ciemna'), sender='service')
            interval = const.tune.service.check_interval
            if self.waitForAbort(interval):
                raise KodiExit()
            if self.selfcheck and self.reload_monitor:
                self.reload_monitor.check()  # raises ReloadExit on any change

    @property
    def indexer(self) -> Indexer:
        if self._indexer is None:
            self._indexer = Indexer()
        return self._indexer

        # --- start from beginning (old code) ---
        # Info.OnChanged          None
        # Player.OnPlay           {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange       {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnSeek           {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                             'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                             'time': {'hours': 0, 'milliseconds': 470, 'minutes': 10, 'seconds': 5}}}
        # <FF enter>
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop          {'end': False, 'item': {'id': 170244501, 'type': 'movie'}}

        # --- resume (kodi) ---
        # <ff enter>             action=play&imdb=tt17024450&tmdb=926393
        # Playlist.OnAdd         {'item': {'id': 170244501, 'type': 'movie'}, 'playlistid': 1, 'position': 0}
        # <ff exit>
        # Info.OnChanged         None
        # Player.OnPlay          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange      {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnSeek          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                            'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                            'time': {'hours': 0, 'milliseconds': 149, 'minutes': 32, 'seconds': 18}}}
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop          {'end': False, 'item': {'id': 170244501, 'type': 'movie'}}
        # <ff enter>             action=movies&url=tmdb_popular

        # --- to the end (no user action at all)
        # ...
        # <ff enter>             action=movies&url=tmdb_popular
        # VideoLibrary.OnUpdate  {'item': {'id': 170244501, 'type': 'movie'}, 'playcount': 2}
        # VideoLibrary.OnUpdate  {'id': 170244501, 'type': 'movie'}
        # Player.OnStop         {'end': True, 'item': {'id': 170244501, 'type': 'movie'}}

        # --- cancel sources ---
        # Player.OnStop          {'end': True, 'item': {'id': 170244501, 'type': 'movie'}}
        # Info.OnChanged         None
        # Player.OnPlay          {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}

        # --- pure video file ---
        # Playlist.OnAdd'        {'item': {'title': 'Watch True Lies (1994) Full Movie Online Free  Movie  TV Online HD Quality.mp4',
        #                         'type': 'movie'}, 'playlistid': 1, 'position': 0}
        # Player.OnPlay          {'item': {'title': 'Watch True Lies (1994) Full Movie Online Free  Movie  TV Online HD Quality.mp4',
        #                         'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1}}
        # Player.OnAVChange x2, Player.OnAVStart ...
        # VideoLibrary.OnUpdate  {'id': -1, 'type': ''}
        # Player.OnStop          {'end': True, 'item': {'title': 'smediaPL--Most nad Sundem S02E07 Lektor PL.[CDA:12827975cd].mp4', 'type': 'movie'}}

        # --- set as watched ---
        # VideoLibrary.OnUpdate  {'item': {'id': 182713481, 'type': 'episode'}, 'playcount': 1}

        # --- set as unwatched ---
        # VideoLibrary.OnUpdate  {'item': {'id': 182713481, 'type': 'episode'}, 'playcount': 0}

        # --- reset progress  ---
        # VideoLibrary.OnUpdate  ...

        # --- others ---
        # System_OnSleep         None
        # System_OnWake          None

        # --- widget ---
        # Player.OnPlay          {'item': {'type': 'unknown'}, 'player': {'playerid': -1, 'speed': 1}}

        # Logika
        # ------
        # przed  Trakt | 0 ½ | 0 e | 0 ½ | 0 e | 1 ½ | 1 e | 1 ½ | 1 e |
        #         Kodi | 0 ½ | 0 e | 1 ½ | 1 e | 0 ½ | 0 e | 1 ½ | 1 e |
        #       folder | 0         | 1         | 1         | 1         |
        # -------------+-----+-----+-----+-----+-----+-----+-----+-----+
        # po   db Kodi | 0 D | 1 _ | 0 D | 1 _ | 0 D | 1 _ | 2 D | 2 _ |
        #        Trakt | 0 D | 1 _ | 1 D | 1 _ | 1 _ | 1 _ | 1 D | 1 _ |

    @suppress(Exception, log_traceback=True)
    def onNotification(self, sender: str, method: str, data: str) -> None:
        works.events['folder'].clear()
        fflog('[FOLDER] hold')
        self.player = state.get_all(module='player')
        # skip updates no longer valid
        if self.skip_updates.parent and self.skip_updates.timestamp < monotonic():
            self.skip_updates.parent = None
            self.skip_updates.refs.clear()
            self.skip_updates.timestamp = 0
        # handle the notification
        try:
            data = json.loads(data or 'null')
            rx = re.compile(r'\W+')
            notif_name: str = f'on__{rx.sub("_", sender)}__{rx.sub("_", method)}'
            handler = getattr(self, notif_name, None)

            if const.debug.tty:
                magenta, off = '\033[95m', '\033[0m'
            else:
                magenta = off = ''
            fflog(f'{magenta}onNotification{off}(sender={sender!r}, method={magenta}{method!r}{off}),'
                  f' handler({notif_name!r})={bool(handler)}, data:\n{pformat(data)}')
            fflog(f'{self.player = }')
            if handler is not None:
                try:
                    handler(sender, method, data)
                except Exception:
                    fflog_exc()
                finally:
                    fflog(f'[SERVICE]  ???  {state.lock.locked() = }')
                    access = state.get_access_value('plugin')
                    fflog(f'[SERVICE]  !!!  {self.need_refresh=}, {self.force_refresh=}, {access=}')

                    if self.need_refresh:
                        if False:
                            # FALSE, bucause we avoid trakt syncing - everyfing should be ok
                            fflog('[SERVICE] forced sync start...')
                            if works.trakt_sync:
                                works.trakt_sync.sync_start()
                        # if state.get_access_value('plugin'):
                        #     # state.add_job('plugin', 'update', sender='service')
                        #     state.add_job('plugin', 'refresh', sender='service')
                        # else:
                        #     control.refresh()
                    if self.force_refresh:
                        control.refresh()
                        if const.tune.service.group_update_busy_dialog:
                            control.close_busy_dialog()
                    self.force_refresh = False
                    self.need_refresh = False
        except Exception:
            fflog_exc()
        finally:
            self.folder_ready()
            self.player.clear()

    def set_state(self, key: str, value: Any) -> None:
        """Set player state."""
        state.set(key, value, module='player')
        self.player[key] = value

    def folder_ready(self):
        """Mark folder as ready to show."""
        if works.events['folder'].is_set():
            fflog('[FOLDER] ready')
        works.events['folder'].set()

    @logtime
    def update_db(self, video: Video) -> bool:
        """Set playback in DB and mark folder ready."""
        if result := update_track_watched_item(video.playback, info=self.playing_items):
            if trakt.credentials():
                trakt.updated()
            # stored = get_playback_item(video.ref)  # DEBUG only
            # fflog(f'{video.playback.progress}%, x{video.playback.play_count}, {result=}, {video.playback=}, {video.playback._db_values=}, {stored=}')
            fflog(f'{video.playback.progress}%, x{video.playback.play_count}, {result=}, {video.playback=}, {video.playback._db_values=}')
            self.need_refresh = True  # only for make sure (trakt should have the same data as DB have)
        else:
            result = False
        self.folder_ready()
        return result

    def on__xbmc__Player_OnPlay(self, sender: str, method: str, data: Any) -> None:
        """On player start."""
        dbid, vtype, video = self.parse_notif_data(data)
        # if self.player.get('playing.empty'):
        #     fflog('[SERVICE][PLAYER] skip video (close sources window)')
        #     return
        if not video or not self.player.get('playing.run'):
            fflog(f'[SERVICE][PLAYER] start alien {vtype} {dbid}, ignore video {video}')
            return
        self.set_state('playing.dbid', dbid)
        fflog(f'[SERVICE][PLAYER] start {dbid}, {video=}')
        if video:
            self.set_state('playing.progress', video.kodi_info.percent)
            self.set_state('playing.play_count', video.kodi_info.play_count)
            if video.kodi_info.percent is None:
                fflog(f'[SERVICE][PLAYER] start, no progress: {video}')
            video.playback.progress = video.kodi_info.percent or 0
            self.scrobble(video, 'start')
            ref = video.item.ref
            self.playing_media_ref = MediaRef(ref.real_type, dbid or 0)
            self.playing_ffitem = video.item
            if (show_ref := video.item.show_ref) and show_ref != ref:
                self.playing_items = ffinfo.get_item_dict([show_ref], tv_episodes=True)
            else:
                self.playing_items = {ref: video.item}
        # else:
        #     # new play
        #     trakt.scrobble_start(vtype, 0, **VideoIds.from_dbid(dbid or 0).ids())

    def on__xbmc__Player_OnStop(self, sender: str, method: str, data: Any) -> None:
        """On player stop."""
        try:
            dbid, vtype, video = self.parse_notif_data(data)
            # if self.player.get('playing.empty'):
            #     fflog('[SERVICE][PLAYER] skip video (close sources window)')
            #     return
            if not video:
                fflog(f'[SERVICE][PLAYER] stop alien {vtype} {dbid}, ignore video {video}')
                return
            if self.player.get('playing.run'):
                fflog(f'[SERVICE][PLAYER] stop still playing {vtype} {dbid}, video {video}')
                self.video_update(video)
            else:
                fflog(f'[SERVICE][PLAYER] stop already stopped {vtype} {dbid}, video {video}')
        finally:
            state.delete_all(module='player')
            self.playing_media_ref = None
            self.playing_ffitem = None
            self.playing_items = None

    def on__xbmc__VideoLibrary_OnUpdate(self, sender: str, method: str, data: Any) -> None:
        """Video status updated."""
        dbid, vtype, video = self.parse_notif_data(data, skip=True)
        if not dbid:
            return
        # if self.player.get('playing.empty'):
        #     fflog('[SERVICE][PLAYER] skip video (close sources window)')
        #     return
        # fflog(f'[SERVICE][PLAYER] update item {item}, {video=}, :::{state.get_all(module="player")}')
        if data.get('added'):
            fflog(f'Mew media {vtype}/{dbid} added to library, ignore it')
            return
        if video:
            # fflog(f'[SERVICE] !!!!!!!!!!!!!!!!!!!!!!!!! {list(video.ref.parents())=}, {self.skip_updates.parent=}')
            # skip updates when playing
            # if self.player.get('playing.run') and self.player.get('media.dbid') == self.playing_media_dbid:
            #     works.events['folder'].clear()
            #     fflog(f'[SERVICE] skip update when playing {self.playing_media_dbid}')
            #     return
            # skip massive updates (episodes on show.seazon/update)
            if self.skip_updates and video.ref in self.skip_updates.refs and bool(video.playback.play_count) == self.skip_updates.playcount:
                fflog(f'[SERVICE] skip update {video.ref} because {self.skip_updates.parent}')
                return
            kodi_playcount = data.get('playcount')
            if kodi_playcount == 0:
                fflog(f'[SERVICE][PLAYER] unwatch {vtype} {dbid}, video {video}')
                self.set_watched(video, 0)
            elif kodi_playcount is not None and kodi_playcount > 0:
                if self.player.get('playing.run') and self.playing_media_ref == MediaRef(vtype, dbid):
                    fflog(f'[SERVICE][PLAYER] update {vtype} {dbid} on stop?')
                    self.video_update(video)
                else:
                    fflog(f'[SERVICE][PLAYER] watch {vtype} {dbid}, video {video}')
                    self.set_watched(video, 1)
            else:
                fflog(f'[SERVICE][PLAYER] update {vtype} {dbid}, video {video}')
                self.video_update(video)
            ref = video.ref
            if ref.is_show or ref.is_season:
                fflog(f'[SERVICE] show/season update detected {ref:a}')
                self.skip_updates.timestamp = monotonic() + const.tune.service.group_update_timeout
                self.skip_updates.parent = ref
                self.skip_updates.refs = {ref for it in video.item.item_tree_iter() for ref in (it.ref, MediaRef(it.type or '', it.dbid or 0))}
                self.skip_updates.playcount = bool(video.playback.play_count)
                # self.force_refresh = True  # kodi walks on FF folders, we could niot detect refreshing, we have to force refreash after season/show update
                if self.force_refresh and const.tune.service.group_update_busy_dialog:
                    control.busy_dialog()
        else:
            fflog(f'[SERVICE][PLAYER] update alien {vtype} {dbid}, ignore video {video}')

    def on__xbmc__Player_OnSeek(self, sender: str, method: str, data: Any) -> None:
        """Video video seek."""
        # Player.OnSeek  {'item': {'id': 170244501, 'type': 'movie'}, 'player': {'playerid': 1, 'speed': 1,
        #                    'seekoffset': {'hours': 0, 'milliseconds': 0, 'minutes': 10, 'seconds': 0},
        #                    'time': {'hours': 0, 'milliseconds': 149, 'minutes': 32, 'seconds': 18}}}
        dbid, vtype, video = self.parse_notif_data(data)
        if self.player.get('playing.empty'):
            fflog('[SERVICE][PLAYER] skip video (close sources window)')
            return
        if video:
            fflog(f'[SERVICE][PLAYER] seek {vtype} {dbid}, video {video}')
            duration: int = int(video.kodi_info.total_s or self.player.get('media.duration') or 0)
            tm: Dict[str, int] = data.get('player', {}).get('time')
            if duration and tm:
                current: float = (tm.get('hours', 0) * 3660 + tm.get('minutes', 0) * 60 + tm.get('seconds', 0)
                                  + tm.get('milliseconds', 0) / 1000)
                progress: float = 100 * current / duration
                video.playback.progress = progress
                self.scrobble(video, 'start', progress=progress)
        else:
            fflog(f'[SERVICE][PLAYER] seek alien {vtype} {dbid}, ignore video {video}')

    def video_update(self, video: Video) -> None:
        old_play_count = self.player.get('playing.play_count') or 0
        # old_progress = self.player.get('playing.progress') or 0

        if self.player.get('playing.run'):  # stop playing
            # progress could disappear if play_count is increment
            if video.kodi_info.has_progress and video.kodi_info.percent and video.kodi_info.percent < const.media.progress.as_watched:
                video.playback.progress = video.kodi_info.percent
                # scrobble, handles db and trakt
                self.scrobble(video, 'pause')
            else:
                # no progress, check play_count
                if video.kodi_info.play_count == old_play_count + 1:
                    video.playback.play_count = video.kodi_info.play_count
                    video.playback.clear_progress()
                    # scrobble, handles db and trakt
                    self.scrobble(video, 'stop', 100)
                else:
                    # nothing match, pause at 0%
                    if not video.playback:
                        fflog(f'[SERVICE][PLAYER] nothing match, canceled unknow video {video}?')
                        return
                    # detect watched again
                    if (video.kodi_info.play_count and video.kodi_info.play_count > 1
                            and not video.kodi_info.time_s and video.playback.play_count == 0):
                        fflog(f'[SERVICE] kodi watched hight count {video.kodi_info.play_count}, mark as watched in trakt.')
                        video.playback.play_count = 1
                        # set watched, handles db and trakt
                        self.set_watched(video, 1)
                    else:
                        fflog('[SERVICE] nothing? Or just reset resume point. Try to pause at 0%.')
                        video.playback.clear_progress(progress=0)
                        # scrobble, handles db and trakt
                        self.scrobble(video, 'pause', 0)
            self.set_state('playing.run', False)  # stop playing
            self.set_state('playing.stopping', True)  # stoping playing...
        elif self.player.get('playing.stopping'):
            # unnecessery update between previous update and player.stop.
            fflog(f"WHAT TO DO ???  Let me guess... Just player stopping..."
                  f'\n{video}\n{state.get_all(module="player")}')
        else:
            # external action like add to watched, removed from watched...
            fflog(f"What to do? Let me guess... I'm removing a progress..."
                  f'\n{video}\nstate: {state.get_all(module="player")}')
            video.playback.clear_progress()
            # scrobble, handles db and trakt
            self.scrobble(video, 'pause', 0)

    def get_video(self, vtype: RefType, dbid: Optional[int], *, player: Optional[Params] = None, play_count: Optional[int] = None) -> Optional[Video]:
        """Get video info & meta data. None if `dbid` is corrupted."""
        if player is None:
            player = self.player
        if not dbid or not type:
            return None

        kodi_info: Optional[KodiVideoInfo] = None
        de_ref = MediaRef(vtype, dbid)
        # ffitem info with no progress, because we use MediaPlayInfo directly
        if self.playing_ffitem and self.playing_media_ref == de_ref:
            ffitem = self.playing_ffitem
        elif dbid in VideoIds.KODI:
            kodi_info = self.kodidb.get_play_by_kodi_id(cast(MediaType, vtype), dbid)
            if kodi_info is None:
                fflog(f'no kodi info {de_ref=}')
                return None  # we do NOT support media if it is unknown for TMDB
            ffitem = ffinfo.find_item(kodi_info.ref, progress=ffinfo.Progress.NO, tv_episodes=True)
        else:
            ffitem = ffinfo.find_item(de_ref, progress=ffinfo.Progress.NO, tv_episodes=True)
        if not ffitem:
            fflog(f'no ffitem {de_ref=}, kodi.ref={kodi_info and kodi_info.ref!r}')
            return None  # we do NOT support media if it is unknown for TMDB
        ref = ffitem.ref
        # direct trakt playback
        if not (pb := get_playback_item(ref)):
            pb = MediaPlayInfo.from_ffitem(ffitem)
        # play progress and count from kodi db
        if not kodi_info:
            kodi_info = self.kodidb.get_play(ref=ref)
        if not kodi_info:
            if play_count is None:
                fflog(f'no kodi info {ref=}, {de_ref=}')
                return None
            # fake kodi info about shows and seasons
            fflog(f'no kodi info {ref=}, {de_ref=} make fake info with {play_count=}')
            kodi_info = KodiVideoInfo(fid=0, bid=0, fname='', play_count=play_count, time_s=0, total_s=0, params={}, ref=ref)
        # return info
        return Video(type=vtype, dbid=dbid, item=ffitem, kodi_info=kodi_info, playback=pb)

    def parse_notif_data(self, data: Any, *, skip: bool = False) -> Tuple[Optional[int], Optional[str], Optional[Video]]:
        """Get base video notification values."""
        if data is None:
            data = {}
        play_count = data.get('playcount')
        item = data.get('item')
        if not item:
            item = data
        dbid = item.get('id')
        vtype = item.get('type')
        # hack for widgets
        if (vtype in ('unknown', '') and self.player.get('playing.run')
                and (mtype := self.player.get('media.real_type'))
                and (mdbid := self.player.get('media.dbid'))):
            vtype, dbid = mtype, mdbid
        reftype = self.VTYPES.get(vtype, cast(RefType, vtype))
        if skip and self.skip_updates and play_count is not None:
            ref = MediaRef(vtype, dbid)
            if ref in self.skip_updates.refs and bool(play_count) == self.skip_updates.playcount:
                fflog(f'[SERVICE] skip update {ref} because {self.skip_updates.parent}')
                return None, None, None
        video: Optional[Video] = self.get_video(dbid=dbid, vtype=reftype, play_count=play_count)
        return dbid, vtype, video

    def scrobble(self, video: Video, action: ScrobbleAction, progress: Optional[float] = None) -> None:
        """Set trakt scrobble if progress changed. video.playback.progress must be already set."""
        if video:
            if progress is None:
                progress = video.kodi_info.percent
            progress = progress or 0
            # first, set in DB
            self.update_db(video)
            # next, send to trakt
            if video and trakt.credentials():
                trakt.scrobble_ref(action, video.ref, progress, db_save=False)  # DB is updated already
            if const.debug.tty:
                fflog(f'[SERVICE] scrobble: {sty.fg.cyan} {action} {progress}% {sty.rs.all}')
            else:
                fflog(f'[SERVICE] scrobble: {action} {progress}%')
            self.need_refresh = True
        else:
            self.folder_ready()

    def set_watched(self, video: Video, play_count: int) -> None:
        """Set trakt watched plays."""
        if video:
            if play_count:
                # first, set in DB
                video.playback.clear_progress()
                video.playback.play_count = play_count
                self.update_db(video)
                # next, send to trakt
                if trakt.credentials():
                    if video.playback.progress:
                        trakt.scrobble_ref('stop', video.ref, 100, db_save=False)  # DB is updated already
                    else:
                        trakt.add_history_ref(video.ref, db_save=False)  # DB is updated already
            else:
                # first, set in DB
                video.playback.clear_progress()
                video.playback.play_count = 0
                self.update_db(video)
                # next, send to trakt
                if trakt.credentials():
                    if video.playback.progress:
                        trakt.scrobble_ref('pause', video.ref, 0, db_save=False)  # DB is updated already
                    trakt.remove_history_ref(video.ref, db_save=False)  # DB is updated already
            if const.debug.tty:
                fflog(f'[SERVICE] plays: {sty.fg.cyan} set {play_count or 0} {sty.rs.all}')
            else:
                fflog(f'[SERVICE] plays:  set {play_count or 0}')
            self.need_refresh = True
        else:
            self.folder_ready()

    def onSettingsChanged(self):
        fflog('[SERVICE]')


def syncTraktLibrary():
    control.run_plugin(f"{plugin_url}?action=tvshowsToLibrarySilent&url=traktcollection")
    control.run_plugin(f"{plugin_url}?action=moviesToLibrarySilent&url=traktcollection")
    hash_bar_next("schedTraktTime", "TRAKT LIBRARY")


def syncTMDBLibrary():
    control.run_plugin(f"{plugin_url}?action=tvshowsToLibrarySilent&url=tmdbuserfavourite")
    control.run_plugin(f"{plugin_url}?action=moviesToLibrarySilent&url=tmdbuserfavourite")
    hash_bar_next("schedTmdbTime", "TMDB LIBRARY")


def syncIMdbLibrary():
    control.run_plugin(f"{plugin_url}?action=tvshowsToLibrarySilent&url=imdbwatchlist")
    control.run_plugin(f"{plugin_url}?action=moviesToLibrarySilent&url=imdbwatchlist")
    hash_bar_next("schedIMdbTime", "IMDB LIBRARY")


def cacheCleanTimer():
    cache.cache_clear()
    hash_bar_next("schedCleanCache", "CACHE CLEAN")


def cacheCleanSourcesList():
    cache.cache_clear_providers()
    cache.cache_clear_sources()
    hash_bar("SOURCES LIST CLEANED")


def service_jobs():
    for job in state.jobs('service'):
        if job.command == 'trakt.sync':
            if works.trakt_sync:
                works.trakt_sync.sync_start()
            else:
                fflog('[WARNING] cyclic trakt_playback_sync() is NOT running, force sync directly')
        elif job.command in ('refresh', 'update'):
            # push job to plugin
            state.add_job('plugin', job.command, args=job.args, sender=job.sender)


def startup():
    """Initialize all startup and cyclic stuff."""

    # def dialog_start():
    #     fflog('aa')
    #     notif = Notification('aa', 'bb', time=3).show()
    #     fflog(repr(notif))

    # def dialog_stop():
    #     fflog('cc')
    #     Notification('cc', 'dd', time=1).show()
    #     # notif.close()

    # def off():
    #     fflog('off')
    #     n0.hide()

    # t1 = Timer(3.5, dialog_start)
    # t2 = Timer(5, dialog_stop)
    # t3 = Timer(7, off)
    # t1.start()
    # t2.start()
    # # t3.start()
    # with Notification('11', '22', time=1) as n0:
    #     for i in range(80):
    #         xsleep(.1)
    #         n0.message = f'00: {i=}'
    #     xsleep(5)
    # return

    def start_cyclic_task(func: Callable, settting_name: str, title: str = '') -> None:
        hours = settings.getInt(settting_name)
        if hours > 0:
            hash_box([
                f"STARTING {title} SCHEDULING",
                f"SCHEDULED TIME FRAME {hours} HOURS",
            ])
            timeout = 3600 * hours
            cyclic_call(timeout, func)

    try:
        MediaVersion = control.addon("script.fanfilm.media").getAddonInfo("version")
        AddonVersion = control.addon(control.plugin_id).getAddonInfo("version")
        AddonOldVersion = settings.getString("addon.version")
        if AddonOldVersion != AddonVersion:
            cache.cache_clear_all()
            hash_bar("FANFILM NOWA INSTALACJA")
        settings.setString("addon.version", AddonVersion)
        hash_box([
            "CURRENT FANFILM VERSIONS REPORT",
            f"FANFILM PLUGIN VERSION: {AddonVersion}",
            f"FANFILM MEDIA VERSION:  {MediaVersion}",
        ], ff=True)
    except Exception:
        hash_box([
            "CURRENT FANFILM VERSIONS REPORT",
            "ERROR GETTING FANFILM VERSIONS - NO HELP WILL BE GIVEN AS THIS IS NOT AN OFFICIAL FANFILM INSTALL"
        ], ff=True)

    if False:
        # XXX
        # if settings.getBool("autoTraktOnStart"):
        #     syncTraktLibrary()

        # XXX
        # start_cyclic_task(syncTraktLibrary, "schedTraktTime", "TRAKT")

        if settings.getBool("autoTmdbOnStart"):
            syncTMDBLibrary()

        start_cyclic_task(syncTMDBLibrary, "schedTmdbTime", "TMDB")

        if settings.getBool("autoIMdbOnStart"):
            syncIMdbLibrary()

        start_cyclic_task(syncIMdbLibrary, "schedIMdbTime", "IMDB")

        if settings.getBool("autoCleanCacheAll"):
            cache.cache_clear_all()
            hash_box(["Wyczyszczono pamięć podręczną"], ff=True)

        start_cyclic_task(cacheCleanTimer, "schedCleanCache", "CLEAN")

        # XXX
        # if trakt.trakt_credentials_manager.credentials_info:
        #     hash_bar("STARTING TRAKT ACTIVITY CYCLE CALL")
        #     cyclic_call(300, trakt.check_trakt_activity)

        cyclic_call(1800, cacheCleanSourcesList)

        cyclic_call(300, metacache.remove_old_entries, settings.getInt("schedCleanMetaCache"))

        # XXX
        # if settings.getBool("syncTraktWithLocal"):
        #     hash_bar("TRAKT SYNC ENABLED")
        #     if trakt.trakt_credentials_manager.credentials_info:
        #         try:
        #             hash_bar("TRAKT SYNC TO LOCAL DB STARTED")
        #             # bookmarks.initialize_bookmarks_db()
        #             trakt.synchronize_movies_with_trakt()
        #             trakt.synchronize_episodes_with_trakt()
        #             hash_bar("TRAKT SYNC TO LOCAL DB FINISHED")
        #         except Exception as e:
        #             fflog(f"TRAKT SYNC TO LOCAL DB EXCEPTION: {e}")
        #             fflog_exc()

        try:
            from lib.ff import downloader
            downloader.clear_db()
        except Exception:
            fflog_exc()

    # works.trakt_sync = TraktSync()
    assert works.trakt_sync
    works.events['trakt'] = works.trakt_sync.synced
    works.events['folder'] = Event()
    works.events['folder'].set()  # ready by default
    works.trakt_sync.start()
    threads.add(works.trakt_sync)

    works.jobs = cyclic_call(const.tune.service.job_list_sleep, service_jobs)


def run(reload_monitor: Optional['ReloadMonitor'] = None) -> None:
    """Run service module."""
    monitor.reload_monitor = reload_monitor
    try:
        proxy.start()
    except Exception:
        fflog_exc()
    try:
        fflog('[FF] ### Service start-up')
        startup()
        fflog('[FF] ### Monitor run')
        monitor.run()
    finally:
        fflog('[FF] ### Gooing to stop')
        stop(join=False)


def join_threds() -> None:
    """Join all threads."""
    for th in threads:
        th.join()
    threads.clear()


def stop(*, join: bool = True) -> None:
    """Stop all services."""
    monitor.working = False
    if works.trakt_sync:
        works.trakt_sync.stop()
    proxy.stop()
    if join:
        join_threds()
    fflog('[FF] ### Stopped')


fflog('[SERVICE] ----- start service -----')


# All thread
threads = WeakSet()

# Trakt sync thread.
works.trakt_sync = TraktSync()

# Uruchamianie serwera HTTP
proxy = works.http = Proxy(works=works)

# Główny monitor
monitor = FFMonitor()
