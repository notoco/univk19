# -*- coding: utf-8 -*-

"""
    FanFilm Project
"""

import json
from urllib.parse import urlencode, parse_qs

from lib.ff import cleantitle, control, source_utils
#from six import ensure_str, ensure_text

def ensure_str(s, encoding='utf-8', errors='strict'):
    if type(s) is str:
        return s
    if isinstance(s, bytes):
        return s.decode(encoding, errors)
    return s

ensure_text = ensure_str

class source:
    # This class has support for *.sort.order setting
    has_sort_order: bool = False
    # This class has support for *.color.identify2 setting
    has_color_identify2: bool = True
    # Mark sources with prem.color.identify2 setting
    use_premium_color: bool = True
    def __init__(self):
        self.priority = 1
        self.language = ["en", "de", "fr", "gr", "ko", "pl", "pt", "ru"]
        self.domains = []

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            return urlencode({"imdb": imdb, "title": title, "localtitle": localtitle, "year": year})
        except Exception:
            return

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            return urlencode(
                {"imdb": imdb, "tmdb": tmdb, "tvshowtitle": tvshowtitle, "localtvshowtitle": localtvshowtitle,
                    "year": year, })
        except Exception:
            return

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, "") for i in url])
            url.update({"premiered": premiered, "season": season, "episode": episode})
            return urlencode(url)
        except Exception:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        # log_utils.log(f'[library.py] {url=!r}')
        try:
            if url is None:
                return sources

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, "") for i in data])

            content_type = "episode" if "tvshowtitle" in data else "movie"

            years = (data["year"], str(int(data["year"]) + 1), str(int(data["year"]) - 1),)

            if content_type == "movie":
                title = cleantitle.get(data["title"])
                ids = [data["imdb"]]

                r = control.jsonrpc(
                    '{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovies", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["imdbnumber", "title", "originaltitle", "file"]}, "id": 1}' % years)
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["movies"]

                r = [i for i in r
                     if str(i["imdbnumber"]) in ids or title in [cleantitle.get(ensure_str(i["title"])),
                                                                 cleantitle.get(ensure_str(i["originaltitle"])), ]]
                r = [i for i in r if not ensure_str(i["file"]).endswith(".strm")][0]

                r = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {'
                                    '"properties": ["streamdetails", "file"], "movieid": %s }, "id": 1}' % r["movieid"])
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["moviedetails"]
            elif content_type == "episode":
                title = data["tvshowtitle"]
                season, episode = data["season"], data["episode"]

                r = control.jsonrpc(
                    '{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"filter":{"or": [{"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}, {"field": "year", "operator": "is", "value": "%s"}]}, "properties": ["imdbnumber", "title"]}, "id": 1}' % years)
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["tvshows"]

                r = [i for i in r if title in (ensure_str(i["title"]))][0]

                r = control.jsonrpc(
                    '{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"filter":{"and": [{"field": "season", "operator": "is", "value": "%s"}, {"field": "episode", "operator": "is", "value": "%s"}]}, "properties": ["file"], "tvshowid": %s }, "id": 1}' % (
                        str(season), str(episode), str(r["tvshowid"])))
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["episodes"]

                r = [i for i in r if not ensure_str(i["file"]).endswith(".strm")][0]

                r = control.jsonrpc('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodeDetails",'
                                    ' "params": {"properties": ["streamdetails", "file"],'
                                    ' "episodeid": %s }, "id": 1}' % r["episodeid"])
                r = ensure_text(r, "utf-8", errors="ignore")
                r = json.loads(r)["result"]["episodedetails"]

            url = ensure_str(r["file"])

            try:
                qual = int(r["streamdetails"]["video"][0]["width"])
            except Exception:
                qual = -1

            if qual >= 2160:
                quality = "4K"
            elif 1920 <= qual < 2000:
                quality = "1080p"
            elif 1280 <= qual < 1900:
                quality = "720p"
            elif qual < 1280:
                quality = "SD"

            info = []

            try:
                f = control.openFile(url)
                s = f.size()
                f.close()
                s = source_utils.convert_size(s)
                # info.append(s)  # dołączane jest na końcu kodu
            except Exception:
                pass

            try:
                c = r["streamdetails"]["video"][0]["codec"]
                if c == "avc1":
                    c = "h264"
                if c == "h265":
                    c = "hevc"
                info.append(c)
            except Exception:
                pass

            try:
                ac = r["streamdetails"]["audio"][0]["codec"]
                if ac == "eac3":
                    ac = "dd+"
                if ac == "dca":
                    ac = "dts"
                if ac == "dtshd_ma":
                    ac = "dts-hd ma"
                info.append(ac)
            except Exception:
                pass

            try:
                ach = r["streamdetails"]["audio"][0]["channels"]
                if ach == 1:
                    ach = "mono"
                if ach == 2:
                    ach = "2.0"
                if ach == 6:
                    ach = "5.1"
                if ach == 7:
                    ach = "6.1"
                if ach == 8:
                    ach = "7.1"
                info.append(ach)
            except Exception:
                pass

            info = " / ".join(info)
            info = f'{s} | [ {info} ]'  # tu dołączany jest rozmiar pliku

            size = s
            
            lang = "en"  # tak było przed zmianami
            lang = source_utils.get_lang_by_type(url)[0]  # ja dodałem detekcję
            
            sources.append({"source": "", "quality": quality, "language": lang, "url": url, "info": info,
                            "size": size, "local": True, "direct": True, "debridonly": False, })

            return sources
        except Exception:
            # log_utils.log('lib_scraper_fail0', 1)
            return sources

    def resolve(self, url):
        return url
