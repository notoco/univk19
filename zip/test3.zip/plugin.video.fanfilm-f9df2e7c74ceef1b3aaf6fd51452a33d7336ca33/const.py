"""
FanFilm const (low-level developper) settings.
Do NOT change if you don't know what you doing.

Avoid imports here, please.
Supports `local.py` from plugin userdata folder. File is created if missing.

You can override settings in `local.py`.
Just in the same form as in section "CONST SETTINGS",
>>> const.name = value


Define new setting
------------------

To create new const settings (ex. `const.a.b.c` as `int`) you have to:
 - define the settings
 - assing the value

Define new settings in `class const` structure in "CONST DEFINITION" section.
Every section (ex. `a.b.`) must be a class with `@constdef` decorator.
The name after the last dot (ex. `c`) have to be defined as a class variable with a type annotations.
DO NOT assign default value here.
>>> @constdef
>>> class const:
>>>    @constdef
>>>    class a:
>>>        @constdef
>>>        class b:
>>>            c: int

And just assign values in following "CONST SETTINGS" section.
>>> const.a.b.c = value

Every value `const.x.y = value` must be defined in `class const` structure.
Every value defined settings in `class const` structure must be assigned.


Use const settings
------------------

And use in source code.
>>> from const import const
>>> if const.a.b.c == value: ...
"""

# Only safe imports here, double check BEFORE add something new.
import runpy
from pathlib import Path
from typing import Optional, Union, Any, Dict, Set, Tuple, Sequence, TypeVar, Type, TYPE_CHECKING
from typing_extensions import Literal
from lib.kolang import L  # semi-safe import
from lib.indexers.defs import DirItemSource, CodeId
if TYPE_CHECKING:
    from lib.ff.menu import ContentView

T = TypeVar('T')

#: ID of source color match: PROVIDER or (PROVIDER, SOURCE).
ExSourceId = Union[str, Tuple[str, str]]


def constdef(cls: Type[T]) -> T:
    """Const section definition decorator."""

    def __init__(self):
        cls = type(self)
        ann = getattr(cls, '__annotations__', {})
        for k, v in vars(cls).items():
            if not k.startswith('_'):
                if getattr(v, '_const_def', None):
                    object.__setattr__(self, k, v)
                elif k in ann:
                    name = f'{cls.__qualname__}.{k}'
                    raise TypeError(f'Value for {name!r} is FORBIDEN, assign it in "CONST SETTINGS"')
                else:
                    raise TypeError(f'Pure class {k!r} in {cls.__qualname__!r} is FORBIDEN, use @constdef')

    def __setattr__(self, key, value):
        cls = self.__class__
        if key not in getattr(cls, '__annotations__', {}):
            raise AttributeError(f'No const attribute {cls.__qualname__}.{key}')
        if getattr(constdef, 'locked', False) and (old := getattr(self, key, ...)) is not ...:
            print(f'WARNING: redefine {cls.__qualname__}: {old!r} -> {value!r}')
            raise RuntimeError(f'WARNING: redefine {cls.__qualname__}: {old!r} -> {value!r}')
        object.__setattr__(self, key, value)

    def __repr__(self):
        return f'<{self.__class__.__qualname__}>'

    cls.__init__ = __init__
    cls.__setattr__ = __setattr__
    cls.__repr__ = __repr__
    cls._const_def = True  # type: ignore
    return cls()


all_languages = (
    'aa', 'ab', 'ae', 'af', 'ak', 'am', 'an', 'ar', 'as', 'av', 'ay', 'az', 'ba', 'be', 'bg', 'bi', 'bm', 'bn', 'bo',
    'br', 'bs', 'ca', 'ce', 'ch', 'cn', 'co', 'cr', 'cs', 'cu', 'cv', 'cy', 'da', 'de', 'dv', 'dz', 'ee', 'el', 'en',
    'eo', 'es', 'et', 'eu', 'fa', 'ff', 'fi', 'fj', 'fo', 'fr', 'fy', 'ga', 'gd', 'gl', 'gn', 'gu', 'gv', 'ha', 'he',
    'hi', 'ho', 'hr', 'ht', 'hu', 'hy', 'hz', 'ia', 'id', 'ie', 'ig', 'ii', 'ik', 'io', 'is', 'it', 'iu', 'ja', 'jv',
    'ka', 'kg', 'ki', 'kj', 'kk', 'kl', 'km', 'kn', 'ko', 'kr', 'ks', 'ku', 'kv', 'kw', 'ky', 'la', 'lb', 'lg', 'li',
    'ln', 'lo', 'lt', 'lu', 'lv', 'mg', 'mh', 'mi', 'mk', 'ml', 'mn', 'mo', 'mr', 'ms', 'mt', 'my', 'na', 'nb', 'nd',
    'ne', 'ng', 'nl', 'nn', 'no', 'nr', 'nv', 'ny', 'oc', 'oj', 'om', 'or', 'os', 'pa', 'pi', 'pl', 'ps', 'pt', 'qu',
    'rm', 'rn', 'ro', 'ru', 'rw', 'sa', 'sc', 'sd', 'se', 'sg', 'sh', 'si', 'sk', 'sl', 'sm', 'sn', 'so', 'sq', 'sr',
    'ss', 'st', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'ti', 'tk', 'tl', 'tn', 'to', 'tr', 'ts', 'tt', 'tw', 'ty',
    'ug', 'uk', 'ur', 'uz', 've', 'vi', 'vo', 'wa', 'wo', 'xh', 'xx', 'yi', 'yo', 'za', 'zh', 'zu',
)


# ----------------------------------------------------------------------------- #
# -----                          SOME DOCUMENTATION                       ----- #
# ----------------------------------------------------------------------------- #
#
# `votes` – minmum number of votes
#  -  >= 0   - the number
#  -  == -1  - skip votes at all
#  -  None   - use default from user settings


# ----------------------------------------------------------------------------- #
# -----                          CONST DEFINITION                         ----- #
# ----------------------------------------------------------------------------- #


@constdef
class const:
    """Const (low-level developper) settings."""

    @constdef
    class debug:
        enabled: bool
        tty: bool
        crash_menu: bool
        autoreload: bool

    @constdef
    class debugger:
        enabled: bool

    @constdef
    class dev:

        @constdef
        class tmdb:
            api_key: Optional[str]
            session_id: Optional[str]

        @constdef
        class trakt:
            client: Optional[str]
            secret: Optional[str]

        @constdef
        class db:
            echo: bool

    @constdef
    class core:
        exit_every_nth: int
        volatile_dbid: bool
        volatile_seasons: bool

        @constdef
        class info:
            save_cache: bool

    @constdef
    class media:
        @constdef
        class progress:
            as_watched: int

            @constdef
            class show:
                episodes_watched: bool

    @constdef
    class sources_dialog:
        index_color: str
        override_color: Dict[ExSourceId, str]

    # ----- Folders -----
    @constdef
    class folder:
        cache_to_disc: bool
        wait_for_refresh_timeout: float
        refresh_delay: float
        db_save: bool
        script_autorefresh: bool
        previous_page: Literal['never', 'always', 'on_last_page']
        max_page_jump: int
        fanart_fallback: Optional[Literal['landscape', 'poster', 'thumb', 'banner', 'clearlogo']]

        @constdef
        class style:
            future: Optional[str]
            role: Optional[str]
            broken: Optional[str]

    # ----- Indexes -----
    @constdef
    class indexer:
        region: Optional[str]

        @constdef
        class art:
            fake_thumb: bool

        @constdef
        class progressbar:
            style: str
            mode: Literal['watched', 'percent']
            width: int

            @constdef
            class fill:
                color: str
                char: str

            @constdef
            class partial:
                color: str
                char: str

            @constdef
            class empty:
                color: str
                char: str

            @constdef
            class watched:
                color: str
                char: str

        # -- Directories: main menu
        @constdef
        class navigator:
            lists_submenu: bool

        # -- Directories: movies
        @constdef
        class movies:
            discover_sort_by: Sequence[Literal['original_title.asc', 'original_title.desc',  # list in setting `movies.sort` order
                                               'popularity.asc', 'popularity.desc',
                                               'revenue.asc', 'revenue.desc',
                                               'primary_release_date.asc', 'primary_release_date.desc',
                                               'title.asc', 'title.desc',
                                               'vote_average.asc', 'vote_average.desc',
                                               'vote_count.asc', 'vote_count.desc']]
            missing_duration: int
            future_if_no_date: bool
            date_from_year: bool
            future_playable: bool

            @constdef
            class resume:
                watched_date_format: Optional[str]

            @constdef
            class top_rated:
                votes: Optional[int]

            @constdef
            class genre:
                votes: Optional[int]
                # menu: Set[int]

            @constdef
            class year:
                votes: Optional[int]

            @constdef
            class joke:
                production_company: bool
                keyword: bool

            @constdef
            class trending:
                service: Literal['tmdb', 'trakt']

            @constdef
            class cinema:
                last_days: int
                next_days: int
                use_region: bool

            @constdef
            class tv:
                page_size: int
                service: Literal['filmweb', 'onet']
                list_mode: Literal['media', 'mixed', 'folders']

            @constdef
            class new:
                votes: Optional[int]

            @constdef
            class progressbar:
                style: str
                mode: Literal['none', 'watched', 'percent', 'percent_and_watched']
                width: int

        # -- Directories: tv-shows
        @constdef
        class tvshows:
            region: Optional[str]
            discover_sort_by: Sequence[Literal['first_air_date.asc', 'first_air_date.desc',  # list in setting `tvshows.sort` order
                                               'name.asc', 'name.desc',
                                               'original_name.asc', 'original_name.desc',
                                               'popularity.asc', 'popularity.desc',
                                               'vote_average.asc', 'vote_average.desc',
                                               'vote_count.asc', 'vote_count.desc']]
            @constdef
            class top_rated:
                votes: Optional[int]

            @constdef
            class genre:
                votes: Optional[int]
                # menu: Set[int]

            @constdef
            class year:
                votes: Optional[int]

            @constdef
            class joke:
                production_company: bool

            @constdef
            class trending:
                service: Literal['tmdb', 'trakt']

            @constdef
            class premiere:
                votes: Optional[int]

            @constdef
            class progress:
                episode_folder: bool

        # -- Directories: seasones
        @constdef
        class seasons:
            no_title_labels: Sequence[str]
            with_title_labels: Sequence[str]
            override_title_by_label: bool

        # -- Directories: episodes
        @constdef
        class episodes:
            missing_duration: int
            progress_if_aired: bool
            future_if_no_date: bool
            date_from_year: bool
            future_playable: bool
            continuing_numbers: bool
            label: str

            @constdef
            class resume:
                watched_date_format: Optional[str]

            @constdef
            class progressbar:
                style: str
                mode: Literal['none', 'watched', 'percent', 'percent_and_watched']
                width: int

        # -- Directories: persons

        # -- Directories: stump indexers (keywords, companies)
        @constdef
        class stump:
            votes: Optional[int]

        # -- Directories: trakt lists
        @constdef
        class trakt:

            show_sync_entry: bool

            @constdef
            class collection:
                mixed: bool

            @constdef
            class recommendation:
                mixed: bool

            @constdef
            class mine:
                view: 'ContentView'

            @constdef
            class lists:
                watched_date_format: Optional[str]

            @constdef
            class progress:
                bar: bool
                page_size: int
                movies_page_size: int
                episodes_page_size: int
                shows_page_size: int
                shows_page_size_exact_match: bool

        # -- Directories: tmdb lists
        @constdef
        class tmdb:

            @constdef
            class favorite:
                mixed: bool

            @constdef
            class watchlist:
                mixed: bool

            @constdef
            class mine:
                view: 'ContentView'

    @constdef
    class indexer_group:

        # -- Genre menu
        @constdef
        class genres:
            translations: Dict[str, Dict[CodeId, str]]
            icons: Dict[CodeId, str]

        # -- Language menu
        @constdef
        class languages:
            default: Set[CodeId]
            top: Set[CodeId]
            groups: Tuple[DirItemSource, ...]
            votes: Optional[int]

        # -- Country menu
        @constdef
        class countries:
            default: Set[CodeId]
            top: Set[CodeId]
            groups: Tuple[DirItemSource, ...]
            votes: Optional[int]

    # ----- tmdb.org settings -----
    @constdef
    class tmdb:
        append_seasons_count: int
        append_seasons_max_count: int
        # image_languages: Sequence[str]
        get_image_mode: Literal['append', 'pull', 'full', 'all']
        language_aliases: Sequence[Sequence[str]]

    # ----- trakt.tv settings -----
    @constdef
    class trakt:

        @constdef
        class page:
            limit: int

        @constdef
        class scan:
            @constdef
            class page:
                limit: int

        @constdef
        class sync:
            startup_interval: int
            interval: int
            cooldown: int
            notification_delay: int
            wait_for_service_timeout: float

        @constdef
        class auth:
            @constdef
            class qrcode:
                size: int

            @constdef
            class code:
                color: str

    # ----- Library -----
    @constdef
    class library:
        flat_show_folder: bool

    # ----- Low level settings (don't change, you are warnend) -----
    @constdef
    class tune:
        sleep_step: float
        event_step: float

        @constdef
        class db:
            connection_timeout: float
            state_wait_read_interval: float

        @constdef
        class service:
            check_interval: float
            job_list_sleep: int
            group_update_timeout: float
            group_update_busy_dialog: bool

            @constdef
            class http_server:
                port: int
                try_count: int
                wait_for_url: float


# ----------------------------------------------------------------------------- #
# -----                          CONST SETTINGS                           ----- #
# ----------------------------------------------------------------------------- #

# --- Developing and debugging ---

#: Use more logs. Useful with `grep -f LOG` on the Linux.
const.debug.enabled = False
#: Use terminal seq (colors) in logs. Useful with `grep -f LOG` on the Linux.
const.debug.tty = False
#: Add extra context menu item: CRASH, allows restart Python interpreter.
const.debug.crash_menu = False
#: Auto-reload modules on changes.
const.debug.autoreload = False

#: Use remote debugger (debugpy, vscode, etc.). Function setup_debugger() in local.py must be declared.
const.debugger.enabled = False

#: Override TMDB api_key for tests.
const.dev.tmdb.api_key = None
#: Override TMDB session_id for tests.
const.dev.tmdb.session_id = None
#: Override Trakt.tv client_id for tests.
const.dev.trakt.client = None
#: Override Trakt.tv client_secret for tests.
const.dev.trakt.secret = None

#: Echo all DB queries.
const.dev.db.echo = False


# --- Core ---

#: Exit (close Python interpreter) for every nth plugin calls.
const.core.exit_every_nth = 25
#: Use service to keep volatile DBID (for seasons only at the moment).
const.core.volatile_dbid = True
#: Use volatile DBID in all sesons. It allows to monitor kodi operations on seasons.
#: To work needs const.core.volatile_dbid set to true.
const.core.volatile_seasons = True

#: Save [ff]info media cache.
const.core.info.save_cache = False


# --- Media (general) ---

# #: Low percentage limit. Less then means not watched.
# const.media.progress.min = 1
#: Watching percent count as watched.
const.media.progress.as_watched = 85
#: Count show and season progress by full watched episodes (ignore partially watched episodes).
const.media.progress.show.episodes_watched = True

# ----- Sources -----

#: Color of the list item index (1/99).
const.sources_dialog.index_color = 'B3FFFFFF'

#: Override source colors.
const.sources_dialog.override_color = {
}


# ----- Folders -----

#: Use cacheToDisk in xbmcplugin.endOfDirectory().
const.folder.cache_to_disc = False
#: How long wait for HTTP server sync on directory refresh.
const.folder.wait_for_refresh_timeout = 5.0
#: Extra delay if refresh is detected to allow service close the "folder-ready" semafor.
const.folder.refresh_delay = 0.5
#: Save folder info into DB (old way). Use HTTP /folder instead.
const.folder.db_save = False
# If FF is caled as script (handler == -1) and directory is building, try to refresh container.
const.folder.script_autorefresh = True
# When show previous page item (except first page even if 'always'):
#   - `never`        - never show
#   - `always`       - on every page (except first page)
#   - `on_last_page` - onlu on last page (except first page)
const.folder.previous_page = 'on_last_page'
# Maximum page number to jump to.
const.folder.max_page_jump = 500
# Item fanart fallback (None, 'landscape', ...). If None or when art missing, plugin fanart is used.
const.folder.fanart_fallback = 'landscape'

#: Format for future item (unaired, non-premiered).
const.folder.style.future = '[COLOR darkred][I]{}[/I][/COLOR]'
#: Format for item with role.
const.folder.style.role = '{item.label} [COLOR gray][{item.role}][/COLOR]'
#: Format for broken items (eg. not found in TMDB). Eg. '{} [COLOR red]![/COLOR]'
const.folder.style.broken = None

# ----- Indexes -----

# Default region.
const.indexer.region = 'PL'
# Fake thumb: alias to landscape (for episode) and poster (for other).
const.indexer.art.fake_thumb = True

# Style to update description (plot). Singe '{…}' means progress formating, double '{{}}' means description formating.
const.indexer.progressbar.style = '[B]{progressbar} {percent}%[/B]\n{{}}'
# Progress bar source mode (watched, percent).
const.indexer.progressbar.mode = 'watched'
# Progress bar width (number of characters).
const.indexer.progressbar.width = 50
# Fill element (watched) color (kodi color eg. darkred, FFCC9900).
const.indexer.progressbar.fill.color = 'darkgreen'
# Fill element (watched) character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.fill.char = 'l'
# Partial filled element (watched & unwatched) color (kodi color eg. darkred, FFCC5500).
const.indexer.progressbar.partial.color = 'darkgreen'
# Partial filled element (watched & unwatched) character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.partial.char = 'ı'
# Empty element (unwatched) color (kodi color eg. darkred, gray, FF999999 or empty).
const.indexer.progressbar.empty.color = 'gray'
# Empty element (unwatched) character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.empty.char = 'ı'
# Already watched element on watching again color (kodi color eg. darkred, gray, FF999999 or empty).
const.indexer.progressbar.watched.color = 'white'
# Already watched element on watching again character (eg. ' ', '|', 'l', 'ı', '•', '⸋').
const.indexer.progressbar.watched.char = const.indexer.progressbar.empty.char

# -- Directories: main menu

#: Show Trakt, TMDB, IMDB in sub-menu. If False, show them in main menu.
const.indexer.navigator.lists_submenu = False

# -- Directories: movies

# Sort by `movies.sort` option index (popularity, year, ...) in movie discovery.
const.indexer.movies.discover_sort_by = (
    'popularity.desc',
    'primary_release_date.desc',
    'title.asc',
)
#: Time in seconds for movies / episodes without duration.
const.indexer.movies.missing_duration = 0
#: Means future (not premiered yet) movie if no date (None/null).
const.indexer.movies.future_if_no_date = True
#: Generate date from "year" (year-01-01) value if no movie date defined.
const.indexer.movies.date_from_year = False
#: Future (not premiered yet) movie can by played.
const.indexer.movies.future_playable = True
# Last watched date-time format in movie resume list. None if disabled.
const.indexer.movies.resume.watched_date_format = '%Y-%m-%d'
#: Override vote count for top-rated movies.
const.indexer.movies.top_rated.votes = 300
#: Override vote count for movies by genre.
const.indexer.movies.genre.votes = 50
#: Override vote count for movies by year.
const.indexer.movies.year.votes = 100
#: List of movie genres (main menu level).    NOT USED NOW !!!
# const.indexer.movies.genre.menu = {
#     12, 14, 16, 18, 27, 28, 35, 36, 37, 53, 80, 99, 878, 9648, 10402, 10749, 10751, 10752,
# }
#: Joke. Show hundreds of thousands production_companies.
const.indexer.movies.joke.production_company = False
#: Joke. Show hundreds of thousands keywords.
const.indexer.movies.joke.keyword = False
#: Trending source (tmdb, trakt):
const.indexer.movies.trending.service = 'trakt'
# Number of last days to see movies in cinema.
const.indexer.movies.cinema.last_days = 60
# Number of next days to see movies in cinema (ongoing).
const.indexer.movies.cinema.next_days = 4
# Filter cinema movies by selected region.
const.indexer.movies.cinema.use_region = False
#: Default Movies in TV service (filmweb, onet).
const.indexer.movies.tv.page_size = 50
#: Default Movies in TV service (filmweb, onet).
const.indexer.movies.tv.service = 'filmweb'
#: Movies in TV (fanfilm) list mode:
#: - movies (all movies)
#: - mixed (movie if single or folder if many)
#: - folders (folder always)
const.indexer.movies.tv.list_mode = 'mixed'
# New movies votes.
const.indexer.movies.new.votes = 50
#: Movie style to update description (plot). Singe '{…}' means progress formating, double '{{}}' means description formating.
const.indexer.movies.progressbar.style = const.indexer.progressbar.style
#: Movie progress bar source mode (none, watched, percent, percent_and_watched).
const.indexer.movies.progressbar.mode = 'percent'
#: Movie progress bar width (number of characters).
const.indexer.movies.progressbar.width = const.indexer.progressbar.width

# -- Directories: tv-shows

#: Default region for tv-shows.
const.indexer.tvshows.region = const.indexer.region
# Sort by `tvshows.sort` option index (popularity, year, ...) in tv-show discovery.
const.indexer.tvshows.discover_sort_by = (
    'popularity.desc',
    'first_air_date.desc',
    'name.asc',
)
#: Override vote count for top-tated tv-shows.
const.indexer.tvshows.top_rated.votes = 200
#: Override vote count for tvshow by genre.
const.indexer.tvshows.genre.votes = 50
#: Override vote count for tvshow by year.
const.indexer.tvshows.year.votes = 100
#: List of tvshow genres (main menu level).    NOT USED NOW !!!
# const.indexer.tvshows.genre.menu = {
#     16, 18, 35, 37, 80, 99, 9648, 10751, 10759, 10762, 10764, 10765, 10766, 10767, 10768,
# }
#: Joke. Show hundreds of thousands production_companies.
const.indexer.tvshows.joke.production_company = False
#: Trending source (tmdb, trakt):
const.indexer.tvshows.trending.service = 'trakt'
# Minimal numer of votes in tv-show premier (new tv-shows).
const.indexer.tvshows.premiere.votes = 20
# If True, show next episode as link to season folder
# if False, show next episode as playable video.
const.indexer.tvshows.progress.episode_folder = True

# -- Directories: seasons

#: Season label format if no season title, selected by user setting `tvshow.season_label`.
#: Season FFItem is available as `item`.
const.indexer.seasons.no_title_labels = (
    '{locale.season} {season}',  # Season 1
    '{locale.season} {season}',  # Season 1
    '{locale.season} {season}',  # Season 1
)
#: Season label format if season has its own title, selected by user setting `tvshow.season_label`.
#: Season FFItem is available as `item`.
const.indexer.seasons.with_title_labels = (
    '{locale.season} {season}',            # Season 1
    '{locale.season} {season} – {title}',  # Season 1 – Title
    '{season}. {title}',                   # 1. Title
)
#: Force override season title by generated label. Should be false.
const.indexer.seasons.override_title_by_label = False

# -- Directories: episodes

#: Time in seconds for movies / episodes without duration.
const.indexer.episodes.missing_duration = 0
#: Skip future (not aired yet) episodes in season (and show) progress.
const.indexer.episodes.progress_if_aired = True
#: Means future (not aired yet) episode if no date (None/null).
const.indexer.episodes.future_if_no_date = True
#: Generate date from "year" (year-01-01) value if no episode date defined.
const.indexer.episodes.date_from_year = False
#: Future (not aired yet) episode can by played.
const.indexer.episodes.future_playable = True
#: It True, episodes number must be for 1 to N (faster but dangerous).
const.indexer.episodes.continuing_numbers = False
#: Episode label format.
const.indexer.episodes.label = '{season}x{episode:02d}. {title}'
# Last watched date-time format in episode resume list. None if disabled.
const.indexer.episodes.resume.watched_date_format = '%Y-%m-%d'
#: Episode style to update description (plot). Singe '{…}' means progress formatting, double '{{}}' means description formatting.
const.indexer.episodes.progressbar.style = const.indexer.progressbar.style
#: Episode progress bar source mode (none, watched, percent, percent_and_watched).
const.indexer.episodes.progressbar.mode = 'percent'
#: Episode progress bar width (number of characters).
const.indexer.episodes.progressbar.width = const.indexer.progressbar.width

# -- Directories: persons

# -- Directories: stump idexers

const.indexer.stump.votes = 0

# -- Directories: lists

#: Trakt mixed collections enabled.
const.indexer.trakt.collection.mixed = False
#: Trakt mixed recommendations enabled.
const.indexer.trakt.recommendation.mixed = False
#: Trakt my list (list of the lists) view.
const.indexer.trakt.mine.view = 'sets'
# Watched date-time format in trkat lists (like history). None if disabled.
const.indexer.trakt.lists.watched_date_format = '%Y-%m-%d'
#: Show ••• progress bar for shows.
const.indexer.trakt.progress.bar = True  # XXX: NOT USED
#: Split any media progress into pages (default value).
const.indexer.trakt.progress.page_size = 20
#: Split watching movies into pages.
const.indexer.trakt.progress.movies_page_size = const.indexer.trakt.progress.page_size
#: Split watching episodes into pages.
const.indexer.trakt.progress.episodes_page_size = const.indexer.trakt.progress.page_size
#: Split tv-shows progress into pages.
const.indexer.trakt.progress.shows_page_size = const.indexer.trakt.progress.page_size
# Exact match for tv-shows progress into pages size. If flase page could be smaller, but faster.
const.indexer.trakt.progress.shows_page_size_exact_match = True
#: If true, show entry in listing: /tools/trakt/entry.
const.indexer.trakt.show_sync_entry = True

#: Trakt mixed collections enabled.
const.indexer.tmdb.favorite.mixed = False
#: Trakt mixed recommendations enabled.
const.indexer.tmdb.watchlist.mixed = False
#: Trakt my list (list of the lists) view.
const.indexer.tmdb.mine.view = 'sets'

# -- Genre menu

#: Fix TMDB genres translations [kodi-language][tmdb-genre-id].
const.indexer_group.genres.translations = {
    'pl-PL': {
        10762: 'Dla dzieci',
        10764: 'Reality TV',
        10766: 'Romans',
        10767: 'Talk Shows',
        10768: 'Wojna i polityka',
    },
}
#: Genre icons by TMDB genre ID.
const.indexer_group.genres.icons = {
    12: 'Adventure.png',
    14: 'Fantasy.png',
    16: 'Animation.png',
    18: 'Drama.png',
    27: 'Horror.png',
    28: 'Action.png',
    35: 'Comedy.png',
    36: 'History.png',
    37: 'Western.png',
    53: 'Thriller.png',
    80: 'Crime.png',
    99: 'Documentary.png',
    878: 'Sci-Fi.png',
    9648: 'Mystery.png',
    10402: 'Music.png',
    10749: 'Romance.png',
    10751: 'Family.png',
    10752: 'War.png',
    10759: 'Action and Adventure.png',
    10762: 'Kids.png',
    10764: 'Reality_show.png',
    10765: 'Sci_fi_and_fantasy.png',
    10766: 'Romance.png',
    10767: 'Television.png',
    10768: 'Historical.png',
}

# -- Language menu

#: Set of favorite languages.
const.indexer_group.languages.default = {
    'cs', 'de', 'en', 'es', 'fr', 'it', 'ja', 'ko', 'pl', 'sv', 'uk', 'zh',
}
#: Set of top languages from favorites. Current Kodi language will be on top too.
const.indexer_group.languages.top = {
    'pl',
}
#: Custom language groups. Use `|` for OR, `,` for AND.
const.indexer_group.languages.groups = (
    # DirItemSource('pl|lt|uk|be', "I Rzeczpospolita"),
)
#: Override vote count for media by language. None for use default.
const.indexer_group.languages.votes = 0

# -- Country menu

#: Set of favorite countries.
const.indexer_group.countries.default = {
    'GB', 'CN', 'CZ', 'DE', 'DK', 'ES', 'FR', 'IT', 'JP', 'KR', 'PL', 'SE', 'UK', 'US',
}
#: Set of top countries from favorites. Current Kodi region will be on top too.
const.indexer_group.countries.top = {
    'PL',
}
#: Custom country groups. Use `|` for OR, `,` for AND.
const.indexer_group.countries.groups = (
    DirItemSource('DK|FI|IS|NO|SE', L(30102, 'Scandinavian')),  # Scandinavian
)
#: Override vote count for media by country. None for use default.
const.indexer_group.countries.votes = 0


# ----- tmdb.org settings -----

#: =season/N in main request. Total max is 20 for all appends.
const.tmdb.append_seasons_count = 10
#: =season/N in next seasons-only requests. Total max is 20 for all appends.
const.tmdb.append_seasons_max_count = 20
#: Default languages used in `include_image_language` when info get with `append_to_response=images`.
# const.tmdb.image_languages = all_languages
#: Mode of image getting:
#:   - append  - use `append_to_response=images` with fixed `include_image_language`, no poster at all often
#:   - pull    - like `append` but get images in next request if fails (no images)
#:   - full    - always make two requests, support all services (it is forced for non-tmdb services, e.g. fanart.tv)
#:   - all     - use /images to get all images in concurrent request
const.tmdb.get_image_mode = 'all'
# Langauge code aliases. Non-ISO-631-1 TMDB extensions.
const.tmdb.language_aliases = (
    ('zh', 'cn'),
)


# ----- trakt.tv settings -----

#: Page size (page limit) in trakt.tv for directory.
const.trakt.page.limit = 20
#: Page limit in scan all pages in trakt.tv. DO NOT edit.
const.trakt.scan.page.limit = 100
#: Interval of first trakt sync (playback, watched, etc) after service started.
const.trakt.sync.startup_interval = 2
#: Interval of cyclic trakt sync (playback, watched, etc) refresh.
const.trakt.sync.interval = 300
#: Time of cool-down before next sync starts. Used with series sync reqiests.
const.trakt.sync.cooldown = 30
#: How long delay the sync notification. Notification is hidden if sync take less time.
const.trakt.sync.notification_delay = 3
#: Timeout for wait synchronic trakt sync (via service).
const.trakt.sync.wait_for_service_timeout = 180
#: Trakt.tv auth link QR-Code scale.
const.trakt.auth.qrcode.size = 20
#: Trakt.tv auth link code color.
const.trakt.auth.code.color = 'FFA3A307'


# ----- Library -----

# Force always flat folder for shows (old format).
# If false new show folders uses season subfolders, existing old one uses flat structure.
# If true always use flat folder structure.
const.library.flat_show_folder = False


# ----- Low level settings (don't change, you are warned) -----

#: Interval in internal sleep loop.
const.tune.sleep_step = 0.1
#: Interval in internal threads.Event.wait() loop.
const.tune.event_step = 0.1

#: Sqlite3 connection timeout (python default is 5.0).
const.tune.db.connection_timeout = 3.0
#: DB state.wait_for_value() reading interval.
const.tune.db.state_wait_read_interval = 0.2

#: Interval in internal sleep loop.
const.tune.service.check_interval = 3
#: Interval in internal sleep loop.
const.tune.service.job_list_sleep = 1
#: Interval for group update (kodi notification for seazon or show).
const.tune.service.group_update_timeout = 5
#: Show busy dialog on group update (kodi notification for seazon or show).
const.tune.service.group_update_busy_dialog = True
#: Port number for proxy HTTP server. Zero means take any free port.
const.tune.service.http_server.port = 0
#: Number of tries to get FF service URL.
const.tune.service.http_server.try_count = 12
#: Wait between get FF service URL tries.
const.tune.service.http_server.wait_for_url = .25


# ----------------------------------------------------------------------------- #
# -----                              THE END                              ----- #
# ----------------------------------------------------------------------------- #


def __getattr__(key: str) -> Any:
    """Return const settings directly as module value."""
    if key and key[0].islower():
        return getattr(const, key)
    raise AttributeError(f'Module {__name__} has o attribute {key!r}')


# dummy function
def setup_debugger():
    """Configure remote debugger. Override this in local.py."""
    from lib.ff.log_utils import fflog
    fflog('setup_debugger() is missing in local.py. Your debugger is not set.')


def run_debugger():
    """Run remote debugger connection."""
    if const.debugger.enabled:
        from lib.ff.log_utils import fflog_exc
        try:
            setup_debugger()
        except Exception:
            fflog_exc()


def _data_path() -> Path:
    """Returns plugin data folder path."""
    from xbmcaddon import Addon
    from xbmcvfs import translatePath
    return Path(translatePath(Addon().getAddonInfo('profile')))


def _check_const_assignment(obj):
    """Check if all defined `class const` settings are assigned."""
    cls = type(obj)
    elements = {k: v for k, v in vars(obj).items() if not k.startswith('_')}
    if ann := getattr(cls, '__annotations__', None):
        if missing := ann.keys() - elements.keys():
            sets = ', '.join(sorted(missing))
            raise TypeError(f'{cls.__qualname__}: missing settings: {sets}')
    for sub in elements.values():
        if getattr(sub, '_const_def', None):
            _check_const_assignment(sub)


_check_const_assignment(const)


# --- must be on the bottom of the file

_local_path: Path = _data_path() / 'local.py'
if not _local_path.exists():
    try:
        _local_path.write_text(('"""Local const settings."""\n\nfrom const import const\n\n\n'
                                '# --- Your custom settings\n\n# const.NAME = VALUE\n'), encoding='utf-8')
    except IOError as exc:
        from lib.ff.log_utils import fflog
        fflog(f'Creating local file {_local_path} failed: {exc}')
if _local_path.is_file():
    try:
        globals().update((k, v)
                         for k, v in runpy.run_path(_local_path).items()
                         if not k.startswith('__'))
    except IOError as exc:
        from lib.ff.log_utils import fflog
        fflog(f'Reading local file {_local_path} failed: {exc}')

# end of const definitions
constdef.locked = True  # type: ignore
