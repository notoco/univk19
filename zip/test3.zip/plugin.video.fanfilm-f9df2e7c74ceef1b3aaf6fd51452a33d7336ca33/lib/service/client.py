"""
Simple FF Service client to use it in FF plugin.
"""

from typing import Optional, Union, Dict, Iterable, ClassVar

import requests

from ..ff.log_utils import fflog, fflog_exc
from ..ff.settings import settings
from ..ff.url import URL
from ..ff.kotools import xsleep
from ..ff.db import state
from ..defs import MediaRef
from .misc import PluginRequestInfo
from const import const


class ServiceClient:
    """Simple FF Service client."""

    LOG_EXCEPTION: ClassVar[bool] = True

    def __init__(self, *, port: Optional[int] = const.tune.service.http_server.port) -> None:
        self._url: Optional[str] = None
        if port:
            self._url = f'http://127.0.0.1:{port}/'

    @property
    def url(self) -> str:
        """Service HTTP server URL."""
        if self._url is None:
            for i in range(const.tune.service.http_server.try_count or 1):
                url = state.get('url', module='service')
                if url:
                    self._url = url
                    break
                if not i:
                    fflog('No FF service URL, wait a little')
                xsleep(const.tune.service.http_server.wait_for_url or .01)
            else:
                fflog('ERROR: No FF service URL')
                return 'http://127.0.0.1:8123/'  # invalid URL (invalid port)
        return self._url

    def foler_ready(self, *, timeout: Optional[float] = None) -> bool:
        """Wait for folder ready (watching progress update)."""
        if timeout is None:
            timeout = const.folder.wait_for_refresh_timeout
        try:
            data = requests.post(f'{self.url}folder/ready', timeout=timeout + 0.5, json={'timeout': timeout}).json()
            return data.get('ready', False)
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
            return False

    def plugin_request_info(self) -> PluginRequestInfo:
        """Get folder info."""
        timeout = 3.0
        try:
            data = requests.get(f'{self.url}plugin/request/info', timeout=timeout + 0.5).json()
            return PluginRequestInfo.__from_json__(data['plugin_request'])
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
            return PluginRequestInfo()

    def plugin_request_enter(self, url: Union[URL, str]) -> PluginRequestInfo:
        """Notify server about FF plugin folder enter."""
        if not isinstance(url, str):
            url = str(url)
        timeout = 3.0
        try:
            data = requests.post(f'{self.url}plugin/request/enter', timeout=timeout + 0.5, json={'url': url}).json()
            info = PluginRequestInfo.__from_json__(data['plugin_request'])
            fflog(f'[FOLDER] ENTER  >>>>>  {info}')
            return PluginRequestInfo.__from_json__(data['plugin_request'])
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
            return PluginRequestInfo()

    def plugin_request_exit(self, *, folder: bool = True) -> PluginRequestInfo:
        """Notify server about FF plugin folder exit."""
        timeout = 3.0
        try:
            data = requests.post(f'{self.url}plugin/request/exit', timeout=timeout + 0.5, json={'folder': folder}).json()
            return PluginRequestInfo.__from_json__(data['plugin_request'])
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
            return PluginRequestInfo()

    folder_info = plugin_request_info
    folder_enter = plugin_request_enter
    folder_exit = plugin_request_exit

    def get_dbid_ref(self, dbid: int, *, timeout: Optional[float] = None) -> Optional[MediaRef]:
        """Get ref by volatile dbid."""
        req_timeout = None if timeout is None else timeout + .5
        try:
            data = requests.get(f'{self.url}dbid/{dbid}', timeout=req_timeout).json()
            if data['status'] == 'ok':
                return MediaRef(**data['ref'])
            msg = data.get('message', '')
            fflog(f'Get volatile DBID failed: {msg}')
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return None

    def get_dbid_ref_dict(self, dbid_list: Iterable[int], *, timeout: Optional[float] = None) -> Dict[int, MediaRef]:
        """Get refs by volatile dbid list, return dict[dbid] = ref."""
        req_timeout = None if timeout is None else timeout + .5
        try:
            data = requests.get(f'{self.url}dbid/', params={'dbid': ','.join(map(str, dbid_list))}, timeout=req_timeout).json()
            if data['status'] == 'ok':
                return {it['dbid']: MediaRef(**jref) for it in data['refs'] if it and (jref := it['ref'])}
            msg = data.get('message', '')
            fflog(f'Get volatile DBID failed: {msg}')
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return {}

    def create_dbid(self, ref: MediaRef, *, timeout: Optional[float] = None) -> Optional[int]:
        """Create new volatile dbid for given ref."""
        req_timeout = None if timeout is None else timeout + .5
        try:
            data = requests.post(f'{self.url}dbid', timeout=req_timeout, json={'ref': ref.as_dict()}).json()
            if data['status'] == 'ok':
                return data['dbid']
            msg = data.get('message', '')
            fflog(f'Create volatile DBID failed: {msg}')
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return None

    def create_dbid_dict(self, refs: Iterable[MediaRef], *, timeout: Optional[float] = None) -> Dict[MediaRef, int]:
        """Create new volatile dbid for given ref."""
        req_timeout = None if timeout is None else timeout + .5
        try:
            data = requests.post(f'{self.url}dbid', timeout=req_timeout, json={'refs': [ref.as_dict() for ref in refs]}).json()
            if data['status'] == 'ok':
                return {MediaRef(**jref): it['dbid'] for it in data['refs'] if it and (jref := it['ref'])}
            msg = data.get('message', '')
            fflog(f'Create volatile DBID failed: {msg}')
        except Exception:
            if self.LOG_EXCEPTION:
                fflog_exc()
        return {}

    def trakt_sync(self) -> Optional[bool]:
        """Synchronize trakt.tv."""
        try:
            resp = requests.post(f'{self.url}trakt/sync', json={'timeout': const.trakt.sync.wait_for_service_timeout}).json()
        except requests.ConnectionError as exc:
            fflog(f'Connection to sevice {self.url} failed: {exc}')
        else:
            try:
                return bool(resp.get('changed'))
            except Exception:
                if self.LOG_EXCEPTION:
                    fflog_exc()
        return None


#: Default global service client.
service_client = ServiceClient()
