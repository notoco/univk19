# -*- coding: utf-8 -*-
"""
    FanFilm Add-on
    Copyright (C) 2024 :)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import base64
import re
from typing import Dict, List, Optional
from urllib.parse import quote, quote_plus

import requests

from lib.ff import cache, cleantitle, control, source_utils, utils
from lib.ff.client import parseDOM
from lib.ff.log_utils import fflog, fflog_exc

# Disable InsecureRequestWarning
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

# Constants
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

HEADERS = {
    "Host": "filman.cc",
    "User-Agent": USER_AGENT,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
    "DNT": "1",
    "Upgrade-Insecure-Requests": "1",
}


class source:
    def __init__(self):
        self.priority = 1
        self.language = ["pl"]
        self.domains = ["filman.cc"]
        self.base_link = "https://filman.cc"
        self.login_link = "https://filman.cc/logowanie"
        self.search_link = "https://filman.cc/item?phrase={title}"
        self.username = control.settings.getString("filman.username")
        self.password = control.settings.getString("filman.password")
        self.session = requests.Session()
        self.session.cookies = requests.cookies.RequestsCookieJar()
        self.initialized = False

    def initialize_session(self):
        """Initialize the session by fetching the home and login pages."""
        try:
            self.session.headers.update(HEADERS)
            self.get_response(self.base_link)  # Initialize session
            self.get_response(self.login_link)  # Get login page
            self.initialized = True
        except Exception as e:
            fflog_exc(e, title="Session initialization error")

    def login(self):
        """Login to the service."""
        try:
            if not self.initialized:
                self.initialize_session()

            login_data = {"login": self.username, "password": self.password, "remember": "on", "submit": ""}
            response_text, cookies_str = self.get_response(self.login_link, data=login_data, method="post")

            if "Wyloguj" in response_text:
                cookies = "; ".join([f"{x}={y}" for x, y in self.session.cookies.get_dict().items()])
                cache.cache_insert("filman_cookie", cookies, control.sourcescacheFile)
                return True
            return False
        except Exception as e:
            fflog_exc(e, title="Login error")
            return False

    def is_logged_in(self):
        """Check if user is logged in."""
        try:
            cookies_str = cache.cache_get("filman_cookie", control.sourcescacheFile)
            if cookies_str:
                cookies_str = cookies_str.get("value")
                cookies = dict(cookie.split("=") for cookie in cookies_str.split("; "))
                self.session.cookies.update(cookies)
                if self.check_login_status():
                    return True
                else:
                    # Clear the cookies if the login status check fails
                    cache.remove_partial_key("filman_cookie")
                    self.session.cookies.clear()
                    # Attempt to login again
                    return self.login()
            return False
        except Exception as e:
            fflog_exc(e, title="Check login status error")
            return False

    def check_login_status(self):
        """Check login status."""
        try:
            response = self.session.get(self.base_link, headers=HEADERS, verify=False)
            if "Wyloguj" in response.text:
                return True
            else:
                return False
        except Exception as e:
            fflog_exc(e, title="Check login status error")
            return False

    def search(self, title, localtitle, year):
        """Search for a movie."""
        try:
            if not self.login():
                fflog("Login failed")
                return None

            fflog("Login successful")

            # Cache normalized titles to avoid redundant processing
            normalized_titles = set()
            for t in [title, localtitle]:
                normalized_titles.add(t)
                normalized_titles.add(cleantitle.normalize(t).lower())
                normalized_titles.add(cleantitle.getsearch(t))
                normalized_titles.add(cleantitle.getsearch(t.split("–")[0].replace("-", " ")))

            results = []
            for normalized_title in normalized_titles:
                url = self.search_link.format(title=quote_plus(normalized_title))
                content, _ = self.get_response(url)
                results.append((normalized_title, content))

            films = []
            for title, content in results:
                try:
                    posters = re.findall(r'<div class="poster">(.*?)</div>', content, re.DOTALL)
                    for result in posters:
                        src = re.findall(r'<img src="(.*?)"', result)[0].replace("thumb", "big")
                        href = re.findall(r'<a href="(.*?)"', result)[0]
                        film_title = re.findall(r'data-title="(.*?)"', result)[0]

                        if src.startswith("//"):
                            src = "http:" + src

                        film = {
                            "href": href.replace("/movies/", "/film/"),
                            "title": utils.decode_title_from_latin1(utils.escape_special_characters(film_title)),
                        }
                        title_parts = film["title"].split("/")

                        primary_words = cleantitle.normalize(title_parts[0].strip()).lower()
                        ratio_primary = utils.calculate_similarity_ratio(title, primary_words)
                        levenshtein_primary = utils.calculate_levenshtein_distance(title, primary_words)
                        film.update(
                            {
                                "ratio": ratio_primary,
                                "levenshtein": levenshtein_primary,
                            }
                        )
                        films.append(film)

                        if len(title_parts) > 1:
                            words = cleantitle.normalize(title_parts[1].strip()).lower()
                            secondary_film = film.copy()
                            secondary_film.update(
                                {
                                    "ratio": utils.calculate_similarity_ratio(title, words),
                                    "levenshtein": utils.calculate_levenshtein_distance(title, words),
                                }
                            )
                            films.append(secondary_film)
                except Exception as e:
                    fflog_exc(e, title="Error processing search result")

            films = sorted(films, key=lambda x: (x["ratio"], -x["levenshtein"]), reverse=True)
            for film in films:
                try:
                    if film["levenshtein"] <= 20 and 0.40 < film["ratio"] <= 1.0:
                        if "/film/" in film["href"] and str(year) in film["href"]:
                            return film["href"]
                except Exception as e:
                    fflog_exc(e, title="Error processing sorted film list")

            for film in films:
                try:
                    normalized_search_title = cleantitle.normalize(utils.decode_title_from_latin1(title)).lower()
                    normalized_film_title = cleantitle.normalize(film["title"]).lower()
                    if normalized_film_title.startswith(normalized_search_title):
                        if "/film/" in film["href"] and str(year) in film["href"]:
                            return film["href"]
                except Exception as e:
                    fflog_exc(e, title="Error processing startswith check")

            previous_year = str(int(year) - 1)
            return self.search(title, localtitle, previous_year)

        except Exception as e:
            fflog_exc(e, title="Search error")
            return None

    def movie(self, imdb, title, localtitle, aliases, year):
        """Search for a movie."""
        return self.search(title, localtitle, year)

    def tvshow(self, imdb, tmdb, tvshowtitle, localtvshowtitle, aliases, year):
        """Search for a TV show."""
        pl_alias = next((alias for alias in aliases if alias.get("country") == "pl"), None)
        pl_title = pl_alias.get("title", "") if pl_alias else ""
        return (tvshowtitle, localtvshowtitle, pl_title), year

    def episode(self, url, imdb, tmdb, title, premiered, season, episode):
        """Search for a TV show episode."""
        # Extract title components from the URL
        original_title = url[0][0]
        local_title = url[0][1]
        pl_alias = url[0][2]

        # Extract the year from the URL
        self.year = int(url[1])

        # Format the episode number to the standard format "sXXeXX"
        ep_no = self._format_episode_number(season, episode)

        # Perform the episode search with the extracted and formatted parameters
        return self.search_ep(original_title, local_title, self.year, pl_alias, ep_no)

    def _format_episode_number(self, season, episode):
        """Format season and episode numbers to the standard 'sXXeXX' format."""
        season_str = str(season).zfill(2)
        episode_str = str(episode).zfill(2)
        return f"s{season_str}e{episode_str}"

    def search_ep(
        self, title: str, localtitle: str, year: str, pl_alias: str, ep_no: str, year_flag: bool = False
    ) -> Optional[str]:
        """Search for a TV show episode."""
        try:
            if not self.login():
                fflog("Login failed")
                return None

            fflog("Login successful")
            normalized_titles = self._get_normalized_titles([title, localtitle, pl_alias])

            results = self._fetch_search_results(normalized_titles)

            tvshows = self._process_search_results(results, title, year)
            for tvshow in tvshows:
                url = self._extract_episode_url(tvshow, ep_no)
                if url:
                    return url

            for tvshow in tvshows:
                url = self._extract_episode_url(tvshow, ep_no, check_startswith=True, search_title=title)
                if url:
                    return url

            if not year_flag:
                return self.search_ep(title, localtitle, str(int(year) - 1), pl_alias, ep_no, year_flag=True)

            return None
        except Exception as e:
            fflog_exc(e, title="Search error")
            return None

    def _get_normalized_titles(self, raw_titles: List[str]) -> set:
        normalized_titles = {cleantitle.normalize(t).lower() for t in raw_titles if t}
        normalized_titles.update({cleantitle.getsearch(t).lower() for t in raw_titles if t})
        normalized_titles.update(
            {cleantitle.getsearch(t.split("–")[0].replace("-", " ")).lower() for t in raw_titles if t}
        )
        return normalized_titles

    def _fetch_search_results(self, normalized_titles: set) -> List[tuple]:
        results = []
        for normalized_title in normalized_titles:
            url = self.search_link.format(title=quote_plus(normalized_title))
            content, _ = self.get_response(url)
            results.append((normalized_title, content))
        return results

    def _process_search_results(self, results: List[tuple], title: str, year: int) -> List[Dict[str, str]]:
        tvshows = []
        should_break = False
        title = title.lower()
        for normalized_title, content in results:
            if should_break:
                break
            try:
                # Wzór wyrażenia regularnego do wyciągnięcia bloków "poster" wraz z rokiem
                pattern = r'(<div class="poster">.*?</div>)\s*<div class="film_year">(\d{4})</div>'

                # Znajdź wszystkie pasujące bloki wraz z rokiem
                matches = re.findall(pattern, content, re.DOTALL)
                # Przetwarzaj wyniki
                for result, film_year in matches:
                    tvshow = self._extract_tvshow_info(result)
                    if "/movies/" in tvshow['href']:
                        continue
                    tvshow.update({"year": film_year})
                    if not tvshow or str(year) != self._fix_year(normalized_title, film_year):
                        continue
                    primary_words, ratio_primary, levenshtein_primary = self._calculate_similarity(
                        tvshow["title"].split("/")[0].strip().lower(), normalized_title
                    )
                    tvshow.update({"ratio": ratio_primary, "levenshtein": levenshtein_primary})
                    tvshows.append(tvshow)

                    if ratio_primary == 1 or levenshtein_primary == 0:
                        should_break = True
                        break

                    if len(tvshow["title"].split("/")) > 1:
                        secondary_tvshow = self._process_secondary_title(tvshow, normalized_title)
                        tvshows.append(secondary_tvshow)

                        if secondary_tvshow["ratio"] == 1 or secondary_tvshow["levenshtein"] == 0:
                            should_break = True
                            break
            except Exception as e:
                fflog_exc(e, title="Error processing search result")
        tvshows = sorted(tvshows, key=lambda x: (x["ratio"], -x["levenshtein"]), reverse=True)
        return tvshows
    
    def _fix_year(self, title: str, year: str):
        if "gra o tron" in title.lower():
            return "2011"
        if "mr. robot"  in title.lower():
            return "2015"
        else:
            return year

    def _extract_tvshow_info(self, result: str) -> Dict[str, str]:
        try:
            src = re.findall(r'<img src="(.*?)"', result)[0].replace("thumb", "big")
            href = re.findall(r'<a href="(.*?)"', result)[0]
            tvshow_title = re.findall(r'data-title="(.*?)"', result)[0]

            if src.startswith("//"):
                src = "http:" + src

            tvshow = {
                "href": href,
                "title": utils.decode_title_from_latin1(utils.escape_special_characters(tvshow_title)),
            }
            return tvshow
        except IndexError:
            return {}

    def _calculate_similarity(self, tvshow_title: str, search_title: str) -> tuple:
        search_title = cleantitle.normalize(search_title)
        title_parts = tvshow_title.split("/")
        primary_words = cleantitle.normalize(title_parts[0].strip().lower())
        ratio_primary = utils.calculate_similarity_ratio(search_title, primary_words)
        levenshtein_primary = utils.calculate_levenshtein_distance(search_title, primary_words)
        return primary_words, ratio_primary, levenshtein_primary

    def _process_secondary_title(self, tvshow: Dict[str, str], search_title: str) -> Dict[str, str]:
        search_title = cleantitle.normalize(search_title)
        words = cleantitle.normalize(tvshow["title"].split("/")[1].strip().lower())
        secondary_tvshow = tvshow.copy()
        secondary_tvshow.update(
            {
                "ratio": utils.calculate_similarity_ratio(search_title, words),
                "levenshtein": utils.calculate_levenshtein_distance(search_title, words),
            }
        )
        return secondary_tvshow

    def _extract_episode_url(
        self, tvshow: Dict[str, str], ep_no: str, check_startswith: bool = False, search_title: str = ""
    ) -> Optional[str]:
        try:
            if check_startswith:
                normalized_search_title = cleantitle.normalize(utils.decode_title_from_latin1(search_title)).lower()
                normalized_tvshow_title = cleantitle.normalize(tvshow["title"]).lower()
                if not normalized_tvshow_title.startswith(normalized_search_title):
                    return None

            if "/serial-online/" in tvshow["href"]:
                content2, _ = self.get_response(tvshow["href"])
                pattern = re.compile(r"<span>Sezon (\d+)</span>.*?<ul>(.*?)</ul>", re.DOTALL)
                episode_pattern = re.compile(r'<a href="(.*?)">\[s(\d+)e(\d+)\] (.*?)</a>')

                seasons = pattern.findall(content2)
                episodes_dict = {}
                for season, episodes_html in seasons:
                    for match in episode_pattern.findall(episodes_html):
                        url, season_number, episode_number, title = match
                        season_number = int(season_number)
                        episode_number = int(episode_number)
                        epno = f"s{season_number:02d}e{episode_number:02d}"
                        episodes_dict[epno] = {"url": url}

                if ep_no in episodes_dict.keys():
                    return episodes_dict[ep_no]["url"]
        except Exception as e:
            fflog_exc(e, title="Error processing episode URL extraction")
        return None

    def sources(self, url, host_dict, hostpr_dict):
        """Get movie sources."""
        try:
            sources = []
            headers = {"referer": "https://filman.cc/", "user-agent": "Mozilla"}

            # Funkcja do tworzenia linku Kodi
            def create_kodi_link(url, headers):
                # Kodowanie wartości nagłówków
                encoded_headers = {key: quote(value, safe="") for key, value in headers.items()}

                # Łączenie zakodowanych nagłówków w format Kodi
                options = "&".join([f"{key}={value}" for key, value in encoded_headers.items()])
                kodi_link = f"{url}|{options}"
                return kodi_link

            if not url:
                return sources

            results = self.get_videos(url)
            for result in results:
                valid, host = source_utils.is_host_valid(result["url"], host_dict)
                if valid or "wolfstream" in host:
                    sources.append(
                        {
                            "source": f"Premium: {host}" if "wolfstream" in host else host,
                            "quality": result["quality"],
                            "language": result["lang"],
                            "url": create_kodi_link(result["url"], headers) if "wolfstream" in host else result["url"],
                            "info": result["sound"],
                            "direct": False,
                            "debridonly": False,
                        }
                    )
            return sources
        except Exception as e:
            fflog_exc(e, title="Sources error")
            return sources

    def resolve(self, url):
        """Resolve URL."""
        return url

    def get_response(self, url, headers=HEADERS, data=None, method="get"):
        """Make HTTP request."""
        try:
            response = (
                self.session.post(url, headers=headers, data=data, verify=False)
                if method == "post"
                else self.session.get(url, headers=headers, verify=False)
            )
            cookies_str = "; ".join([f"{c.name}={c.value}" for c in self.session.cookies])
            return response.text, cookies_str
        except Exception as e:
            fflog_exc(e, title="Error in get_response")

    def get_videos(self, url: str) -> List[Dict[str, str]]:
        """Get list of videos from the URL."""
        content = self.get_url_req(url, url)
        out = []

        try:
            table_content = parseDOM(content, "table", attrs={"id": "links"})
            if not table_content:
                return out

            result = parseDOM(table_content[0], "tbody")
            if not result:
                return out

            rows = self._get_rows(result[0])
            for row in rows:
                try:
                    video_info = self._extract_video_info(row)
                    if video_info:
                        out.append(video_info)
                except Exception as e:
                    fflog_exc(e, title="Error processing link")
        except Exception as e:
            fflog_exc(e, title="Error parsing content")

        return out

    def _get_rows(self, content: str) -> List[str]:
        row_pattern = re.compile(r'<tr class="[^"]*version[^"]*">(.+?)</tr>', re.DOTALL)
        return row_pattern.findall(content)

    def _extract_video_info(self, row: str) -> Dict[str, str]:
        iframe_pattern = re.compile(r'data-iframe="([^"]+)"')
        href_pattern = re.compile(r'<a href="([^"]+)" target="_blank" data-mp4="true">')
        td_pattern = re.compile(r"<td[^>]*>(.*?)</td>")

        iframe_match = iframe_pattern.findall(row)
        href_match = href_pattern.findall(row)
        td_values = td_pattern.findall(row)

        if iframe_match:
            hrefok = self._decode_base64_url(iframe_match[0])
            sound, quality = self._extract_td_values(td_values, 1, 2)
        elif href_match:
            hrefok = self._decode_base64_url(href_match[0])
            sound, quality = self._extract_td_values(td_values, -3, -2)
        else:
            hrefok = None

        if hrefok:
            sound, lang = self._process_sound(sound)
            return {"url": hrefok, "quality": quality, "sound": sound, "lang": lang}

        return {}

    def _decode_base64_url(self, encoded_url: str) -> str:
        decoded_iframe = base64.b64decode(encoded_url).decode("utf-8").replace("\\/", "/")
        if "wolfstream" in decoded_iframe:
            return decoded_iframe
        else:
            return re.findall(r"src['\"]:['\"](.+?)['\"]", decoded_iframe)[0]

    def _extract_td_values(self, td_values: List[str], sound_idx: int, quality_idx: int) -> (str, str):
        sound = td_values[sound_idx].strip()
        quality = source_utils.check_sd_url(td_values[quality_idx].strip())
        return sound, quality

    def _process_sound(self, sound: str) -> (str, str):
        sound = sound.replace("Napisy_Tansl", "napisy").replace("ENG", "en")
        lang = "en" if "en" in sound else "pl"
        sound = " " if lang == "en" else sound
        return sound, lang

    def get_url_req(self, url, ref, allow=True):
        """Make HTTP request with cookies."""
        try:
            cookies_str = cache.cache_get("filman_cookie", control.sourcescacheFile)
            if cookies_str:
                cookies_str = cookies_str.get("value")
                cookies = dict(cookie.split("=") for cookie in cookies_str.split("; "))
                self.session.cookies.update(cookies)

            headers = {
                "Host": "filman.cc",
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "pl,en-US;q=0.7,en;q=0.3",
                "Referer": ref,
                "Upgrade-Insecure-Requests": "1",
            }

            self.session.headers.update(headers)
            response = self.session.get(url, verify=False, allow_redirects=allow)

            if "Security Check" in response.text:
                response = self.session.get(url, headers=headers)
                cookies = "; ".join([f"{x}={y}" for x, y in self.session.cookies.get_dict().items()])
                cache.cache_insert("filman_cookie", cookies, control.sourcescacheFile)

            return response.text if allow else response.content
        except Exception as e:
            fflog_exc(e, title="Error in get_url_req")
