"""
Some global object definitions.

Those classes are independent of rest of code.
Can be safety used in const.py.
"""

import re
from sys import maxsize
from datetime import datetime
from enum import Enum
from typing import Optional, Union, Any, Tuple, Dict, Mapping, Iterable, Iterator, Generic, TypeVar, NamedTuple, TYPE_CHECKING
from typing import overload, Sequence
# from collections.abc import Sequence
from typing_extensions import Self, Literal, TypeAlias
from typing_extensions import TypedDict, NotRequired
from attrs import frozen, field
from .ff.types import JsonData
from .ff.calendar import make_datetime
# from .ff.calendar import utc_timestamp
# from .ff.tricks import namedtuple_base
if TYPE_CHECKING:
    from .ff.item import FFItem


T = TypeVar('T')

#: Main reference type.
RefType: TypeAlias = Literal['', 'movie', 'show', 'season', 'episode', 'person', 'collection',
                             'company', 'keyword', 'network',
                             # extra types (has no tmdb details)
                             'genre', 'language', 'country', 'list']
#: General media (item) content type.
MainMediaType: TypeAlias = Literal['movie', 'show']
MainMediaTypeList: TypeAlias = Literal['movie', 'show', 'movie,show']
#: General media (item) content type.
MediaType: TypeAlias = Literal['movie', 'show', 'season', 'episode']
#: Dict with media data
MediaDict: TypeAlias = Dict[str, Any]
#: Video objects to play.
MediaPlayType: TypeAlias = Literal['movie', 'episode']
#: Seatch type.
SearchType: TypeAlias = Literal['all', 'multi', 'movie', 'show', 'person', 'collection', 'company', 'keyword']


#: Factor for denormalized season dbid.
SHOW_SEASON_COMBINE_FACTOR: int = 100


#: Dict with IDs (like in trakt.tv).
class IdsDict(TypedDict):
    tmdb: NotRequired[Optional[int]]
    imdb: NotRequired[Optional[str]]
    trakt: NotRequired[Optional[int]]
    tvdb: NotRequired[Optional[int]]
    slug: NotRequired[Optional[str]]


class DeprecatedError(BaseException):
    """Deprecated, method shoudn't be uesed."""


class VideoIds(NamedTuple):
    """
    Simple TMDB or IMDB or TRAKT IDs.

    This object can generate `vid` (video id). Typicaly it's just tmdb id.

    `vid` is used as DBID in Kodi API.
    """

    # The TMDB ID.
    tmdb: Optional[int] = None
    # The IMDB ID.
    imdb: Optional[str] = None
    # The Trakt ID.
    trakt: Optional[int] = None
    # The TVDB ID.
    tvdb: Optional[int] = None
    # Volatile (fake) ID, only for one FF session.
    volatile: Optional[int] = None
    # Kodi internal DBID.
    kodi: Optional[int] = None

    # --- NOTE: following class vars can NOT use hint type. ---
    #: Kodi DB internal IDs.
    KODI = range(0, 99_000_000)
    #: Tmdb id range.
    TMDB = range(100_000_000, 999_000_000)
    #: Fake, temporary, dynamic ID, used for seasons only.
    VOLATILE = range(999_000_000, 1_000_000_000)
    #: Imdb id range.
    IMDB = range(1_000_000_000, 2_000_000_000)
    #: Trakt id range.
    TRAKT = range(2_000_000_000, 2_147_482_000)  # fit in 31 bit
    #: TvDB id range.
    TVDB = range(3_000_000_000, 4_000_000_000)  # not used

    def is_kodi(self) -> bool:
        """Return True if internal Kodi ID."""
        return self.kodi is not None

    def is_tmdb(self) -> bool:
        """Return True if TMDB."""
        return self.tmdb is not None

    def is_imdb(self) -> bool:
        """Return True if IMDB."""
        return self.imdb is not None

    def is_trakt(self) -> bool:
        """Return True if Trakt."""
        return self.trakt is not None

    def is_tvdb(self) -> bool:
        """Return True if Trakt."""
        return self.tvdb is not None

    def is_volatile(self) -> bool:
        """Return True if FF volatile ID."""
        return self.volatile is not None

    def db_id(self) -> int:
        """Generate video ID form VideoIds imdb / tmdb ID."""
        return self.make_dbid(imdb=self.imdb, tmdb=self.tmdb, trakt=self.trakt, tvdb=self.tvdb, volatile=self.volatile, kodi=self.kodi)

    @property
    def dbid(self) -> int:
        """Generate video ID form VideoIds imdb / tmdb ID."""
        return self.make_dbid(imdb=self.imdb, tmdb=self.tmdb, trakt=self.trakt, tvdb=self.tvdb, volatile=self.volatile, kodi=self.kodi)

    def ids(self) -> IdsDict:
        """Create dict with existing IDs."""
        ids: IdsDict = {}
        if self.imdb:
            ids['imdb'] = self.imdb
        if self.tmdb:
            ids['tmdb'] = self.tmdb
        if self.trakt:
            ids['trakt'] = self.trakt
        if self.tvdb:
            ids['tvdb'] = self.tvdb
        return ids

    def kodi_ids(self) -> Mapping[str, str]:
        """Create dict with existing IDs in kodi setUniqueIDs() format."""
        ids = {}
        if self.imdb:
            ids['imdb'] = str(self.imdb)
        if self.tmdb:
            ids['tmdb'] = str(self.tmdb)
        if self.trakt:
            ids['trakt'] = str(self.trakt)
        if self.tvdb:
            ids['tvdb'] = str(self.tvdb)
        if self.volatile:
            ids['ff/volatile'] = str(self.tvdb)
        if self.kodi:
            ids['dbid'] = str(self.kodi)
        return ids

    def service(self) -> Optional[str]:
        """Return main service name (service with existing ID)."""
        if self.tmdb:
            return 'tmdb'
        if self.imdb:
            return 'imdb'
        if self.trakt:
            return 'trakt'
        if self.tvdb:
            return 'tvdb'
        if self.volatile:
            return 'ff/volatile'
        if self.kodi:
            return 'dbid'
        return None

    def ref(self, type: RefType) -> 'MediaRef':
        """Return media reference."""
        return MediaRef(type, self.db_id())

    @property
    def value(self) -> Union[None, str, int]:
        """Return ID whathever it is."""
        if self.tmdb is not None:
            return self.tmdb
        if self.imdb is not None:
            return self.imdb
        if self.volatile is not None:
            return self.volatile + self.VOLATILE.start
        if self.kodi is not None:
            return self.kodi
        # Trakt is ignored, it does NOT differ to TMDB ID.
        return None

    def __str__(self) -> str:
        """ID as string (whathever ID is)."""
        return str(self.value or '')

    @classmethod
    def from_ids(cls, ids: JsonData) -> 'VideoIds':
        """Generate video IDs from ids dict."""
        return cls(tmdb=ids.get('tmdb'), imdb=ids.get('imdb'), trakt=ids.get('trakt'), tvdb=ids.get('tvdb'))

    @classmethod
    def from_tmdb(cls, item: JsonData) -> 'VideoIds':
        """Generate video IDs from TMDB item (`id` and `external_ids`)."""
        ids = item.get('external_ids') or {}
        return cls(tmdb=item['id'], imdb=ids.get('imdb_id'), tvdb=ids.get('tvdb_id'))

    @classmethod
    def dbid_from_tmdb(cls, item: JsonData) -> int:
        """Generate video IDs from TMDB item (`id` and `external_ids`)."""
        ids = item.get('external_ids') or {}
        return cls.make_dbid(tmdb=item['id'], imdb=ids.get('imdb_id'), tvdb=ids.get('tvdb_id'))

    @classmethod
    def make_dbid(cls, *,
                  tmdb: Optional[int] = None,
                  imdb: Optional[str] = None,
                  trakt: Optional[int] = None,
                  tvdb: Optional[int] = None,
                  volatile: Optional[int] = None,
                  kodi: Optional[int] = None,
                  ) -> int:
        """Generate video ID form imdb / tmdb ID."""
        if tmdb:
            return cls.TMDB.start + int(tmdb)
        elif imdb:
            factor = len(cls.IMDB)
            tt = int(f'9{imdb[2:]}')
            if tt >= 99 * factor // 10:
                from .ff.log_utils import error
                error(f'IMDB ID {imdb!r} is out of range')
                return 0
            return cls.IMDB.start + tt % factor
        elif trakt:
            return cls.TRAKT.start + int(trakt)
        elif tvdb:
            return cls.TVDB.start + int(tvdb)
        elif volatile:
            return cls.VOLATILE.start + int(volatile)
        elif kodi:
            return cls.KODI.start + int(kodi)
        return 0

    @classmethod
    def from_dbid(cls, dbid: int) -> Optional['VideoIds']:
        """Recover imdb / tmdb ID from video ID."""
        if dbid is None:
            return None
        if dbid in cls.TMDB:
            return cls(tmdb=cls.TMDB.index(dbid))
        if dbid in cls.IMDB:
            value_digit_length = len(str(len(cls.IMDB) - 1))  # Number of digits for value part.
            tt = str(cls.IMDB.index(dbid))
            if len(tt) == value_digit_length and tt[0] != '9':
                return cls(imdb=f'tt{tt}')
            if tt[0] == '9':
                return cls(imdb=f'tt{tt[1:]}')
            return cls(imdb=f'tt{tt:0>{value_digit_length}}')
        if dbid in cls.VOLATILE:
            return cls(volatile=cls.VOLATILE.index(dbid))
        if dbid in cls.TRAKT:
            return cls(trakt=cls.TRAKT.index(dbid))
        if dbid in cls.TVDB:
            return cls(tvdb=cls.TVDB.index(dbid))
        if dbid in cls.KODI:
            return cls(kodi=cls.KODI.index(dbid))
        return None


_rx_mediaref_format: re.Pattern = re.compile(r'(?P<align>[<>^])?(?P<width>\d+)?(?P<code>\w)?')


class MediaRef(NamedTuple):
    """
    Reference to media (video).

    Movies:
        - type="movie" and `dbid`.
    Tv-show:
        - type="show" and `dbid`.
    Season:
        - type="show", tvshow in `dbid` and `season`.
        - type="season" and season `dbid` (denormalized, should not be used).
    Episode:
        - type="show", tvshow in `dbid`, `season` and `episode`.
        - type="episode" and episode `dbid` (denormalized, should be avoided, used in kodi monitor).

    Examples:
        - ('movie', MOVIE_ID, None, None)
        - ('show', SHOW_ID, None, None)
        - ('show', SHOW_ID, SEASON_NUM, None)
        - ('show', SHOW_ID, SEASON_NUM, EPISODE_NUM)

    Denormalized examples, should be avoided:
        - ('season', SEASON_ID, None, None)
        - ('episode', EPISODE_ID, None, None)
    """

    #: Media type.
    type: RefType
    #: Media ID (dbid).
    dbid: int
    #: Season number if season or episode is pointed by tvshow in `dbid` with `type` == 'show'.
    season: Optional[int] = None
    #: Episode number if episode is pointed by tvshow in `dbid` with `type` == 'show'.
    episode: Optional[int] = None

    def as_dict(self) -> Dict[str, Any]:
        """Return media ref as dict."""
        return self._asdict()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MediaRef':
        """New ref from dict data."""
        return cls(**data)

    @property
    def is_normalized(self) -> bool:
        """Return True if ref is normalized, used movie or tvshow only."""
        return self.type not in ('season', 'episode')

    @property
    def real_type(self) -> RefType:
        """Return media type based on IDs and numbers."""
        if self.type == 'show':
            if self.episode is not None:
                return 'episode'
            if self.season is not None:
                return 'season'
        return self.type or ''

    @classmethod
    def from_tmdb(cls, type: RefType, tmdb: int, season: Optional[int] = None, episode: Optional[int] = None) -> 'MediaRef':
        """Create MediaRef from TMDB id."""
        return cls(type, tmdb + VideoIds.TMDB.start, season, episode)

    @property
    def main_type(self) -> str:
        """Return main type based on IDs: "movie" or "show" (for tv, season, episode)."""
        return self.type or ''

    @property
    def is_movie(self) -> bool:
        """Return True is ref is a movie."""
        return self.type == 'movie'

    @property
    def is_show(self) -> bool:
        """Return True is ref is a show."""
        return self.type == 'show' and self.season is None and self.episode is None

    @property
    def is_season(self) -> bool:
        """Return True is ref is a season (only normalized)."""
        return self.type == 'show' and self.season is not None and self.episode is None

    @property
    def is_episode(self) -> bool:
        """Return True is ref is an episode (only normalized)."""
        return self.type == 'show' and self.season is not None and self.episode is not None

    @property
    def is_volatile(self) -> bool:
        """Return True is ref's DBIDs is volatile."""
        return bool(self.dbid) and self.dbid in VideoIds.VOLATILE

    @property
    def is_container(self) -> bool:
        """Return True is ref is container type (could have children) like show and season."""
        return (self.type == 'show' and self.episode is None) or self.type == 'collection'

    def denormalize(self) -> Optional['MediaRef']:
        """Denormalize, it's possible only for seasons and only for TMDB."""
        return None  # Kodi has not enough bits for DBID to handle denormalized season DBID.

    def normalize(self) -> Optional['MediaRef']:
        """Normalize, it's possible only for seasons and only for TMDB."""
        if self.is_normalized:
            return self
        if self.type == 'season' and self.season is None and self.episode is None and self.dbid and self.dbid < 0:
            show, season = divmod(self.dbid, SHOW_SEASON_COMBINE_FACTOR)
            return MediaRef('show', show, season)
        return None

    def try_normalize(self) -> 'MediaRef':
        """Try to normalize, it's possible only for seasons and only for TMDB."""
        return self.normalize() or self

    @property
    def tv_tuple(self) -> Tuple[int, ...]:
        """Return variable-length tuple for tvshow, season or episode: [show[,season[,episode]]]."""
        if self.type == 'show':
            if self.season is not None:
                if self.episode is not None:
                    return (self.dbid, self.season, self.episode)
                return (self.dbid, self.season)
            return (self.dbid,)
        return ()

    @property
    def tmdb_tv_tuple(self) -> Tuple[int, ...]:
        """Return variable-length tuple for tvshow, season or episode: [show[,season[,episode]]] with TMDB id."""
        if self.type == 'show':
            if self.season is not None:
                if self.episode is not None:
                    return (self.tmdb_id, self.season, self.episode)
                return (self.tmdb_id, self.season)
            return (self.tmdb_id,)
        return ()

    @property
    def tv_dbid(self) -> Optional[int]:
        """Return tv-show dbid for shows, season, episode."""
        if self.type == 'show':
            return self.dbid
        return None

    @property
    def tmdb_tv_dbid(self) -> Optional[int]:
        """Return tv-show dbid for shows, season, episode with TMDB id."""
        if self.type == 'show':
            return self.tmdb_id
        return None

    @property
    def video_ids(self) -> VideoIds:
        """Return VideoIds()."""
        vid = VideoIds.from_dbid(self.dbid)
        if vid is None:
            return VideoIds()
        return vid

    @property
    def ref(self) -> 'MediaRef':
        """Return ref (just itself). Same property as FFItem.ref."""
        return self

    @property
    def tmdb_id(self) -> int:
        """Return TMDB id, 0 if dbid is not TMDB."""
        return VideoIds.TMDB.index(self.dbid) if self.dbid in VideoIds.TMDB else 0

    @property
    def role(self) -> str:
        """Return empty role. Same property as FFItem.role."""
        return ''

    @property
    def sql_ref(self) -> 'XMediaRef':
        """Return media ref for SQL, without None (dbid = 0, season and episode = -1)."""
        return XMediaRef(self.type or '', self.dbid or 0, self.sql_season, self.sql_episode)

    @property
    def xref(self) -> 'XMediaRef':
        """Return media ref for SQL, without None (dbid = 0, season and episode = -1)."""
        return XMediaRef(self.type or '', self.dbid or 0, self.sql_season, self.sql_episode)

    @property
    def sql_dbid(self) -> int:
        """Return media DBID for SQL. 0 if missing (for season and episode)."""
        if self.season is None and self.episode is None:
            return self.dbid or 0
        return 0

    @property
    def sql_main_dbid(self) -> int:
        """Return parent DBID (movie itself or tvshow for rest) for SQL."""
        if self.type in ('movie', 'show'):
            return self.dbid or 0
        return 0

    @property
    def sql_tv_dbid(self) -> int:
        """Return tvshow DBID for SQL (show, season and episode). 0 if missing (for movie)."""
        if self.type == 'show':
            return self.dbid or 0
        return 0

    @property
    def sql_season(self) -> int:
        """Return season number for SQL, -1 if None."""
        return -1 if self.season is None else self.season

    @property
    def sql_episode(self) -> int:
        """Return episode number for SQL, -1 if None."""
        return -1 if self.episode is None else self.episode

    @classmethod
    def from_sql_ref(cls, ref: 'MediaRef') -> Self:
        """Return media ref for SQL, without None (dbid = 0, season and episode = -1)."""
        season = None if ref.season == -1 else ref.season
        episode = None if ref.episode == -1 else ref.episode
        return cls(ref.type, ref.dbid, season, episode)

    @classmethod
    def movie(cls, dbid: int) -> 'MediaRef':
        """Create movie ref."""
        return cls('movie', dbid)

    @classmethod
    def tvshow(cls, dbid: int, season: Optional[int] = None, episode: Optional[int] = None) -> 'MediaRef':
        """Create tvshow ref."""
        return cls('show', dbid, season, episode)

    @classmethod
    def person(cls, dbid: int) -> 'MediaRef':
        """Create person ref."""
        return cls('person', dbid)

    def ref_list(self) -> Tuple['MediaRef', ...]:
        """Create media ref list. Ex. tvshow ref for season or episode."""
        if self.season is not None:
            if self.episode is not None:
                return (self, MediaRef('show', self.dbid, self.season), MediaRef('show', self.dbid))
            return (self, MediaRef('show', self.dbid))
        return (self,)

    @property
    def main_ref(self) -> 'MediaRef':
        """Return main ref (show ref for show, season and episode)."""
        return MediaRef(self.type, self.dbid)

    @property
    def show_ref(self) -> Optional['MediaRef']:
        """Return show ref for show, season and episode."""
        if self.type == 'show':
            return MediaRef(self.type, self.dbid)
        return None

    @property
    def season_ref(self) -> Optional['MediaRef']:
        """Return seasons ref for season and episode."""
        if self.type == 'show' and self.season is not None:
            return MediaRef(self.type, self.dbid, self.season)
        return None

    def parents(self) -> Iterator['MediaRef']:
        """Return all parent refs, ex. show and season ref for episode."""
        if self.type == 'show':
            if self.episode is not None:
                yield MediaRef(self.type, self.dbid, self.season)
            if self.season is not None:
                yield MediaRef(self.type, self.dbid)

    def with_forced_type(self, type: RefType) -> 'MediaRef':
        """Return copy with new type replaced."""
        return MediaRef(type, self.dbid, self.season, self.episode)

    def with_season(self, season: int) -> 'MediaRef':
        """Return copy with season replaced."""
        return MediaRef(self.type, self.dbid, season=season, episode=None)

    def with_episode(self, episode: int) -> 'MediaRef':
        """Return copy with episode replaced."""
        return MediaRef(self.type, self.dbid, season=self.season, episode=episode)

    def __format__(self, fmt: str) -> str:
        """Return ref IDs as URL path."""
        mch = _rx_mediaref_format.fullmatch(fmt)
        assert mch
        align = mch['align'] or '<'
        width = int(mch['width'] or -1)
        code = mch['code'] or ''
        if code == 'a':
            out = '/'.join(map(str, (self.type, *(self.tv_tuple or (self.dbid,)))))
        else:
            if (tt := self.tv_tuple):
                out = '/'.join(map(str, tt))
            else:
                out = str(self.dbid)
        if width > len(out):
            out = f'{out:{align}{width}}'
        return out


# @dataclass
# class MediaPlayInfo:
#     """Short media (movie, tv-show, season, episode) play info."""

#     ref: MediaRef
#     tmdb: Optional[int] = None
#     imdb: Optional[str] = None
#     trakt: Optional[int] = None
#     tvdb: Optional[int] = None
#     slug: Optional[str] = None
#     tv_slug: Optional[str] = None
#     playback_id: Optional[int] = None
#     progress: Optional[float] = None
#     paused_at: Optional[int] = None
#     play_count: Optional[int] = None
#     last_watched_at: Optional[int] = None
#     duration: Optional[int] = None
#     aired_at: Optional[int] = None
#     meta_updated_at: Optional[int] = None

#     def __post_init__(self):
#         if self.ref.type not in get_typing_args(MediaType):
#             allowed = ', '.join(get_typing_args(MediaType))
#             raise ValueError(f'MediaPlayInfo: incorrect type {type!r}, should be one of: {allowed}')
#         for key in ('paused_at', 'last_watched_at', 'meta_updated_at'):
#             val = getattr(self, key)
#             if isinstance(val, str):
#                 val = int(utc_timestamp(val)) if val else None
#                 setattr(self, key, val)

#     def __iter__(self):
#         for field in fields(self):
#             yield getattr(self, field.name)

#     @property
#     def has_progress(self) -> bool:
#         return self.progress is not None and 0 < self.progress < 100

#     @property
#     def has_play_count(self) -> bool:
#         return self.play_count is not None

#     def ids(self) -> IdsDict:
#         """Return item IDs dict."""
#         return {'tmdb': self.tmdb, 'imdb': self.imdb, 'trakt': self.trakt, 'tvdb': self.tvdb}

#     def as_dict(self) -> Dict[str, Any]:
#         """Return a new dict which maps field names to their corresponding values."""
#         return asdict(self)

#     def as_media_dict(self) -> MediaDict:
#         """Return values as media dict (old format)."""
#         return asdict(self)  # TODO: filter out some values


class XMediaRef(MediaRef):
    """Helper. Media reference for SQL (without None), ORM hacking."""
    __slots__ = ()
    _field_defaults = {'season': -1, 'episode': -1}
    __annotations__ = {**MediaRef.__annotations__, **{'season': int, 'episode': int}}


class ItemList(list, Generic[T]):
    """TMDB item list with pagination info. Initialize with page-only items."""

    def __init__(self, *args, page: int, total_pages: int, total_results: int = 0) -> None:
        super().__init__(*args)
        #: Current page number.
        self.page: int = page
        #: Total number of pages.
        self.total_pages: int = total_pages
        #: Total number of items.
        self.total_results: int = total_results

    def next_page(self) -> Optional[int]:
        """Return next page number or None."""
        if self.page and self.total_pages and self.page < self.total_pages:
            return self.page + 1
        return None

    def set_item_count(self, count, page_size: int = 25):
        """Set number of items and pages."""
        self.total_results = count
        self.total_pages = (count + page_size - 1) // page_size

    @classmethod
    def empty(cls) -> 'ItemList':
        """Return new empty item list."""
        return cls(page=0, total_pages=0, total_results=0)

    @classmethod
    def single(cls, items: Iterable[T]) -> 'ItemList':
        """Return new single page item list."""
        lst = cls(items, page=1, total_pages=1, total_results=0)
        lst.total_results = len(lst)
        return lst

    def with_content(self, items: Iterable[T]) -> 'ItemList':
        """Create new list with content changed (with the same pages)."""
        lst = self.__class__(items, page=self.page, total_pages=self.total_pages)
        lst.total_results = len(lst)
        return lst


class Pagina(Sequence, Generic[T]):
    """Pagination object to split item list into pages. Initialize with full item list. Pages count from one."""

    def __init__(self, items: Iterable[T], *, page: int = 1, limit: int = 20):
        if not isinstance(items, Sequence):
            items = tuple(items)
        #: Full item  list.
        self.items: Sequence[T] = items
        #: Current page number.
        self.page: int = page
        #: Page size.
        self._limit: int = limit

    @property
    def limit(self) -> int:
        """Size of page."""
        return self._limit

    @property
    def total_pages(self) -> int:
        """Total number of pages."""
        return (len(self.items) + self._limit - 1) // self._limit

    @property
    def total_results(self) -> int:
        """Total number of items."""
        return len(self.items)

    def next_page(self) -> Optional[int]:
        """Return next page number or None."""
        total_pages = self.total_pages
        if self.page and total_pages and self.page < total_pages:
            return self.page + 1
        return None

    def start(self) -> int:
        """Return begin of the view (view first index in items space)."""
        if self.page < 1:
            return 0
        # Pages count from one.
        return min((self.page - 1) * self._limit, len(self.items))

    def end(self) -> int:
        """Return end of the view (view last index + 1 in items space)."""
        if self.page < 1:
            return 0
        # Pages count from one.
        return min((self.page + 0) * self._limit, len(self.items))

    def next(self) -> 'Pagina[T]':
        """Get next page."""
        return Pagina(self.items, page=self.page+1, limit=self._limit)

    def __repr__(self) -> str:
        items = ', '.join(map(repr, iter(self)))
        return f'Pagina(page={self.page}, [{items}])'

    @classmethod
    def empty(cls) -> 'Pagina[T]':
        return cls([], page=0)

    # --- Sequence protocol ---

    @overload
    def __getitem__(self, index: int) -> T:  ...

    @overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...

    def __getitem__(self, index: Union[int, slice]) -> Union[T, Sequence[T]]:
        start, end = self.start(), self.end()
        if isinstance(index, int):
            if index < 0:
                index += end
            else:
                index += start
            if start <= index < end:
                return self.items[index]
            raise IndexError('Pagina index out of range')
        return self.items[start:end][index]

    def __len__(self) -> int:
        return self.end() - self.start()

    def __contains__(self, item: object, /) -> bool:
        for i in range(self.start(), self.end()):
            if self.items[i] == item:
                return True
        return False

    def __iter__(self) -> Iterator[T]:
        return iter(self.items[self.start():self.end()])

    def __reversed__(self) -> Iterator[T]:
        return reversed(self.items[self.start():self.end()])

    def index(self, value: T, start: int = 0, stop: int = maxsize) -> int:
        # TODO user start and stop
        start = self.start()
        end = self.end()
        for i in range(start, end):
            if self.items[i] == value:
                return i - start
        raise ValueError(f'{value!r} is not in page')

    def count(self, value: T) -> int:
        return self.items[self.start():self.end()].count(value)


class NextWatchPolicy(Enum):
    """How to calculate last and next episode in show progress."""
    # Episode are calculated using the last aired episode the user has watched.
    LAST = 'last'
    # Episode are calculated using last watched episode (last activity).
    CONTINUED = 'continued'
    # Episode are calculated using first unwatched episode.
    FIRST = 'first'
    # Episode are calculated using the last aired episode at all.
    NEWEST = 'newest'


@frozen
class MediaProgressItem:
    """Video (movie or episode) progress."""
    #: Media reference.
    ref: MediaRef
    #: The video watching progress percent (0..100).
    progress: float = 0.0
    #: The number of played.
    play_count: int = 0
    #: The last watch time or minimum date (1y).
    last_watched_at: datetime = field(default=datetime.min, converter=make_datetime)

    def __bool__(self) -> bool:
        """If item is watched or waching."""
        return self.play_count > 0 or self.progress > 0

    @property
    def total_progress(self) -> float:
        return 100.0 if self.play_count else self.progress

    @property
    def has_last_watched_at(self) -> bool:
        return self.last_watched_at and self.last_watched_at.year > 1


@frozen
class MediaProgressCount:
    """Number of watched, total etc. sub-items (e.g. episodes)."""
    unwatched: int = 0
    in_progress: int = 0
    watched: int = 0
    total: int = 0


@frozen
class MediaProgress:
    """Media progress (all types)."""

    #: Media reference.
    ref: MediaRef
    #: The video watching progress percent (0..100).
    progress: float = 0.0
    #: The number of played.
    play_count: int = 0
    #: The ast watch time or minimum date (1y).
    last_watched_at: datetime = field(default=datetime.min, converter=make_datetime)

    #: Flat bar of sub-items.
    bar: Sequence[MediaProgressItem] = ()
    #: The next episode the user should watch.
    next_episode: Optional['FFItem'] = None
    #: The last episode the user watched.
    last_episode: Optional['FFItem'] = None

    def __bool__(self) -> bool:
        """If item is watched or waching."""
        return self.play_count > 0 or self.progress > 0

    @property
    def total_progress(self) -> float:
        return 100.0 if self.play_count else self.progress

    @property
    def has_last_watched_at(self) -> bool:
        return self.last_watched_at and self.last_watched_at.year > 1

    def items_count(self) -> MediaProgressCount:
        """Get  umber of watched, total etc. counters."""
        watched = in_progress = 0
        for it in self.bar:
            if it.play_count:
                watched += 1
            if 0 < it.progress < 100:
                in_progress += 1
        total = len(self.bar)
        return MediaProgressCount(unwatched=total - watched, in_progress=in_progress, watched=watched, total=total)
