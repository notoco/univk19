
import sys
from urllib.parse import unquote_plus
# MUST be before any kodi or FF import
from lib import autoinstall  # noqa: F401, pylint: disable=W0611  # type: ignore

print(f'\033[93;1m[FF.script]\033[0m   {sys.argv=}', file=sys.stderr)
print(f'  {sys.modules=}', file=sys.stderr)  # test czy moduyły FF są załadowane – nie są

try:
    if len(sys.argv) >= 2 and sys.argv[1] == 'play':
        from xbmc import Player
        from xbmcgui import ListItem
        player = Player()
        item = ListItem('Dupka')
        item.setInfo('video', {'title': 'Dupeczka'})
        # url = 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'
        url = unquote_plus(sys.argv[2])
        player.play(url, item)
finally:
    print('\033[93m[FF.script]\033[0m  exit ---', file=sys.stderr)
