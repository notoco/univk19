"""Hyperion control addon resources."""
