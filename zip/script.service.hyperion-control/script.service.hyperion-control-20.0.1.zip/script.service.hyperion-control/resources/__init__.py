"""Hyperion control addon resources."""
