# Odysee (Unofficial)

This is unofficial add-on for Odysee.

## How to Install this add-on?

You need `kodipl` module to be able to use this add-on. The source code of the module is located here: [kodi-pl/kodipl](https://github.com/kodi-pl/kodipl)

After installing module, you will be able to install this plugin from zip file.

## Disclaimer

This is an unofficial add-on that only allows you to view content. For full content, please visit the official site.

## License

This add-on is under GPL-2.0 license.