# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcgui
import xbmc
import json
import http.client
import threading


headers = {
    'Content-Type': 'application/json',
}
HYPERION_HOST = '127.0.0.1'
HYPERION_PORT = 8090
HYPERION_TIMEOUT = 2
# Hyperion.NG of CoreELEC canary (Kodi feeds the picture) is its own add-on
HYPERION_ADDONS = ('service.hyperion.canary', 'service.hyperion.ng')
HYPERION_DB = '/storage/.kodi/userdata/addon_data/%s/db/hyperion.db'
# Hyperion grabs an HDR picture before the HDR -> SDR conversion of the box (pale and dark), its own adjustment then
HDR_ADJUSTMENT = {'gammaRed': 3.5, 'gammaGreen': 3.5, 'gammaBlue': 3.5, 'saturationGain': 1.6, 'brightnessGain': 2.0}
# the saved calibration, if it can not be read from the database of Hyperion
SDR_ADJUSTMENT = {'gammaRed': 1.9, 'gammaGreen': 1.9, 'gammaBlue': 1.9, 'saturationGain': 1.15, 'brightnessGain': 1.0}

icon = xbmcaddon.Addon().getAddonInfo('icon')

_hyperion_conn = None
_hyperion_lock = threading.Lock()  # one connection, the fade in runs in its own thread

def _hyperion_request(data, notify=True):
    with _hyperion_lock:
        return _hyperion_send(data, notify)

def _hyperion_send(data, notify):
    global _hyperion_conn
    body = json.dumps(data)
    response_body = None
    for attempt in (1, 2):
        try:
            if _hyperion_conn is None:
                _hyperion_conn = http.client.HTTPConnection(HYPERION_HOST, HYPERION_PORT, timeout=HYPERION_TIMEOUT)
            _hyperion_conn.request('POST', '/json-rpc', body=body, headers=headers)
            response_body = _hyperion_conn.getresponse().read()
            break
        except (OSError, http.client.HTTPException):
            try:
                _hyperion_conn.close()
            except Exception:
                pass
            _hyperion_conn = None
    if response_body is None:
        if notify:
            send_notification("Hyperion", "Brak połączenia z Hyperion")
        return None
    result = json.loads(response_body)
    if not result.get('success', True):
        send_notification("Hyperion", "Błąd Hyperion: " + str(result.get('error', '')))
        return None
    return result

def _get_bright():
    try:
        bright = int(get_setting('bright'))
    except ValueError:
        bright = 50
    return max(0, min(100, bright))

# a video started from the menu: the LEDs brighten from black up to the brightness of the settings
FADE_IN_SECONDS = 4.0
FADE_IN_STEPS = 40

def _set_brightness(brightness):
    _hyperion_request({"command": "adjustment", "adjustment": {"brightness": brightness}, "tan": 1}, notify=False)

def ambilight_fade_start():
    if get_setting('state') == 'true':
        _set_brightness(0)

FADE_IN_WAIT_SECONDS = 10.0

def _wait_for_picture(monitor, player):
    # AV started comes about a second before the picture: wait for the time of the video to move
    try:
        start = player.getTime()
        for _ in range(int(FADE_IN_WAIT_SECONDS / 0.1)):
            if monitor.waitForAbort(0.1):
                return False
            if player.getTime() - start >= 0.2:
                return True
    except RuntimeError:  # not playing any more
        return False
    return True

def ambilight_fade_in(monitor, player):
    if get_setting('state') != 'true' or not _wait_for_picture(monitor, player):
        _set_brightness(_get_bright())
        return
    bright = _get_bright()
    for step in range(1, FADE_IN_STEPS + 1):
        _set_brightness(round(bright * (step / FADE_IN_STEPS) ** 3))  # slow at first: the eye sees the low ones most
        if step < FADE_IN_STEPS and monitor.waitForAbort(FADE_IN_SECONDS / FADE_IN_STEPS):
            return

def ambilight_turn_off():
    data = {"command":"componentstate", "componentstate":{"component": "LEDDEVICE", "state": False }, "tan":1}
    if _hyperion_request(data) is not None:
        set_setting('state', 'false')

def ambilight_turn_on():
    data = {"command":"componentstate", "componentstate":{"component": "LEDDEVICE", "state": True }, "tan":1}
    if _hyperion_request(data) is not None:
        set_setting('state', 'true')

def ambilight_switch():
    if get_setting('state') == 'true':
        ambilight_turn_off()
        send_notification("Ambilight", "Wyłączono podświetlenie")
    else:
        ambilight_turn_on()
        send_notification("Ambilight", "Włączono podświetlenie")

def hyperion_ready():
    return _hyperion_request({"command":"sysinfo", "tan":1}, notify=False) is not None

def ambilight_restore():
    # Hyperion starts with the values of its database: the state and the brightness of the settings again
    if get_setting('state') == 'true':
        ambilight_turn_on()
    else:
        ambilight_turn_off()
    data = {"command":"adjustment", "adjustment":{"brightness": _get_bright() }, "tan":1}
    _hyperion_request(data)
    ambilight_idle_black()

# CoreELEC canary feeds only the playback: without any input Hyperion lets the LEDs show the last scene / white
# for a moment at the next start - a permanent black below every input instead
IDLE_PRIORITY = 250

# a paused video: black above the picture of Kodi (smoothing of Hyperion makes it a short fade)
PAUSE_PRIORITY = 50

def ambilight_pause(paused):
    if paused:
        data = {"command": "color", "color": [0, 0, 0], "priority": PAUSE_PRIORITY, "origin": "notoco helper pause", "tan": 1}
    else:
        data = {"command": "clear", "priority": PAUSE_PRIORITY, "tan": 1}
    _hyperion_request(data, notify=False)

def ambilight_idle_black():
    data = {"command": "color", "color": [0, 0, 0], "priority": IDLE_PRIORITY, "origin": "notoco helper idle", "tan": 1}
    _hyperion_request(data, notify=False)

def ambilight_bright_up():
    bright = min(_get_bright() + 10, 100)
    data = {"command":"adjustment", "adjustment":{"brightness": bright }, "tan":1}
    if _hyperion_request(data) is not None:
        set_setting('bright', str(bright))
        send_notification("Ambilight", "Jasność: "+str(bright))

def ambilight_bright_down():
    bright = max(_get_bright() - 10, 0)
    data = {"command":"adjustment", "adjustment":{"brightness": bright }, "tan":1}
    if _hyperion_request(data) is not None:
        set_setting('bright', str(bright))
        send_notification("Ambilight", "Jasność: "+str(bright))

def ambilight_set_brightness(percentage):
    try:
        bright = int(percentage)
    except (ValueError, TypeError):
        send_notification("Ambilight", "Nieprawidłowy format wartości jasności.")
        return
    if not (0 <= bright <= 100):
        send_notification("Ambilight", "Nieprawidłowa wartość jasności. Zakres 0-100.")
        return

    data = {"command":"adjustment", "adjustment":{"brightness": bright }, "tan":1}
    if _hyperion_request(data) is not None:
        set_setting('bright', str(bright))
        send_notification("Ambilight", "Jasność ustawiona na: "+str(bright)+"%")

def hyperion_addon():
    return next((addon for addon in HYPERION_ADDONS if xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % addon)),
                HYPERION_ADDONS[-1])

def _saved_adjustment():
    import sqlite3
    try:
        db = sqlite3.connect('file:%s?mode=ro' % (HYPERION_DB % hyperion_addon()), uri=True, timeout=2)
        try:
            row = db.execute("SELECT config FROM settings WHERE type = 'color' AND hyperion_inst = 0").fetchone()
        finally:
            db.close()
        adjustment = json.loads(row[0])['channelAdjustment'][0]
        return {key: adjustment[key] for key in HDR_ADJUSTMENT}
    except Exception as exc:
        xbmc.log('[script.notoco.helper] Hyperion adjustment not read: %s' % exc, xbmc.LOGWARNING)
        return SDR_ADJUSTMENT

def ambilight_hdr(hdr):
    # off when Hyperion already gets an SDR picture (e.g. CoreELEC canary: Kodi sends the picture itself)
    adjustment = HDR_ADJUSTMENT if hdr and get_setting('hdr_fix') != 'false' else _saved_adjustment()
    data = {"command":"adjustment", "adjustment": adjustment, "tan":1}
    return _hyperion_request(data) is not None

def _jsonrpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        request['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get('result') or {}


def play_from_start():
    """Live TV: the running programme from its start (Notoco TV plays it from the archive and
    seeks forward up to the broadcast). A programme from the archive: the previous programme of
    the channel (Kodi's own skip back). Anything else: the usual skip back."""
    item = _jsonrpc('Player.GetItem', {'playerid': 1}).get('item') or {}
    if item.get('type') == 'channel' and not xbmc.getCondVisibility('PVR.IsPlayingEpgTag'):
        details = _jsonrpc('PVR.GetChannelDetails', {'channelid': item['id'], 'properties': ['broadcastnow']})
        broadcast = (details.get('channeldetails') or {}).get('broadcastnow') or {}
        if broadcast.get('broadcastid'):
            _jsonrpc('Player.Open', {'item': {'broadcastid': broadcast['broadcastid']}})
            return
    xbmc.executebuiltin('PlayerControl(Previous)')


def skip_next():
    """Live TV: back to the broadcast after a pause or a rewind (Kodi's own skip forward stops a
    live stream that can seek). A programme from the archive: the next programme of the channel."""
    item = _jsonrpc('Player.GetItem', {'playerid': 1}).get('item') or {}
    if item.get('type') == 'channel' and not xbmc.getCondVisibility('PVR.IsPlayingEpgTag'):
        player = xbmc.Player()
        total = player.getTotalTime()
        if total - player.getTime() > 15:
            player.seekTime(total - 5)
        return
    xbmc.executebuiltin('PlayerControl(Next)')


def cpu():
    send_notification("", "[B]CPU:[/B] $INFO[System.CPUUsage] [CR][B]Temperatura:[/B] $INFO[System.CPUTemperature]   [B]RAM:[/B] $INFO[System.memory(used.percent)] [B]Up:[/B] $INFO[System.Uptime]")

def send_notification(komponent, message):
    xbmcgui.Dialog().notification(komponent, message, icon=icon)

# a new Addon each time: an Addon object keeps the settings of its creation (the service lives as long as Kodi)
def get_setting(name):
    return xbmcaddon.Addon().getSetting(name)

def set_setting(name, value):
    xbmcaddon.Addon().setSetting(name, value)
